GLOBAL PILGRIM - BINANCE INTEGRATION

Public API connectivity is checked by check.js.

Before private exchange integration:
1. Create an authorised Binance API key.
2. Use read-only permissions initially.
3. Never enable withdrawal permission on an exposed API key.
4. Keep API secrets in secure server-side secret storage.
5. Do not place secrets in index.html or browser JavaScript.

Exchange access does not automatically list PilgrimCoin.
PGC listing requires Binance approval.

Real deposits and withdrawals require additional implementation,
authorisation, security controls and testing.
