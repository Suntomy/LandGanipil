GLOBAL PILGRIM - BNB SMART CHAIN

Network: BNB Smart Chain Mainnet
Chain ID: 56
Native currency: BNB
RPC: https://bsc-dataseed.binance.org
Explorer: https://bscscan.com

PGC contract deployment is a separate operation.
Do not send funds until the contract address is verified.
