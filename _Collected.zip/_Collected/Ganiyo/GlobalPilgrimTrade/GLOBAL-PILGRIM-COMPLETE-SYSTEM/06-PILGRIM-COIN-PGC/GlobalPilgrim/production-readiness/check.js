const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");

const ROOT = process.cwd();
const OUT = path.join(
  ROOT,
  "production-readiness/reports"
);

fs.mkdirSync(OUT, { recursive: true });

const report = {
  project: "Global Pilgrim",
  assessment: "Production Readiness",
  generated: new Date().toISOString(),
  environment: {},
  project_files: {},
  dependencies: {},
  blockchain_networks: [],
  security: {},
  transaction_system: {},
  results: []
};

function exists(file) {
  return fs.existsSync(path.join(ROOT, file));
}

function readJSON(file) {
  try {
    return JSON.parse(
      fs.readFileSync(path.join(ROOT, file), "utf8")
    );
  } catch {
    return null;
  }
}

function findFiles(dir, depth = 0) {
  if (depth > 4 || !fs.existsSync(dir)) return [];

  let results = [];

  for (const item of fs.readdirSync(dir, {
    withFileTypes: true
  })) {
    if ([
      "node_modules",
      ".git",
      "wallets",
      "logs"
    ].includes(item.name)) continue;

    const full = path.join(dir, item.name);

    if (item.isDirectory()) {
      results.push(...findFiles(full, depth + 1));
    } else {
      results.push(path.relative(ROOT, full));
    }
  }

  return results;
}

report.environment = {
  operating_system: os.platform(),
  architecture: os.arch(),
  node: process.version,
  memory_available_mb:
    Math.round(os.freemem() / 1048576),
  project_directory: ROOT
};

const important = [
  "package.json",
  "index.js",
  "server.js",
  "network/check.js",
  "config/testnet.json",
  "database",
  "payments",
  "pilgrimcoin",
  "integrations",
  "robot",
  "public"
];

for (const file of important) {
  report.project_files[file] = exists(file);
}

const packageJSON = readJSON("package.json") || {};

report.dependencies = {
  declared: packageJSON.dependencies || {},
  installed: {}
};

for (const name of [
  "ethers",
  "@solana/web3.js",
  "bitcoinjs-lib",
  "express",
  "dotenv"
]) {
  try {
    report.dependencies.installed[name] =
      require.resolve(name);
  } catch {
    report.dependencies.installed[name] = false;
  }
}

const config = readJSON("config/testnet.json");

if (config) {
  function inspect(value, name = "network") {
    if (!value || typeof value !== "object") return;

    if (Array.isArray(value)) {
      value.forEach((v, i) => inspect(v, name + "_" + i));
      return;
    }

    for (const [key, val] of Object.entries(value)) {
      if (typeof val === "string" &&
          /rpc|endpoint|url/i.test(key) &&
          /^https?:\/\//.test(val)) {

        report.blockchain_networks.push({
          name: name,
          endpoint_configured: true,
          host: (() => {
            try { return new URL(val).hostname; }
            catch { return "unknown"; }
          })()
        });

      } else if (typeof val === "object") {
        inspect(val, key);
      }
    }
  }

  inspect(config);

  report.security.real_money_setting =
    config.real_money ?? "NOT SPECIFIED";

  report.security.mining_setting =
    config.mining ?? "NOT SPECIFIED";
}

report.security = {
  ...report.security,
  private_keys_in_report: false,
  secret_values_exposed: false,
  encryption_required: true,
  withdrawal_authorization_required: true,
  duplicate_transaction_protection_required: true
};

report.transaction_system = {
  wallet_creation: "REQUIRES TEST",
  message_signing: "REQUIRES TEST",
  deposit_verification: "REQUIRES TEST",
  internal_transfers: "REQUIRES TEST",
  external_withdrawals: "REQUIRES TEST",
  transaction_receipts: "REQUIRES TEST",
  balance_reconciliation: "REQUIRES TEST",
  audit_logs: "REQUIRES TEST",
  idempotency: "REQUIRES TEST"
};

const files = findFiles(ROOT);

report.results = [
  {
    test: "Project directory",
    status: "PASSED"
  },
  {
    test: "Test network configuration",
    status: config ? "FOUND" : "MISSING"
  },
  {
    test: "Ethers library",
    status: report.dependencies.installed.ethers
      ? "INSTALLED"
      : "MISSING"
  },
  {
    test: "Project source files",
    status: files.length ? "FOUND" : "MISSING"
  }
];

report.project_files.total_source_files = files.length;

const output = path.join(
  OUT,
  "production-readiness-report.json"
);

fs.writeFileSync(
  output,
  JSON.stringify(report, null, 2)
);

console.log("\n==================================");
console.log(" GLOBAL PILGRIM NETWORK REPORT");
console.log("==================================\n");

console.log("Project:", ROOT);
console.log("Node:", process.version);
console.log("Source files:", files.length);

console.log(
  "Testnet configuration:",
  config ? "FOUND" : "MISSING"
);

console.log(
  "Ethers:",
  report.dependencies.installed.ethers
    ? "INSTALLED"
    : "NOT INSTALLED"
);

console.log("\nReport created:");
console.log(output);

console.log("\nIMPORTANT:");
console.log("No real-money transaction was executed.");
console.log("No private key was included in the report.");
console.log("==================================");
