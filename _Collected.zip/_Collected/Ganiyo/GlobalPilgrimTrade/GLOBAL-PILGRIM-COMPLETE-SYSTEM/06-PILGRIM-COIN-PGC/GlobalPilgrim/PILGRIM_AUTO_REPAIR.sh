#!/data/data/com.termux/files/usr/bin/bash

clear

echo "=========================================="
echo " GLOBAL PILGRIM AUTO DIAGNOSTIC SYSTEM"
echo " NETWORK CHECK AND REPAIR"
echo "=========================================="

PROJECT="$PWD"
REPORT="$PROJECT/PILGRIM_DIAGNOSTIC_REPORT.txt"

touch "$REPORT"

log() {
    echo "$1" | tee -a "$REPORT"
}

log "GLOBAL PILGRIM DIAGNOSTIC"
log "DATE: $(date)"
log "PROJECT: $PROJECT"
log " "

ERRORS=0

check() {
    if eval "$2" >/dev/null 2>&1; then
        log "[PASS] $1"
    else
        log "[ERROR] $1"
        ERRORS=$((ERRORS+1))
    fi
}

echo "STEP 1: INSTALLING SYSTEM REQUIREMENTS"

pkg update -y
pkg upgrade -y
pkg install nodejs-lts npm git curl jq openssl python -y

check "Node.js installed" "node --version"
check "NPM installed" "npm --version"
check "Git installed" "git --version"
check "Curl installed" "curl --version"
check "OpenSSL installed" "openssl version"

echo
echo "STEP 2: PROJECT INSPECTION"

check "Package configuration" "test -f package.json"
check "Main index" "test -f index.js -o -f server.js -o -f index.html"
check "Network directory" "test -d network"
check "Wallet directory" "test -d wallets -o -d wallet"
check "Mining directory" "test -d pilgrim-mining -o -d mining"
check "Integration directory" "test -d integrations"

echo
echo "STEP 3: INSTALLING PROJECT DEPENDENCIES"

if [ -f package.json ]; then
    if npm install --no-audit --no-fund; then
        log "[PASS] Project dependencies installed"
    else
        log "[ERROR] npm install failed"
        ERRORS=$((ERRORS+1))
    fi
else
    log "[ERROR] package.json missing"
    ERRORS=$((ERRORS+1))
fi

echo
echo "STEP 4: CHECKING BLOCKCHAIN LIBRARIES"

for LIB in ethers express dotenv; do
    if node -e "require.resolve('$LIB')" >/dev/null 2>&1; then
        log "[PASS] $LIB installed"
    else
        log "[MISSING] $LIB"
    fi
done

echo
echo "STEP 5: BLOCKCHAIN CONFIGURATION"

if [ -f config/testnet.json ]; then
    jq empty config/testnet.json 2>/dev/null

    if [ $? -eq 0 ]; then
        log "[PASS] Test network JSON valid"
    else
        log "[ERROR] Test network JSON invalid"
        ERRORS=$((ERRORS+1))
    fi
else
    log "[ERROR] config/testnet.json missing"
fi

echo
echo "STEP 6: CHECKING NETWORK CONNECTIVITY"

if [ -n "$RPC_URL" ]; then

    RESULT=$(curl -sS --max-time 12 \
      -H "Content-Type: application/json" \
      -d '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}' \
      "$RPC_URL" 2>/dev/null)

    if echo "$RESULT" | jq -e '.result' >/dev/null 2>&1; then
        log "[PASS] EVM blockchain RPC responding"
        log "CHAIN ID: $(echo "$RESULT" | jq -r '.result')"
    else
        log "[ERROR] EVM blockchain RPC not responding"
        ERRORS=$((ERRORS+1))
    fi

else
    log "[WARNING] RPC_URL not configured"
fi

echo
echo "STEP 7: CHECKING TRANSACTION COMPONENTS"

for FILE in \
    wallet.js \
    wallets.js \
    payments/deposit.js \
    payments/withdraw.js \
    payments/transfer.js \
    network/check.js \
    database.js \
    server.js
do
    if [ -f "$FILE" ]; then
        log "[PASS] $FILE"
    else
        log "[MISSING] $FILE"
    fi
done

echo
echo "STEP 8: SECURITY INSPECTION"

if [ -f .env ]; then
    log "[PASS] Environment configuration exists"
else
    log "[WARNING] .env missing"
fi

if [ -d .git ]; then
    log "[PASS] Git project detected"
fi

if [ -f .gitignore ]; then
    log "[PASS] Git ignore file exists"
else
    log "[WARNING] .gitignore missing"
fi

if [ -f .env ]; then
    if grep -q '\.env' .gitignore 2>/dev/null; then
        log "[PASS] .env excluded from Git"
    else
        log "[WARNING] .env is not excluded from Git"
    fi
fi

echo
echo "STEP 9: SERVER STARTUP CHECK"

if [ -f server.js ]; then
    node --check server.js >/dev/null 2>&1 &&
        log "[PASS] server.js syntax valid" ||
        log "[ERROR] server.js syntax error"
elif [ -f index.js ]; then
    node --check index.js >/dev/null 2>&1 &&
        log "[PASS] index.js syntax valid" ||
        log "[ERROR] index.js syntax error"
else
    log "[WARNING] No recognized server entry point"
fi

echo
echo "STEP 10: FINAL REPORT"

log " "
log "=========================================="
log "DIAGNOSTIC FINISHED"
log "=========================================="
log "ERRORS DETECTED: $ERRORS"
log "REAL COIN TRANSACTION: NOT EXECUTED"
log "LIVE WITHDRAWALS: NOT ENABLED"
log " "

echo
echo "=========================================="
echo " GLOBAL PILGRIM RESULTS"
echo "=========================================="
echo "Errors detected: $ERRORS"
echo "Report: $REPORT"
echo
echo "No real money was transferred."
echo "=========================================="

