#!/data/data/com.termux/files/usr/bin/bash

set -e

cd "$(dirname "$0")"

pkg update -y
pkg install nodejs-lts -y

if [ ! -f package.json ]; then
    echo "ERROR: package.json missing"
    exit 1
fi

npm install --no-audit --no-fund

if [ ! -f .env ]; then
    cp .env.example .env
fi

mkdir -p logs database network wallets payments

echo "Checking backend..."
node --check server.js

echo "Checking wallet..."
node --check wallet.js

echo "Checking network..."
node --check network/check.js

echo "================================"
echo "GLOBAL PILGRIM INSTALL COMPLETE"
echo "================================"
echo "Start with: node server.js"
