const crypto = require("crypto");

function createTransferReference() {
    return "PGC-" + crypto.randomUUID();
}

function validateTransfer(data) {
    if (!data || !data.from || !data.to) {
        throw new Error("Sender and receiver are required");
    }

    if (data.from === data.to) {
        throw new Error("Self-transfer is not permitted");
    }

    const amount = Number(data.amount);

    if (!Number.isFinite(amount) || amount <= 0) {
        throw new Error("Invalid transfer amount");
    }

    return {
        reference: createTransferReference(),
        status: "PENDING",
        amount,
        from: data.from,
        to: data.to
    };
}

module.exports = { validateTransfer };
