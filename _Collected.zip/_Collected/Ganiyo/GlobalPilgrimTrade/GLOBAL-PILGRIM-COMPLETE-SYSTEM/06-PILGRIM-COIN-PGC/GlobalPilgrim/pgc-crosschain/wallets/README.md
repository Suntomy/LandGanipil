# External Wallet Integration

The PGC token is designed for compatible EVM wallets.

Required before public wallet integration:
1. Deploy the token contract to a supported network.
2. Verify the contract source code.
3. Publish the official contract address.
4. Test token transfers.
5. Publish token metadata and network details.

Never request or store a user's seed phrase or private key.
Never report a transaction as successful without checking its blockchain receipt.
