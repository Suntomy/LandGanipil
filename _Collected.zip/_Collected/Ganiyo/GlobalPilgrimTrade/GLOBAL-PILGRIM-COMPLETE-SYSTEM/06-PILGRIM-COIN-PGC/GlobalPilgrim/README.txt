PILGRIM MINING — Mine & Wallet
================================

HOW TO RUN
----------
1. Unzip the folder.
2. Double-click "index.html" (opens in any modern browser: Chrome, Edge, Firefox, Safari).
   No installation, no internet, no server required. It runs 100% locally.
3. All your mining balances, wallet addresses and history are saved automatically
   in your browser (localStorage), so they persist between visits.

FEATURES
--------
- 7 coins: Pilgrimcoin (PGC, MAIN) + Bitcoin (BTC), Ethereum (ETH), Litecoin (LTC),
  Dogecoin (DOGE), Monero (XMR), Ravencoin (RVN).
- Mining tab: Start/Stop mining per coin. Live balance + hash rate. Pilgrimcoin has a
  300-coin goal; mining stops automatically when 300 PGC are reached.
- Wallet tab: per-coin wallet balance, wallet address, and a mining/withdraw address
  for every coin. Pilgrim Main Wallet address is shown in the header (click to copy).
- Send / Withdraw tab: pick a coin, enter the destination wallet address (the coin's
  mining/withdraw address is pre-filled) and the number of coins to send. Coins move
  from your Mining Balance into your Wallet Balance and a record is logged.
  Optionally tick "Send to Pilgrim Main Wallet" to consolidate.
- History tab: full transaction log (time, coin, amount, type, wallet address, status).
- Download Backup (JSON) and Reset All Data buttons at the bottom.

NOTES
-----
- This is a simulation/mining dashboard for tracking and wallet management. It does not
  connect to real blockchains or perform real cryptographic mining.
- Addresses are generated locally for demonstration purposes.
- To back up or move your data, use "Download Backup (JSON)".
