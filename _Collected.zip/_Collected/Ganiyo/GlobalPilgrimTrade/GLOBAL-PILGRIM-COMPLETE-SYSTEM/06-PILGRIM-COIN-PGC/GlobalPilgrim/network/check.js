require("dotenv").config();

const { JsonRpcProvider } = require("ethers");

async function checkNetwork() {
    const rpc = process.env.RPC_URL;

    console.log("\nGLOBAL PILGRIM BLOCKCHAIN CHECK");

    if (!rpc) {
        console.log("[ERROR] RPC_URL is not configured");
        process.exitCode = 1;
        return;
    }

    try {
        const provider = new JsonRpcProvider(rpc);

        const network = await provider.getNetwork();
        const block = await provider.getBlockNumber();

        console.log("[PASS] RPC connected");
        console.log("Chain ID:", network.chainId.toString());
        console.log("Block:", block);

    } catch (error) {
        console.log("[ERROR] Network connection failed");
        console.log(error.message);
        process.exitCode = 1;
    }
}

checkNetwork();
