#!/data/data/com.termux/files/usr/bin/bash

set -u

cd ~/pilg_edit/Pil || exit 1

echo "======================================"
echo " GLOBAL PILGRIM CONNECTION MANAGER"
echo "======================================"

pkg install nodejs-lts curl jq -y

mkdir -p logs database network payments wallets

# Configure Ethereum Sepolia testnet.
export RPC_URL="https://ethereum-sepolia-rpc.publicnode.com"

# Preserve existing environment settings.
touch .env

for KEY in RPC_URL NETWORK_NAME REAL_MONEY_ENABLED WITHDRAWALS_ENABLED; do
    sed -i "/^${KEY}=/d" .env
done

cat >> .env <<'ENV'
RPC_URL=https://ethereum-sepolia-rpc.publicnode.com
NETWORK_NAME=ethereum-sepolia
REAL_MONEY_ENABLED=false
WITHDRAWALS_ENABLED=false
ENV

chmod 600 .env

echo ""
echo "1. TESTING BLOCKCHAIN CONNECTION"

RESULT=$(curl -sS --max-time 20 \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}' \
  "$RPC_URL" 2>/dev/null || true)

CHAIN=$(echo "$RESULT" | jq -r '.result // empty')

if [ "$CHAIN" = "0xaa36a7" ]; then
    echo "[CONNECTED] Ethereum Sepolia"
else
    echo "[FAILED] Blockchain RPC"
    echo "$RESULT"
fi

echo ""
echo "2. TESTING NODE DEPENDENCIES"

npm install --no-audit --no-fund

npm ls --depth=0

echo ""
echo "3. TESTING SERVER FILE"

node --check server.js || exit 1

echo ""
echo "4. STARTING GLOBAL PILGRIM"

if curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1; then
    echo "[CONNECTED] Backend already running"
else
    nohup node server.js > logs/server.log 2>&1 </dev/null &
    echo $! > logs/server.pid
    sleep 4
fi

echo ""
echo "5. TESTING ALL CONNECTIONS"

echo "BACKEND:"
curl -sS --max-time 10 http://127.0.0.1:3000/api/health

echo ""
echo ""
echo "BLOCKCHAIN:"
curl -sS --max-time 20 http://127.0.0.1:3000/api/network

echo ""
echo ""
echo "SECURITY:"
curl -sS http://127.0.0.1:3000/api/security

echo ""
echo ""
echo "======================================"
echo " CONNECTION TEST FINISHED"
echo "======================================"

echo "SERVER LOG:"
tail -20 logs/server.log

