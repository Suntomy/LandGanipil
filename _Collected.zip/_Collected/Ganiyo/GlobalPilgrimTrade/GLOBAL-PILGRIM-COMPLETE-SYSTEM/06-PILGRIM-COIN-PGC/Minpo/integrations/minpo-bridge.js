const express = require("express");
const crypto = require("crypto");

const { COINS, adapters } =
    require("./adapters");

const ledger =
    require("./reward-ledger");

const router = express.Router();

const MIN_CONFIRMATIONS = Number(
    process.env.MINPO_MIN_CONFIRMATIONS || 6
);

const WEBHOOK_SECRET =
    process.env.MINPO_REWARD_WEBHOOK_SECRET || "";

const API_KEY =
    process.env.MINPO_ADMIN_API_KEY || "";

const miningStarted = new Date();

function safeEqual(a, b) {

    const first = Buffer.from(a);
    const second = Buffer.from(b);

    return first.length === second.length &&
        crypto.timingSafeEqual(first, second);
}

function adminAuth(req, res, next) {

    if (!API_KEY) {
        return res.status(503).json({
            error: "Admin API key not configured"
        });
    }

    const supplied =
        req.headers["x-minpo-api-key"] || "";

    if (!safeEqual(supplied, API_KEY)) {
        return res.status(401).json({
            error: "Unauthorized"
        });
    }

    next();
}

async function callAdapter(coin, method, ...args) {

    const adapter = adapters[coin];

    if (!adapter) {
        return {
            available: false,
            status: "NOT_CONFIGURED"
        };
    }

    if (typeof adapter[method] !== "function") {
        return {
            available: false,
            status: "METHOD_NOT_IMPLEMENTED"
        };
    }

    try {

        const result = await adapter[method](...args);

        return {
            available: true,
            ...result
        };

    } catch (error) {

        console.error(
            `[MINPO] ${coin} ${method}:`,
            error.message
        );

        return {
            available: false,
            status: "ERROR"
        };
    }
}


// ------------------------------------
// SYSTEM HEALTH
// ------------------------------------

router.get("/health", async (req, res) => {

    const networks = {};

    for (const coin of COINS) {

        networks[coin] = await callAdapter(
            coin,
            "getHealth"
        );
    }

    res.json({
        service: "MINPO",
        status: "RUNNING",
        uptime: process.uptime(),
        startedAt: miningStarted.toISOString(),
        networks
    });

});


// ------------------------------------
// MINING STATUS
// ------------------------------------

router.get("/mining/status", async (req, res) => {

    const result = {};

    for (const coin of COINS) {

        result[coin] = await callAdapter(
            coin,
            "getMiningStatus"
        );
    }

    const hashes = Object.values(result)
        .reduce((total, item) => {

            if (!item.available) return total;

            const rate = Number(item.hashRate || 0);

            return total +
                (Number.isFinite(rate) ? rate : 0);

        }, 0);

    res.json({
        service: "MINPO",
        status: "MONITORING",
        hashRate: hashes,
        networks: result,
        updatedAt: new Date().toISOString()
    });

});


// ------------------------------------
// VERIFIED REWARD BALANCES
// ------------------------------------

router.get("/wallet/balances", (req, res) => {

    const balances = ledger.getBalances();

    res.json({
        service: "MINPO",
        verified: true,
        source: "MINPO_CONFIRMED_REWARD_LEDGER",
        balances,
        updatedAt: new Date().toISOString()
    });

});


// ------------------------------------
// REWARD HISTORY
// ------------------------------------

router.get("/rewards/history", (req, res) => {

    res.json({
        verified: true,
        rewards: ledger.getHistory()
    });

});


// ------------------------------------
// REWARD WEBHOOK
// ------------------------------------

router.post(
    "/rewards/webhook",
    express.raw({
        type: "application/json",
        limit: "32kb"
    }),
    async (req, res) => {

        if (!WEBHOOK_SECRET) {
            return res.status(503).json({
                error: "Reward webhook secret not configured"
            });
        }

        const signature =
            req.headers["x-minpo-signature"] || "";

        if (!/^[a-f0-9]{64}$/i.test(signature)) {
            return res.status(401).json({
                error: "Invalid signature"
            });
        }

        const expected = crypto
            .createHmac("sha256", WEBHOOK_SECRET)
            .update(req.body)
            .digest("hex");

        if (!safeEqual(signature, expected)) {
            return res.status(401).json({
                error: "Signature verification failed"
            });
        }

        let reward;

        try {
            reward = JSON.parse(req.body.toString("utf8"));
        } catch {
            return res.status(400).json({
                error: "Invalid JSON"
            });
        }

        const {
            coin,
            eventId,
            amount,
            source,
            blockHash,
            transactionHash,
            confirmations
        } = reward;

        if (!COINS.includes(coin)) {
            return res.status(400).json({
                error: "Unsupported coin"
            });
        }

        if (
            typeof eventId !== "string" ||
            eventId.length < 8 ||
            eventId.length > 200
        ) {
            return res.status(400).json({
                error: "Invalid reward event ID"
            });
        }

        if (
            typeof blockHash !== "string" ||
            !/^[a-f0-9]{32,128}$/i.test(blockHash)
        ) {
            return res.status(400).json({
                error: "Invalid block hash"
            });
        }

        if (
            !Number.isInteger(confirmations) ||
            confirmations < MIN_CONFIRMATIONS
        ) {
            return res.status(409).json({
                error: "Insufficient confirmations",
                required: MIN_CONFIRMATIONS
            });
        }

        // The coin adapter must independently verify
        // the reward against its actual blockchain.

        const verification = await callAdapter(
            coin,
            "verifyReward",
            reward
        );

        if (
            !verification.available ||
            verification.verified !== true
        ) {
            return res.status(403).json({
                error: "Blockchain reward not independently verified"
            });
        }

        try {

            const result = await ledger.creditReward({
                coin,
                eventId,
                amount,
                source,
                blockHash,
                transactionHash,
                confirmations
            });

            if (result.duplicate) {
                return res.status(200).json(result);
            }

            res.status(201).json(result);

        } catch (error) {

            console.error(error);

            res.status(400).json({
                error: "Reward accounting failed"
            });
        }

    }
);


// ------------------------------------
// LIVE NETWORK BALANCE CONNECTORS
// ------------------------------------

router.get("/wallet/networks", async (req, res) => {

    const result = {};

    for (const coin of COINS) {

        result[coin] = await callAdapter(
            coin,
            "getBalances"
        );
    }

    res.json({
        networks: result,
        updatedAt: new Date().toISOString()
    });

});


// ------------------------------------
// ADMIN NETWORK DIAGNOSTICS
// ------------------------------------

router.get("/admin/diagnostics", adminAuth, async (req, res) => {

    const diagnostics = {};

    for (const coin of COINS) {

        diagnostics[coin] = {
            adapterLoaded: Boolean(adapters[coin]),
            health: await callAdapter(coin, "getHealth"),
            mining: await callAdapter(coin, "getMiningStatus")
        };
    }

    res.json({
        service: "MINPO",
        diagnostics
    });

});

module.exports = router;
