'use strict';

const rules = require('../config/confirmation-rules.json');

function checkConfirmation(network, confirmations, finalized = false) {
  const key = String(network).toLowerCase();
  const rule = rules.networks[key];

  if (!rule) {
    return {
      accepted: false,
      status: 'UNSUPPORTED_NETWORK'
    };
  }

  if (rule.minimum_confirmations !== undefined &&
      Number(confirmations) < rule.minimum_confirmations) {
    return {
      accepted: false,
      status: 'PENDING_CONFIRMATIONS',
      required: rule.minimum_confirmations,
      actual: Number(confirmations)
    };
  }

  if (rule.require_finality_check && !finalized) {
    return {
      accepted: false,
      status: 'WAITING_FOR_FINALITY'
    };
  }

  if (rule.require_network_finality && !finalized) {
    return {
      accepted: false,
      status: 'WAITING_FOR_NETWORK_FINALITY'
    };
  }

  return {
    accepted: true,
    status: 'CONFIRMED'
  };
}

module.exports = { checkConfirmation };
