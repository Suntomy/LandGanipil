'use strict';

const endpoints = {
  ethereum: process.env.ETH_RPC_URL,
  bitcoin: process.env.BTC_RPC_URL,
  litecoin: process.env.LTC_RPC_URL,
  ton: process.env.TON_RPC_URL,
  pgc: process.env.PGC_RPC_URL
};

async function checkEthereum(url) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'eth_chainId',
      params: []
    }),
    signal: AbortSignal.timeout(15000)
  });

  if (!response.ok) throw new Error(`HTTP ${response.status}`);

  const data = await response.json();
  if (data.error) throw new Error(data.error.message);

  return { chain_id: data.result };
}

async function checkBitcoin(url) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '1.0',
      id: 'minpo',
      method: 'getblockchaininfo',
      params: []
    }),
    signal: AbortSignal.timeout(15000)
  });

  if (!response.ok) throw new Error(`HTTP ${response.status}`);

  const data = await response.json();
  if (data.error) throw new Error(data.error.message);

  return {
    chain: data.result.chain,
    blocks: data.result.blocks,
    verification_progress: data.result.verificationprogress
  };
}

async function check(url, network) {
  if (!url) return { configured: false, online: false };

  try {
    const result =
      network === 'ethereum'
        ? await checkEthereum(url)
        : network === 'bitcoin'
          ? await checkBitcoin(url)
          : { endpoint_reachable: true };

    return { configured: true, online: true, ...result };
  } catch (error) {
    return {
      configured: true,
      online: false,
      error: error.message
    };
  }
}

async function main() {
  const results = {};

  for (const [network, url] of Object.entries(endpoints)) {
    results[network] = await check(url, network);
  }

  console.log(JSON.stringify(results, null, 2));

  if (Object.values(results).some(x => !x.online)) {
    process.exitCode = 1;
  }
}

if (require.main === module) {
  main().catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { check };
