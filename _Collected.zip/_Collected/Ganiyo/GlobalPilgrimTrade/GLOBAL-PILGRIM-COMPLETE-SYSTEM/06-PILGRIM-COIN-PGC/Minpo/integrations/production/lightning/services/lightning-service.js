'use strict';

const crypto = require('node:crypto');

const BASE = (process.env.LND_REST_URL || '').replace(/\/+$/, '');
const MACAROON = process.env.LND_MACAROON_HEX || '';

function ready() {
  return Boolean(BASE && MACAROON);
}

function headers() {
  if (!ready()) {
    throw new Error('LND REST endpoint or macaroon is not configured');
  }

  return {
    'Grpc-Metadata-macaroon': MACAROON,
    'Content-Type': 'application/json'
  };
}

async function lnd(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const response = await fetch(BASE + path, {
      ...options,
      headers: { ...headers(), ...(options.headers || {}) },
      signal: controller.signal
    });

    const body = await response.text();
    let data;

    try {
      data = body ? JSON.parse(body) : {};
    } catch {
      throw new Error('LND returned a non-JSON response');
    }

    if (!response.ok) {
      throw new Error(data.message || `LND HTTP ${response.status}`);
    }

    return data;
  } finally {
    clearTimeout(timeout);
  }
}

async function health() {
  if (!ready()) {
    return {
      configured: false,
      online: false,
      message: 'Configure LND_REST_URL and LND_MACAROON_HEX'
    };
  }

  const info = await lnd('/v1/getinfo');

  return {
    configured: true,
    online: true,
    alias: info.alias,
    identity_pubkey: info.identity_pubkey,
    synced_to_chain: info.synced_to_chain,
    block_height: info.block_height,
    version: info.version
  };
}

async function createInvoice({ amountSat, memo, expirySeconds = 3600 }) {
  if (!Number.isSafeInteger(amountSat) || amountSat <= 0) {
    throw new Error('Invoice amount must be a positive integer in satoshis');
  }

  if (!Number.isInteger(expirySeconds) ||
      expirySeconds < 60 || expirySeconds > 86400) {
    throw new Error('Invoice expiry must be between 60 and 86400 seconds');
  }

  const paymentReference = crypto.randomUUID();

  const result = await lnd('/v1/invoices', {
    method: 'POST',
    body: JSON.stringify({
      value: String(amountSat),
      memo: String(memo || 'Minpo Lightning payment'),
      expiry: String(expirySeconds),
      private: true
    })
  });

  return {
    payment_reference: paymentReference,
    payment_request: result.payment_request,
    r_hash: result.r_hash,
    add_index: result.add_index,
    amount_sat: amountSat,
    expiry_seconds: expirySeconds,
    status: 'OPEN'
  };
}

async function lookupInvoice(paymentHash) {
  if (!paymentHash) throw new Error('Payment hash is required');

  const encoded = Buffer.from(paymentHash, 'base64').toString('hex');

  const result = await lnd(
    '/v1/invoice/' + encodeURIComponent(encoded)
  );

  return {
    payment_hash: paymentHash,
    settled: Boolean(result.settled),
    state: result.state || 'UNKNOWN',
    amount_paid_sat: result.amt_paid_sat || '0',
    settle_date: result.settle_date || null
  };
}

async function channels() {
  const result = await lnd('/v1/channels');

  return (result.channels || []).map(channel => ({
    channel_point: channel.channel_point,
    active: channel.active,
    remote_pubkey: channel.remote_pubkey,
    capacity_sat: channel.capacity,
    local_balance_sat: channel.local_balance,
    remote_balance_sat: channel.remote_balance,
    pending_htlcs: channel.pending_htlcs || []
  }));
}

async function exportChannelBackup() {
  const result = await lnd('/v1/channels/backup');

  if (!result.multi_chan_backup ||
      !result.multi_chan_backup.multi_chan_backup) {
    throw new Error('LND did not return a channel backup');
  }

  return result.multi_chan_backup.multi_chan_backup;
}

module.exports = {
  ready,
  health,
  createInvoice,
  lookupInvoice,
  channels,
  exportChannelBackup
};
