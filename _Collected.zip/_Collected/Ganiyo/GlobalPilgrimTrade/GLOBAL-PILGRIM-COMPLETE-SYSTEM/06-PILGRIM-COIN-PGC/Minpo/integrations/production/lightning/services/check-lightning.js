'use strict';

require('dotenv').config({ path: process.env.MINPO_ENV_FILE || undefined });

const lightning = require('./lightning-service');

(async () => {
  try {
    const result = await lightning.health();
    console.log(JSON.stringify(result, null, 2));

    if (!result.online) process.exitCode = 2;
  } catch (error) {
    console.error('LIGHTNING CHECK FAILED:', error.message);
    process.exitCode = 1;
  }
})();
