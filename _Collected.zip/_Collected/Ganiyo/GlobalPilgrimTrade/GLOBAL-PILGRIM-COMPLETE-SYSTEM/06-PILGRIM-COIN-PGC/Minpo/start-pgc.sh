#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME/Minpo/pgc-blockchain" || exit 1
nohup node node.js >> "$HOME/Minpo/logs/pgc-blockchain.log" 2>&1 &
sleep 2
curl -s http://127.0.0.1:3100/api/health
