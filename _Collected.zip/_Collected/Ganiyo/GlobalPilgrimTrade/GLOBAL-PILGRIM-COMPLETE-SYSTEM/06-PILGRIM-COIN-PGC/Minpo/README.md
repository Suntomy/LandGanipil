MINPO MULTI-COIN SYSTEM

Project: MINPO
Runtime: Termux Node.js
Dashboard: public/index.html
Backend: server.js
Coin configuration: assets.json

Supported assets:
BTC, ETH, LTC, TON, USDT, PGC, DOGE, SOL, BNB.

IMPORTANT:
This installation is a software foundation.
It does not create cryptocurrency or guarantee mining rewards.

Real mining requires eligible hardware and pool credentials.
Staking requires an eligible validator or staking provider.
USDT is a token and is not mined.
PGC requires its actual blockchain RPC and reward protocol.

Withdrawals remain disabled until secure signing,
address validation, fee handling and transaction
reconciliation have been implemented.

Backups exclude .env and private credentials.
