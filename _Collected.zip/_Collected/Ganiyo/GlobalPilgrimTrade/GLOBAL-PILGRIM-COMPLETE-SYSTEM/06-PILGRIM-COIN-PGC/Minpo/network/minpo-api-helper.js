// MINPO CENTRAL API RESPONSE HELPER

(function () {
    const API_BASE = window.location.origin;

    async function apiRequest(path, options = {}) {
        const url = new URL(path, API_BASE);

        const response = await fetch(url, {
            ...options,
            headers: {
                Accept: "application/json",
                ...(options.headers || {})
            }
        });

        const contentType =
            response.headers.get("content-type") || "";

        if (!contentType.includes("application/json")) {
            const body = await response.text();

            throw new Error(
                "MINPO API ERROR: Expected JSON but received " +
                contentType +
                ". HTTP " + response.status +
                ". Check API route: " + url.pathname +
                ". Response: " + body.slice(0, 150)
            );
        }

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.message ||
                data.error ||
                "MINPO API request failed: " + response.status
            );
        }

        return data;
    }

    window.MINPO_API = {
        base: API_BASE,
        request: apiRequest,

        health: function () {
            return apiRequest("/api/minpo/health");
        }
    };

    console.log("MINPO API HELPER READY");
})();
