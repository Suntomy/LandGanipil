(function () {

    let socket = null;
    let retryDelay = 2000;
    let stopped = false;

    function connect() {

        if (stopped) return;

        const protocol =
            location.protocol === "https:" ? "wss:" : "ws:";

        const url =
            protocol + "//" + location.host + "/ws";

        try {

            socket = new WebSocket(url);

            socket.onopen = function () {
                console.log("MINPO WEBSOCKET CONNECTED");
                retryDelay = 2000;

                window.dispatchEvent(
                    new Event("minpo:connected")
                );
            };

            socket.onmessage = function (event) {
                window.dispatchEvent(
                    new CustomEvent("minpo:message", {
                        detail: event.data
                    })
                );
            };

            socket.onerror = function () {
                console.error(
                    "MINPO WEBSOCKET ERROR:",
                    url
                );
            };

            socket.onclose = function () {

                if (stopped) return;

                console.warn(
                    "MINPO WEBSOCKET DISCONNECTED"
                );

                window.setTimeout(connect, retryDelay);

                retryDelay = Math.min(
                    retryDelay * 2,
                    30000
                );
            };

        } catch (error) {
            console.error(
                "MINPO WEBSOCKET:",
                error
            );

            window.setTimeout(connect, retryDelay);
        }
    }

    window.MINPO_SOCKET = {
        connect: connect,

        disconnect: function () {
            stopped = true;

            if (socket) socket.close();
        },

        send: function (message) {
            if (
                socket &&
                socket.readyState === WebSocket.OPEN
            ) {
                socket.send(
                    typeof message === "string"
                        ? message
                        : JSON.stringify(message)
                );

                return true;
            }

            return false;
        }
    };

    connect();

})();
