'use strict';

const fs = require('node:fs');
const path = require('node:path');

const PROJECT_ROOT = path.resolve(__dirname, '..');
const REGISTRY_FILE = path.join(__dirname, 'minpo-registry.json');

function getRegistry() {
  if (!fs.existsSync(REGISTRY_FILE)) {
    throw new Error('Minpo registry missing. Run MINPO_CONNECT_ALL.sh');
  }

  return JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf8'));
}

function getModuleFiles() {
  const registry = getRegistry();
  return registry.modules || [];
}

function getProjectFile(relativePath) {
  const target = path.resolve(PROJECT_ROOT, relativePath);

  if (!target.startsWith(PROJECT_ROOT + path.sep)) {
    throw new Error('Invalid project path');
  }

  if (!fs.existsSync(target)) {
    throw new Error('Project file not found: ' + relativePath);
  }

  return target;
}

function getModuleStatus() {
  return getModuleFiles().map(item => {
    const target = getProjectFile(item.path);

    return {
      path: item.path,
      exists: fs.existsSync(target),
      extension: item.extension,
      size: item.size
    };
  });
}

function getApiBase() {
  return process.env.MINPO_API_BASE || '/api/minpo';
}

function getApiUrl(endpoint = '') {
  const base = getApiBase().replace(/\/+$/, '');
  const suffix = String(endpoint).replace(/^\/+/, '');
  return suffix ? `${base}/${suffix}` : base;
}

async function apiRequest(endpoint, options = {}) {
  const url = getApiUrl(endpoint);

  const response = await fetch(url, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(options.headers || {})
    }
  });

  const contentType = response.headers.get('content-type') || '';

  if (!contentType.includes('application/json')) {
    throw new Error(
      `Minpo API returned non-JSON response: ${response.status}`
    );
  }

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || `API error ${response.status}`);
  }

  return data;
}

module.exports = {
  PROJECT_ROOT,
  getRegistry,
  getModuleFiles,
  getModuleStatus,
  getProjectFile,
  getApiBase,
  getApiUrl,
  apiRequest
};
