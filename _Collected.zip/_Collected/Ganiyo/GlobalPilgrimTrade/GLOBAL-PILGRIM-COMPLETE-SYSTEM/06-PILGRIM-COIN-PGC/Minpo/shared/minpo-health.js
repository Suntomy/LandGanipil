'use strict';

const connector = require('./minpo-connector');

function health() {
  const registry = connector.getRegistry();
  const modules = connector.getModuleStatus();

  const counts = {
    discovered: modules.length,
    existing: modules.filter(x => x.exists).length,
    missing: modules.filter(x => !x.exists).length
  };

  return {
    service: 'MINPO',
    status: 'REGISTRY_AVAILABLE',
    api: connector.getApiBase(),
    counts,
    entrypoints: registry.entrypoints,
    modules
  };
}

if (require.main === module) {
  try {
    console.log(JSON.stringify(health(), null, 2));
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

module.exports = { health };
