const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");

const CONFIG_FILE = path.join(
  ROOT, "pgc-network", "pgc-config.json"
);

const MEMORY_FILE = path.join(
  ROOT, "memory", "robot-memory.json"
);

const LOG_FILE = path.join(
  ROOT, "logs", "pgc-human-robot.log"
);

function load(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function save(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function remember(message) {
  const line = new Date().toISOString() + " " + message;

  console.log(line);
  fs.appendFileSync(LOG_FILE, line + "\n");
}

function inspectConfiguration(config) {
  const missing = [];

  if (!config.network.rpc)
    missing.push("PGC RPC endpoint");

  if (!config.network.chainId)
    missing.push("PGC chain ID");

  if (!config.network.consensus)
    missing.push("Consensus mechanism");

  if (!config.network.algorithm)
    missing.push("Mining algorithm or validation method");

  if (!config.network.genesisHash)
    missing.push("Genesis block hash");

  return missing;
}

async function inspectEndpoint(url) {
  if (!url || !/^https:\/\//i.test(url)) {
    return {
      connected: false,
      reason: "Valid HTTPS RPC endpoint required"
    };
  }

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method: "eth_chainId",
        params: [],
        id: 1
      }),
      signal: AbortSignal.timeout(10000)
    });

    const data = await response.json();

    if (!response.ok || data.error || !data.result) {
      throw new Error("RPC validation failed");
    }

    return {
      connected: true,
      chainId: data.result
    };

  } catch (error) {
    return {
      connected: false,
      reason: error.message
    };
  }
}

async function brain() {
  const config = load(CONFIG_FILE);
  const memory = load(MEMORY_FILE);

  remember("PGC HUMAN ROBOT STARTED");
  remember("Inspecting Pilgrim Coin network.");

  const missing = inspectConfiguration(config);

  for (const item of missing) {
    remember("MISSING CONFIGURATION: " + item);
  }

  if (config.network.rpc) {
    const result = await inspectEndpoint(config.network.rpc);

    if (result.connected) {
      remember("PGC RPC RESPONDED.");

      memory.discoveries.push({
        type: "PGC_RPC_RESPONSE",
        chainId: result.chainId,
        date: new Date().toISOString()
      });

    } else {
      remember("PGC RPC ERROR: " + result.reason);

      memory.failures.push({
        error: result.reason,
        date: new Date().toISOString()
      });
    }
  }

  config.network.status =
    missing.length === 0
      ? "CONFIGURATION_COMPLETE_PENDING_VERIFICATION"
      : "AWAITING_MISSING_CONFIGURATION";

  memory.lastScan = new Date().toISOString();

  save(CONFIG_FILE, config);
  save(MEMORY_FILE, memory);

  const report = {
    robot: "PGC HUMAN INTELLIGENCE",
    time: new Date().toISOString(),
    missingConfiguration: missing,
    networkStatus: config.network.status,
    miningEnabled: config.mining.enabled,
    rewardIssuanceEnabled:
      config.security.automaticRewardIssuance
  };

  fs.writeFileSync(
    path.join(ROOT, "logs", "pgc-diagnostic-report.json"),
    JSON.stringify(report, null, 2)
  );

  remember("DIAGNOSTIC COMPLETED.");
}

async function start() {
  await brain();

  if (process.argv.includes("--once")) return;

  setInterval(() => {
    brain().catch(error => {
      remember("ROBOT ERROR: " + error.message);
    });
  }, 60000);
}

start().catch(error => {
  remember("FATAL ERROR: " + error.message);
  process.exit(1);
});
