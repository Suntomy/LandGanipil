const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "../network/native-rewards.json");

const [symbol, amount, txid] = process.argv.slice(2);

if (!symbol || !amount || !txid ||
    !Number.isFinite(Number(amount)) ||
    Number(amount) <= 0) {
  console.log(
    'Usage: node robot/record-reward.js BTC 0.001 TRANSACTION_ID'
  );
  process.exit(1);
}

const db = JSON.parse(fs.readFileSync(file, "utf8"));

if (db.rewards.some(r => r.txid === txid)) {
  console.error("Duplicate transaction. Reward not recorded.");
  process.exit(1);
}

db.rewards.push({
  symbol: symbol.toUpperCase(),
  amount: Number(amount),
  txid,
  status: "PENDING_INDEPENDENT_VERIFICATION",
  recordedAt: new Date().toISOString()
});

fs.writeFileSync(file, JSON.stringify(db, null, 2));

console.log("Reward recorded for verification.");
console.log("No PGC has been issued or credited.");
