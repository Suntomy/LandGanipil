const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");

const file = name => path.join(ROOT, name);

function read(name, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file(name), "utf8"));
  } catch {
    return fallback;
  }
}

function write(name, data) {
  fs.writeFileSync(file(name), JSON.stringify(data, null, 2));
}

function log(message) {
  const line = new Date().toISOString() + " " + message;
  console.log(line);
  fs.appendFileSync(file("logs/network-intelligence.log"), line + "\n");
}

async function rpc(url, method, params = []) {
  if (!url || !url.startsWith("https://")) {
    throw new Error("HTTPS endpoint required");
  }

  const response = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method,
      params
    }),
    signal: AbortSignal.timeout(12000)
  });

  if (!response.ok) {
    throw new Error("HTTP " + response.status);
  }

  const result = await response.json();

  if (result.error || result.result === undefined) {
    throw new Error("RPC verification failed");
  }

  return result.result;
}

async function verify(network) {
  if (network.protocol === "EVM") {
    const chain = await rpc(network.rpc, "eth_chainId");
    const genesis = await rpc(
      network.rpc,
      "eth_getBlockByNumber",
      ["0x0", false]
    );

    const chainId = Number(BigInt(chain));

    if (chainId !== Number(network.chainId)) {
      throw new Error("Chain ID mismatch");
    }

    if (!genesis || !genesis.hash) {
      throw new Error("Genesis block unavailable");
    }

    return {
      protocol: "EVM",
      chainId,
      genesisHash: genesis.hash
    };
  }

  if (network.protocol === "SOLANA") {
    const genesisHash = await rpc(
      network.rpc,
      "getGenesisHash"
    );

    const health = await rpc(network.rpc, "getHealth");

    if (health !== "ok") {
      throw new Error("Solana health check failed");
    }

    return {
      protocol: "SOLANA",
      genesisHash,
      health
    };
  }

  throw new Error("Unsupported protocol");
}

async function scan() {
  const catalog = read("network/network-catalog.json", {
    networks: []
  });

  const active = read("integrations/active-networks.json", {
    networks: []
  });

  const memory = read("network/network-memory.json", {
    discoveries: [],
    failures: []
  });

  for (const network of catalog.networks) {
    try {
      log("Discovering " + network.symbol);

      const identity = await verify(network);

      const integration = {
        name: network.name,
        symbol: network.symbol,
        protocol: network.protocol,
        rpc: network.rpc,
        verifiedIdentity: identity,
        status: "AUTO_CONNECTED_READ_ONLY",
        miningEnabled: false,
        withdrawalsEnabled: false,
        transactionsEnabled: false,
        lastVerified: new Date().toISOString()
      };

      const index = active.networks.findIndex(
        n => n.symbol === network.symbol
      );

      if (index >= 0) {
        active.networks[index] = integration;
      } else {
        active.networks.push(integration);
      }

      memory.discoveries.push({
        symbol: network.symbol,
        date: new Date().toISOString(),
        status: "CONNECTED"
      });

      log(network.symbol + " automatically connected.");

    } catch (error) {
      memory.failures.push({
        symbol: network.symbol,
        error: error.message,
        date: new Date().toISOString()
      });

      log(network.symbol + " failed: " + error.message);
    }
  }

  memory.lastScan = new Date().toISOString();

  write("integrations/active-networks.json", active);
  write("network/network-memory.json", memory);

  log("Automatic discovery completed.");
}

function status() {
  const active = read("integrations/active-networks.json", {
    networks: []
  });

  console.log("\nMINPO AUTOMATIC NETWORK STATUS");

  for (const network of active.networks) {
    console.log(
      network.symbol + " : " + network.status
    );
  }

  console.log("\nAutomatic discovery: ON");
  console.log("Automatic read-only integration: ON");
  console.log("Mining: NOT ACTIVATED");
  console.log("Withdrawals: NOT ACTIVATED");
  console.log("Financial transactions: NOT ACTIVATED");
}

async function main() {
  const command = process.argv[2];

  if (command === "scan") {
    await scan();
  } else if (command === "status") {
    status();
  } else {
    console.log(
      "Commands: scan | status"
    );
  }
}

main().catch(error => {
  log("ROBOT ERROR: " + error.message);
  process.exitCode = 1;
});
