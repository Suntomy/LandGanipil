#!/data/data/com.termux/files/usr/bin/bash

cd "$HOME/Minpo" || exit 1

while true; do
    node robot/network-intelligence.js scan
    sleep 300
done
