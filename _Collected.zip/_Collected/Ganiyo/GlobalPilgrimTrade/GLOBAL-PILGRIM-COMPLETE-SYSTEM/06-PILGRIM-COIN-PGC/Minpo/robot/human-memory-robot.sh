#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME/Minpo" || exit 1
REPORT="$HOME/Minpo/logs/diagnostic-report.txt"
ERRORS=0
{
echo "MINPO DIAGNOSTIC"
date
for f in server.js public/index.html config/pgc.json cloud-worker/README.txt; do
 if [ -s "$f" ]; then echo "OK: $f"; else echo "ERROR: $f"; ERRORS=$((ERRORS+1)); fi
done
node --check server.js || ERRORS=$((ERRORS+1))
node -e "JSON.parse(require('fs').readFileSync('config/pgc.json'))" || ERRORS=$((ERRORS+1))
echo "Errors found: $ERRORS"
echo "PGC network/mining still requires real network configuration."
} | tee "$REPORT"
