const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "../config/networks.json");

const [name, symbol, type, algorithm, endpoint] =
  process.argv.slice(2);

if (!name || !symbol || !type || !algorithm || !endpoint) {
  console.log(
    'Usage: node robot/add-network.js "Network Name" SYMBOL TYPE ALGORITHM RPC_URL'
  );
  process.exit(1);
}

if (!/^https:\/\//i.test(endpoint)) {
  console.error("Only HTTPS endpoints are accepted.");
  process.exit(1);
}

const config = JSON.parse(fs.readFileSync(file, "utf8"));

if (config.networks.some(n => n.symbol === symbol.toUpperCase())) {
  console.error("Network already registered.");
  process.exit(1);
}

config.networks.push({
  name,
  symbol: symbol.toUpperCase(),
  type,
  algorithm,
  status: "PENDING_VERIFICATION",
  endpoint
});

fs.writeFileSync(file, JSON.stringify(config, null, 2));

console.log("Network added for verification:", symbol);
console.log("Mining is NOT automatically enabled.");
