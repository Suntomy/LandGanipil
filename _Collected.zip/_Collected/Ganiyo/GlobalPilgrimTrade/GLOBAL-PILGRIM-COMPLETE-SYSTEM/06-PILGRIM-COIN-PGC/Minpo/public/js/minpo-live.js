
async function minpoRequest(endpoint) {

    const response = await fetch(endpoint);

    if (!response.ok) {
        throw new Error("MINPO API error: " + response.status);
    }

    return response.json();
}

async function minpoRefresh() {

    try {

        const health = await minpoRequest(
            "/api/minpo/health"
        );

        const mining = await minpoRequest(
            "/api/minpo/mining/status"
        );

        const balances = await minpoRequest(
            "/api/minpo/wallet/balances"
        );

        const networks = await minpoRequest(
            "/api/minpo/wallet/networks"
        );

        console.log("MINPO HEALTH", health);
        console.log("MINPO MINING", mining);
        console.log("MINPO REWARDS", balances);
        console.log("MINPO NETWORK WALLETS", networks);

        window.MINPO_LIVE = {
            health,
            mining,
            balances,
            networks
        };

        window.dispatchEvent(
            new CustomEvent("minpo:update", {
                detail: window.MINPO_LIVE
            })
        );

    } catch (error) {

        console.error("MINPO CONNECTION ERROR:", error);

    }
}

minpoRefresh();

setInterval(
    minpoRefresh,
    60000
);

