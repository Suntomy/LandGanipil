window.MINPO_CONFIG = {
    API_BASE: "",
    REFRESH_INTERVAL: 60000,
    ASSETS: [
        "PGC",
        "BTC",
        "ETH",
        "LTC",
        "TON",
        "USDT"
    ]
};
