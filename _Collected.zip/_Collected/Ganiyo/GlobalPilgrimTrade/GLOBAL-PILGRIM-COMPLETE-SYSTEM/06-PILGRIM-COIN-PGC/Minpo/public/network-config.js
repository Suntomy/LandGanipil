"use strict";

window.MINPO_NETWORK = {
    API: "/api/minpo",

    COINS: [
        "PGC",
        "BTC",
        "ETH",
        "LTC",
        "TON",
        "USDT"
    ],

    request: async function(path, options = {}) {

        const response = await fetch(
            this.API + path,
            {
                ...options,
                cache: "no-store",
                headers: {
                    "Accept": "application/json",
                    ...options.headers
                }
            }
        );

        if (!response.ok) {
            throw new Error(
                "MINPO API ERROR: " + response.status
            );
        }

        return response.json();
    }
};
