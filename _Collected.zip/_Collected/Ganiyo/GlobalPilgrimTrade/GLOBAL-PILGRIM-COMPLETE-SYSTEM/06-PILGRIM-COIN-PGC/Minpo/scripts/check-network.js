"use strict";

const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");

const required = [
    "server.js",
    "package.json",
    "config/network.json",
    "shared/network.js",
    "public/network-config.js"
];

console.log("\nMINPO NETWORK DIAGNOSTICS\n");

for (const file of required) {

    const full = path.join(root, file);

    console.log(
        fs.existsSync(full)
            ? "[FOUND] " + file
            : "[MISSING] " + file
    );
}

const config = JSON.parse(
    fs.readFileSync(
        path.join(root, "config/network.json"),
        "utf8"
    )
);

console.log("\nCENTRAL API:", config.apiPrefix);

console.log("\nSUPPORTED COINS:");

for (const [symbol, coin] of Object.entries(config.coins)) {
    console.log(
        symbol + " - " +
        coin.name + " - " +
        (coin.enabled ? "ENABLED" : "NOT CONFIGURED")
    );
}

console.log("\nDiagnostic completed.");
