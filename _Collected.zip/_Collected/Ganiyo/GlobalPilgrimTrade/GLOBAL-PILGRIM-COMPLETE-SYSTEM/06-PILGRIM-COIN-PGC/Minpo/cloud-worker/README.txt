MINPO PGC CLOUD WORKER

Primary coin: Pilgrim Coin (PGC)
Owner attribution: Olawale Abdul-Ganiyu Adeshina

This directory is reserved for a real PGC-compatible mining worker.

Before deployment:
1. Confirm PGC mainnet RPC and node software.
2. Confirm consensus and mining algorithm.
3. Confirm block reward and validation rules.
4. Install compatible miner/pool software.
5. Configure a public PGC reward address.
6. Verify real accepted shares and confirmed payouts.

This directory does not itself start a cloud server or miner.
Never store wallet seed phrases or private keys here.
