require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"]
    }
  }
}));
app.use(express.json({ limit: '32kb' }));

// No demo accounts, seeded balances, synthetic prices or order execution.
const brokers = {
  HFM: { connected: false, liveVerified: false },
  PU_PRIME: { connected: false, liveVerified: false }
};

app.get('/api/health', (req, res) => {
  res.json({
    application: 'PILGRIM LIVE TRADING',
    backend: 'online',
    tradingData: 'unavailable_until_broker_verification',
    simulatedData: false,
    orderExecution: false,
    withdrawals: false,
    time: new Date().toISOString()
  });
});

app.get('/api/brokers', (req, res) => {
  res.json({
    brokers: Object.entries(brokers).map(([name, status]) => ({
      name,
      ...status,
      message: 'Authorised broker connection not configured'
    }))
  });
});

// Return no account data until a genuine broker adapter is installed.
app.get('/api/account/:broker', (req, res) => {
  const requestedName = req.params.broker.toUpperCase().replace(/-/g, '_');
  const name = requestedName === 'PUPRIME' ? 'PU_PRIME' : requestedName;
  if (!brokers[name]) {
    return res.status(404).json({ error: 'Unknown broker' });
  }
  return res.status(503).json({
    broker: name,
    connected: false,
    accountData: null,
    balance: null,
    equity: null,
    freeMargin: null,
    positions: null,
    message: 'No verified live broker data. No balance is being displayed.'
  });
});

app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, HOST, () => {
  console.log(`PILGRIM LIVE TRADING: http://${HOST}:${PORT}`);
  console.log('Broker connections: NOT CONFIGURED');
  console.log('Orders: DISABLED | Withdrawals: DISABLED');
});
