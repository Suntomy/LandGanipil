
/* PILGRIM PRIVATE BRANDING - MANAGED */
(function () {
  if (typeof document === 'undefined') return;

  function addPilgrimBrand() {
    if (!document.body ||
        document.querySelector('.pilgrim-owner-banner')) return;

    const banner = document.createElement('div');
    banner.className = 'pilgrim-owner-banner';

    const title = document.createElement('div');
    title.textContent = 'PILGRIM PRIVATE TRADING PLATFORM';

    const owner = document.createElement('small');
    owner.textContent =
      'Owner: Olawale Abdul-Ganiyu Adeshina | Adegan Global Enterprise';

    const access = document.createElement('small');
    access.textContent = 'Private system — authorized access only';

    banner.append(title, owner, access);
    document.body.prepend(banner);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addPilgrimBrand);
  } else {
    addPilgrimBrand();
  }
})();
