PILGRIM LIVE TRADING - OFFICIAL TECHNICAL REFERENCES

Vercel CLI deployment:
https://vercel.com/docs/projects/deploy-from-cli

Vercel environment variables:
https://vercel.com/docs/environment-variables

Vercel sensitive environment variables:
https://vercel.com/docs/environment-variables/sensitive-environment-variables

Vercel deployment protection:
https://vercel.com/docs/deployment-protection

Vercel security settings:
https://vercel.com/docs/project-configuration/security-settings

Vercel Git deployment:
https://vercel.com/docs/git

Google Search Central:
https://developers.google.com/search/docs

RULES:
- Do not execute arbitrary scripts found through Google Search.
- Use official package registries and vendor documentation.
- Never commit .env files, passwords, tokens, wallet keys or certificates.
- Do not put broker credentials in browser JavaScript.
- Do not represent an unverified broker connection as live.
