-- PILGRIM GLOBAL FINANCIAL LEDGER
-- Supabase PostgreSQL migration
-- No simulated balances or client-authorized transfers.

create extension if not exists pgcrypto;

-- 1. Main financial transaction ledger
create table if not exists public.pilgrim_transactions (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id),
    transaction_ref text not null unique
      default ('PGT-' || upper(substr(
        replace(gen_random_uuid()::text, '-', ''), 1, 20
      ))),

    transaction_type text not null check (
      transaction_type in (
        'deposit', 'withdrawal', 'transfer',
        'trade_profit', 'trade_loss',
        'fee', 'refund', 'reversal'
      )
    ),

    source_provider text,
    destination_provider text,
    currency varchar(12) not null,
    amount numeric(24,8) not null check (amount > 0),
    fee numeric(24,8) not null default 0 check (fee >= 0),

    status text not null default 'pending' check (
      status in ('pending', 'confirmed', 'failed', 'reversed')
    ),

    external_reference text,
    blockchain_tx_hash text,

    from_wallet_address text,
    to_wallet_address text,

    from_bank_name text,
    from_account_last4 varchar(4),
    to_bank_name text,
    to_account_last4 varchar(4),

    idempotency_key text,
    provider_payload_hash text,
    metadata jsonb not null default '{}'::jsonb,

    verified_at timestamptz,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),

    unique (user_id, idempotency_key),
    unique (id, user_id)
);

create index if not exists pilgrim_tx_user_date_idx
on public.pilgrim_transactions(user_id, created_at desc);

create index if not exists pilgrim_tx_external_ref_idx
on public.pilgrim_transactions(external_reference);

create index if not exists pilgrim_tx_hash_idx
on public.pilgrim_transactions(blockchain_tx_hash);

-- 2. Saved bank and crypto destinations
create table if not exists public.pilgrim_destinations (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id),

    destination_type text not null check (
      destination_type in ('bank', 'crypto')
    ),

    label text,

    bank_name text,
    bank_code text,
    account_name text,
    account_last4 varchar(4),
    provider_beneficiary_token text,

    wallet_network text,
    wallet_address text,

    created_at timestamptz not null default now(),

    check (
      (destination_type = 'bank' and
       bank_name is not null and
       account_last4 is not null)
      or
      (destination_type = 'crypto' and
       wallet_network is not null and
       wallet_address is not null)
    )
);

create index if not exists pilgrim_destinations_user_idx
on public.pilgrim_destinations(user_id);

-- 3. Receipt records
create table if not exists public.pilgrim_receipts (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id),
    transaction_id uuid not null,

    storage_path text not null unique,
    mime_type text not null,
    file_size bigint,
    sha256 text,

    created_at timestamptz not null default now(),
    foreign key (transaction_id, user_id)
      references public.pilgrim_transactions(id, user_id)
);

-- 4. Immutable audit history
create table if not exists public.pilgrim_audit_events (
    id bigint generated always as identity primary key,
    user_id uuid not null references auth.users(id),
    transaction_id uuid references public.pilgrim_transactions(id),

    event_type text not null,
    old_status text,
    new_status text,
    actor_type text not null default 'server',
    external_reference text,
    metadata jsonb not null default '{}'::jsonb,

    created_at timestamptz not null default now()
);

create index if not exists pilgrim_audit_user_date_idx
on public.pilgrim_audit_events(user_id, created_at desc);

-- 5. Record transaction creation and status changes automatically
create or replace function public.pilgrim_record_transaction_audit()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    insert into public.pilgrim_audit_events (
        user_id,
        transaction_id,
        event_type,
        old_status,
        new_status,
        actor_type,
        external_reference,
        metadata
    )
    values (
        new.user_id,
        new.id,
        case
          when tg_op = 'INSERT' then 'transaction_created'
          else 'transaction_updated'
        end,
        case when tg_op = 'UPDATE' then old.status else null end,
        new.status,
        'server',
        new.external_reference,
        pg_catalog.jsonb_build_object(
          'transaction_type', new.transaction_type,
          'currency', new.currency,
          'amount', new.amount
        )
    );

    return new;
end;
$$;

revoke all on function public.pilgrim_record_transaction_audit() from public, anon, authenticated;

drop trigger if exists pilgrim_transaction_audit
on public.pilgrim_transactions;

create trigger pilgrim_transaction_audit
after insert or update on public.pilgrim_transactions
for each row
execute function public.pilgrim_record_transaction_audit();

-- 6. Prevent deletion of financial transaction records
create or replace function public.pilgrim_prevent_transaction_delete()
returns trigger
language plpgsql
as $$
begin
    raise exception
      'Financial transactions cannot be deleted. Use a reversal record.';
end;
$$;

drop trigger if exists pilgrim_no_transaction_delete
on public.pilgrim_transactions;

create trigger pilgrim_no_transaction_delete
before delete on public.pilgrim_transactions
for each row
execute function public.pilgrim_prevent_transaction_delete();

-- 7. Prevent editing or deleting audit records
create or replace function public.pilgrim_prevent_audit_changes()
returns trigger
language plpgsql
as $$
begin
    raise exception 'Audit records are immutable.';
end;
$$;

drop trigger if exists pilgrim_audit_immutable
on public.pilgrim_audit_events;

create trigger pilgrim_audit_immutable
before update or delete on public.pilgrim_audit_events
for each row
execute function public.pilgrim_prevent_audit_changes();

-- 8. Enable row-level security
alter table public.pilgrim_transactions enable row level security;
alter table public.pilgrim_destinations enable row level security;
alter table public.pilgrim_receipts enable row level security;
alter table public.pilgrim_audit_events enable row level security;

-- 9. Remove direct client write permissions
revoke all on public.pilgrim_transactions from anon, authenticated;
revoke all on public.pilgrim_destinations from anon, authenticated;
revoke all on public.pilgrim_receipts from anon, authenticated;
revoke all on public.pilgrim_audit_events from anon, authenticated;

grant select on public.pilgrim_transactions to authenticated;
grant select on public.pilgrim_destinations to authenticated;
grant select on public.pilgrim_receipts to authenticated;
grant select on public.pilgrim_audit_events to authenticated;

grant all on public.pilgrim_transactions to service_role;
grant all on public.pilgrim_destinations to service_role;
grant all on public.pilgrim_receipts to service_role;
grant all on public.pilgrim_audit_events to service_role;

-- 10. Users can only read their own records
drop policy if exists pilgrim_tx_read_own
on public.pilgrim_transactions;

create policy pilgrim_tx_read_own
on public.pilgrim_transactions
for select to authenticated
using (user_id = (select auth.uid()));

drop policy if exists pilgrim_destinations_read_own
on public.pilgrim_destinations;

create policy pilgrim_destinations_read_own
on public.pilgrim_destinations
for select to authenticated
using (user_id = (select auth.uid()));

drop policy if exists pilgrim_receipts_read_own
on public.pilgrim_receipts;

create policy pilgrim_receipts_read_own
on public.pilgrim_receipts
for select to authenticated
using (user_id = (select auth.uid()));

drop policy if exists pilgrim_audit_read_own
on public.pilgrim_audit_events;

create policy pilgrim_audit_read_own
on public.pilgrim_audit_events
for select to authenticated
using (user_id = (select auth.uid()));

-- 11. Private receipt storage bucket
insert into storage.buckets (
    id, name, public, file_size_limit, allowed_mime_types
)
values (
    'pilgrim-receipts',
    'pilgrim-receipts',
    false,
    10485760,
    array[
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/webp'
    ]
)
on conflict (id) do update
set public = false,
    file_size_limit = 10485760;

drop policy if exists pilgrim_receipt_objects_read_own
on storage.objects;

create policy pilgrim_receipt_objects_read_own
on storage.objects
for select to authenticated
using (
    bucket_id = 'pilgrim-receipts'
    and (storage.foldername(name))[1] = (select auth.uid())::text
);

-- Server-side service_role uploads receipts.
-- Browser users do not receive direct upload or delete privileges.

