require('dotenv').config();
const express = require('express');
const { RSI } = require('technicalindicators');

const app = express();
const PORT = 3101;
const timeout = 15000;

async function getJSON(url) {
  const r = await fetch(url, {
    signal: AbortSignal.timeout(timeout),
    headers: { accept: 'application/json' }
  });
  if (!r.ok) throw new Error(`Provider returned HTTP ${r.status}`);
  return r.json();
}

app.get('/api/market/health', (req, res) => {
  res.json({
    service: 'Pilgrim Read-only Market Data',
    status: 'online',
    tradingEnabled: false,
    withdrawalsEnabled: false,
    timestamp: new Date().toISOString()
  });
});

app.get('/api/market/crypto', async (req, res) => {
  try {
    const data = await getJSON(
      'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=50&page=1&sparkline=false'
    );
    res.json({ source: 'CoinGecko', dataTimestamp: new Date().toISOString(), data });
  } catch (e) {
    res.status(502).json({ error: e.message, source: 'CoinGecko' });
  }
});

app.get('/api/market/signal/:coin', async (req, res) => {
  try {
    const coin = String(req.params.coin).toLowerCase();
    if (!/^[a-z0-9-]{1,60}$/.test(coin)) {
      return res.status(400).json({ error: 'Invalid coin ID' });
    }
    const data = await getJSON(
      `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(coin)}/market_chart?vs_currency=usd&days=90`
    );
    const prices = (data.prices || []).map(x => Number(x[1])).filter(Number.isFinite);
    if (prices.length < 15) {
      return res.status(502).json({ error: 'Insufficient price history' });
    }
    const values = RSI.calculate({ period: 14, values: prices });
    const rsi = values.at(-1);
    const signal = rsi < 30 ? 'OVERSOLD WATCH' :
      rsi > 70 ? 'OVERBOUGHT WATCH' : 'NEUTRAL';
    res.json({
      coin, source: 'CoinGecko', indicator: 'RSI 14',
      rsi, signal, pricesUsed: prices.length,
      advisoryOnly: true, notFinancialAdvice: true,
      timestamp: new Date().toISOString()
    });
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

app.get('/api/market/capital/:symbol', async (req, res) => {
  const key = process.env.ALPHA_VANTAGE_API_KEY;
  if (!key) {
    return res.status(503).json({
      error: 'Capital-market provider key not configured',
      provider: 'Alpha Vantage'
    });
  }
  const symbol = String(req.params.symbol).toUpperCase();
  if (!/^[A-Z0-9.^_-]{1,20}$/.test(symbol)) {
    return res.status(400).json({ error: 'Invalid symbol' });
  }
  try {
    const url = new URL('https://www.alphavantage.co/query');
    url.search = new URLSearchParams({
      function: 'GLOBAL_QUOTE', symbol, apikey: key
    }).toString();
    const data = await getJSON(url);
    if (!data['Global Quote'] || !Object.keys(data['Global Quote']).length) {
      return res.status(502).json({ error: data.Note || data.Information || 'No quote returned' });
    }
    res.json({
      provider: 'Alpha Vantage',
      quote: data['Global Quote'],
      timestamp: new Date().toISOString()
    });
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

app.get('/api/market/blockchain/bitcoin', async (req, res) => {
  try {
    const getText = async (url) => {
      const r = await fetch(url, { signal: AbortSignal.timeout(timeout) });
      if (!r.ok) throw new Error(`Blockstream HTTP ${r.status}`);
      return (await r.text()).trim();
    };
    const [heightText, hash] = await Promise.all([
      getText('https://blockstream.info/api/blocks/tip/height'),
      getText('https://blockstream.info/api/blocks/tip/hash')
    ]);
    const height = Number(heightText);
    if (!Number.isSafeInteger(height) || !/^[a-f0-9]{64}$/i.test(hash)) {
      throw new Error('Invalid Bitcoin block response');
    }
    res.json({
      network: 'Bitcoin mainnet',
      latestBlockHeight: height,
      latestBlockHash: hash,
      source: 'Blockstream',
      timestamp: new Date().toISOString()
    });
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});


app.get('/api/market/providers', async (req, res) => {
  const check = async (name, url, validate) => {
    const started = Date.now();
    try {
      const response = await fetch(url, {
        signal: AbortSignal.timeout(timeout),
        headers: { accept: 'application/json,text/plain' }
      });

      const body = await response.text();
      const valid = response.ok && validate(body);

      return {
        provider: name,
        status: valid ? 'responding' : 'provider_error',
        httpStatus: response.status,
        latencyMs: Date.now() - started
      };
    } catch {
      return {
        provider: name,
        status: 'unavailable',
        latencyMs: Date.now() - started
      };
    }
  };

  const results = await Promise.all([
    check(
      'CoinGecko',
      'https://api.coingecko.com/api/v3/ping',
      body => {
        try {
          return typeof JSON.parse(body).gecko_says === 'string';
        } catch {
          return false;
        }
      }
    ),
    check(
      'Blockstream',
      'https://blockstream.info/api/blocks/tip/height',
      body => /^[0-9]+$/.test(body.trim())
    )
  ]);

  results.push({
    provider: 'Alpha Vantage',
    status: process.env.ALPHA_VANTAGE_API_KEY
      ? 'configured_not_tested'
      : 'not_configured'
  });

  res.json({
    service: 'Pilgrim Read-only Market Data',
    checkedAt: new Date().toISOString(),
    tradingEnabled: false,
    withdrawalsEnabled: false,
    providers: results
  });
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`Pilgrim market data listening at http://127.0.0.1:${PORT}`);
  console.log('Read-only mode: orders and withdrawals disabled.');
});
