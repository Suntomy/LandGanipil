# InstaTrade integration references

Official browser terminal:
https://www.insta.trade/webtrader

Official Client Cabinet API:
https://www.instatrade.com/client_cabinet_api

Official trading platform information:
https://www.insta.trade/trading_platform/webtrader

Documented account data includes balance, open trades, closed trades
and account summaries. Confirm available methods and access permissions
with InstaTrade before implementing any order execution.

Do not put broker passwords or API credentials in website JavaScript.
Do not enable live orders, withdrawals or interest credits without
verified authentication, permissions, execution and ledger controls.
