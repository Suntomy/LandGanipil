'use strict';

class BrokerAdapter {
  constructor(config = {}) {
    this.config = config;
    this.name = 'UNIMPLEMENTED';
  }

  async connect() {
    throw new Error('Broker connection is not implemented');
  }

  async getAccount() {
    throw new Error('Account data is not implemented');
  }

  async getPositions() {
    throw new Error('Position data is not implemented');
  }

  async getHistory() {
    throw new Error('Trade history is not implemented');
  }

  async placeOrder() {
    throw new Error('Order execution is disabled');
  }

  async closePosition() {
    throw new Error('Position closing is disabled');
  }

  async disconnect() {
    return { disconnected: true };
  }
}

module.exports = { BrokerAdapter };
