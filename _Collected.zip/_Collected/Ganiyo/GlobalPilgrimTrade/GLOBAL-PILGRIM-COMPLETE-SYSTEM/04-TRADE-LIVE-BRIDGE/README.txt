PILGRIM TRADING LIVE BROKER INTEGRATION

Supported broker targets:
1. HFM MT5
2. PU Prime MT5

Android Termux is for website development and diagnostics.
Actual official MetaTrader 5 Python integration requires
a compatible Windows MT5 terminal environment.

No broker credentials are stored in this project.
No orders are enabled.
No deposits or withdrawals are enabled.
No simulated profit is considered real profit.

Live operation requires:
- Correct broker account and server
- Authorised MT5 connection
- Secure backend
- Read-only connection verification
- Risk limits and order reconciliation
- Authorised payment provider
