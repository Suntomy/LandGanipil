const express = require("express");
const router = express.Router();
const engine = require("./live-engine");

router.get("/", async(req,res)=>{
 try {
  res.json(await engine.checkAll());
 } catch(e) {
  res.status(500).json({error:e.message});
 }
});

module.exports = router;
