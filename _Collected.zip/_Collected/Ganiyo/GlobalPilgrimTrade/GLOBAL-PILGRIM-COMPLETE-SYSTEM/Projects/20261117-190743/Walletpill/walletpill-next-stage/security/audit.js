'use strict';

async function recordAudit(pool, {
  actorId,
  action,
  referenceId = null,
  details = {}
}) {
  await pool.query(
    `INSERT INTO wp_security_audit
     (actor_id, action, reference_id, details, created_at)
     VALUES ($1, $2, $3, $4, NOW())`,
    [
      actorId || null,
      action,
      referenceId,
      JSON.stringify(details)
    ]
  );
}

module.exports = { recordAudit };
