'use strict';

const fs = require('fs');
const path = require('path');
const bip39 = require('bip39');
const { HDNodeWallet } = require('ethers');
const bitcoin = require('bitcoinjs-lib');
const ecc = require('tiny-secp256k1');
const { BIP32Factory } = require('bip32');
const { Keypair } = require('@solana/web3.js');
const { derivePath } = require('ed25519-hd-key');
const TronWeb = require('tronweb');

bitcoin.initEccLib(ecc);

const bip32 = BIP32Factory(ecc);
const DATA = path.join(__dirname, '../../data/deposit-addresses.json');

const PATHS = {
  BTC: "m/44'/0'/0'/0",
  LTC: "m/44'/2'/0'/0",
  ETH: "m/44'/60'/0'/0",
  USDT: "m/44'/195'/0'/0",
  SOL: "m/44'/501'/0'/0"
};

const networks = {
  BTC: bitcoin.networks.bitcoin,
  LTC: {
    messagePrefix: '\x19Litecoin Signed Message:\n',
    bech32: 'ltc',
    bip32: { public: 0x019da462, private: 0x019d9cfe },
    pubKeyHash: 0x30,
    scriptHash: 0x32,
    wif: 0xb0
  }
};

function readStore() {
  if (!fs.existsSync(DATA)) return {
    counters: {},
    addresses: [],
    deposits: []
  };

  return JSON.parse(fs.readFileSync(DATA, 'utf8'));
}

function saveStore(store) {
  const temp = DATA + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(store, null, 2), {
    mode: 0o600
  });
  fs.renameSync(temp, DATA);
}

function getPhrase() {
  const phrase = process.env.WALLET_MASTER_MNEMONIC;

  if (!phrase || !bip39.validateMnemonic(phrase)) {
    throw new Error(
      'A valid WALLET_MASTER_MNEMONIC must be configured privately.'
    );
  }

  return phrase;
}

async function generateAddress(asset, customerId) {
  asset = String(asset).toUpperCase();

  if (!PATHS[asset]) {
    throw new Error('Unsupported asset');
  }

  const store = readStore();
  const index = store.counters[asset] || 0;
  const phrase = getPhrase();
  const basePath = PATHS[asset];

  let address;

  if (asset === 'BTC' || asset === 'LTC') {
    const seed = await bip39.mnemonicToSeed(phrase);
    const root = bip32.fromSeed(seed, networks[asset]);
    const child = root.derivePath(`${basePath}/${index}`);
    const result = bitcoin.payments.p2pkh({
      pubkey: Buffer.from(child.publicKey),
      network: networks[asset]
    });
    address = result.address;
  }

  if (asset === 'ETH') {
    const wallet = HDNodeWallet.fromPhrase(
      phrase, '', `${basePath}/${index}`
    );
    address = wallet.address;
  }

  if (asset === 'USDT') {
    const wallet = HDNodeWallet.fromPhrase(
      phrase, '', `${basePath}/${index}`
    );

    const tron = new TronWeb({ fullHost: 'https://api.trongrid.io' });

    address = tron.address.fromPrivateKey(wallet.privateKey);
  }

  if (asset === 'SOL') {
    const seed = await bip39.mnemonicToSeed(phrase);
    const derived = derivePath(
      `${basePath}/${index}`,
      seed.toString('hex')
    );
    const keypair = Keypair.fromSeed(derived.key);
    address = keypair.publicKey.toBase58();
  }

  if (!address) {
    throw new Error('Address generation failed');
  }

  store.counters[asset] = index + 1;

  const record = {
    customerId: customerId || null,
    id: `${asset}-${index}`,
    asset,
    network: asset === 'USDT' ? 'TRON-TRC20' : asset,
    derivationIndex: index,
    address,
    createdAt: new Date().toISOString(),
    status: 'ACTIVE'
  };

  store.addresses.push(record);
  saveStore(store);

  return record;
}

function listAddresses() {
  return readStore().addresses;
}

function recordVerifiedDeposit(deposit) {
  const store = readStore();

  if (!deposit.txHash || !deposit.address ||
      !deposit.asset || !deposit.amount) {
    throw new Error('Incomplete deposit information');
  }

  const duplicate = store.deposits.some(
    item => item.txHash === deposit.txHash &&
            item.asset === deposit.asset
  );

  if (duplicate) {
    throw new Error('Duplicate transaction');
  }

  const record = {
    id: `DEP-${Date.now()}`,
    customerId: deposit.customerId,
    asset: deposit.asset,
    amount: String(deposit.amount),
    address: deposit.address,
    txHash: deposit.txHash,
    confirmations: deposit.confirmations || 0,
    status: 'PENDING_ADMIN_APPROVAL',
    createdAt: new Date().toISOString()
  };

  store.deposits.push(record);
  saveStore(store);

  return record;
}

function listPendingDeposits() {
  return readStore().deposits.filter(
    item => item.status === 'PENDING_ADMIN_APPROVAL'
  );
}

function reviewDeposit(id, decision, adminId) {
  if (!['APPROVED', 'REJECTED'].includes(decision)) {
    throw new Error('Invalid approval decision');
  }

  const store = readStore();
  const deposit = store.deposits.find(item => item.id === id);

  if (!deposit || deposit.status !== 'PENDING_ADMIN_APPROVAL') {
    throw new Error('Pending deposit not found');
  }

  deposit.status = decision;
  deposit.reviewedBy = adminId;
  deposit.reviewedAt = new Date().toISOString();

  saveStore(store);
  return deposit;
}

module.exports = {
  generateAddress,
  listAddresses,
  recordVerifiedDeposit,
  listPendingDeposits,
  reviewDeposit
};
