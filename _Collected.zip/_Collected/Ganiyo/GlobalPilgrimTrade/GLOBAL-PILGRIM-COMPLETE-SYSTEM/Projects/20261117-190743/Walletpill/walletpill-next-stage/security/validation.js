'use strict';

const crypto = require('crypto');

function validAsset(asset, assets) {
  return typeof asset === 'string' &&
    Object.prototype.hasOwnProperty.call(assets, asset.toUpperCase()) &&
    assets[asset.toUpperCase()].enabled;
}

function validAmount(value) {
  if (typeof value !== 'string' && typeof value !== 'number') {
    return false;
  }

  const amount = Number(value);
  return Number.isFinite(amount) && amount > 0;
}

function validTransactionId(value) {
  return typeof value === 'string' &&
    /^[a-fA-F0-9]{32,128}$/.test(value);
}

function requestId() {
  return crypto.randomUUID();
}

module.exports = {
  validAsset,
  validAmount,
  validTransactionId,
  requestId
};
