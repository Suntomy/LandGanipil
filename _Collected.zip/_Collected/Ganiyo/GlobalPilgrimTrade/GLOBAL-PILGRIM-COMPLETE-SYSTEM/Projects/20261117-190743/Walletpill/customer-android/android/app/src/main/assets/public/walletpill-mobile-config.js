(function () {
  window.WALLETPILL_MOBILE = {
    appName: "Walletpill Customer",
    platform: "android",
    apiBaseUrl: "https://CHANGE-TO-YOUR-WALLETPILL-DOMAIN",
    productionReady: false,
    realWithdrawalsEnabled: false
  };
})();
