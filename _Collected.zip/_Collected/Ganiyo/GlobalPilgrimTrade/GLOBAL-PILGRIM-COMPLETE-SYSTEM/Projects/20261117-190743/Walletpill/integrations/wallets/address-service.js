'use strict';

const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, 'receiving-addresses.json');

function loadAddresses() {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function getAllAddresses() {
  return loadAddresses();
}

function getAddress(symbol) {
  const addresses = loadAddresses();
  const coin = String(symbol).toUpperCase();

  if (!addresses[coin] || !addresses[coin].enabled) {
    throw new Error('Unsupported or disabled asset');
  }

  return addresses[coin];
}

module.exports = {
  getAllAddresses,
  getAddress
};
