'use strict';

const express = require('express');
const jwt = require('jsonwebtoken');

const router = express.Router();

const wallet = require('./wallets/hd-wallet');
const health = require('./health');

function authenticate(req, res, next) {
  const secret = process.env.JWT_SECRET;

  if (!secret) {
    return res.status(503).json({
      success: false,
      message: 'Authentication secret is not configured.'
    });
  }

  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ')
    ? header.slice(7)
    : null;

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required.'
    });
  }

  try {
    req.user = jwt.verify(token, secret);

    if (!req.user.sub) {
      throw new Error('Missing user identity');
    }

    next();
  } catch {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired authentication token.'
    });
  }
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Administrator permission required.'
    });
  }

  next();
}

// Public service health information. No secrets are returned.
router.get('/integrations/status', (req, res) => {
  res.json(health.getIntegrationStatus());
});

// Authenticated customer: generate a fresh deposit address.
router.post(
  '/wallets/:asset/deposit-address',
  authenticate,
  async (req, res) => {
    try {
      const result = await wallet.generateAddress(
        req.params.asset,
        String(req.user.sub)
      );

      res.status(201).json({
        success: true,
        message: 'New receiving address generated.',
        wallet: result
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
);

// Customer sees only their own generated addresses.
router.get('/wallets/addresses', authenticate, (req, res) => {
  const all = wallet.listAddresses();

  const result = req.user.role === 'admin'
    ? all
    : all.filter(
        item => String(item.customerId) === String(req.user.sub)
      );

  res.json({
    success: true,
    addresses: result
  });
});

// Administrator: view pending deposits.
router.get(
  '/admin/deposits/pending',
  authenticate,
  adminOnly,
  (req, res) => {
    res.json({
      success: true,
      deposits: wallet.listPendingDeposits()
    });
  }
);

// Approval cannot credit a balance until a real database ledger
// and atomic credit operation have been connected.
router.post(
  '/admin/deposits/:id/review',
  authenticate,
  adminOnly,
  (req, res) => {
    const decision = String(req.body.decision || '').toUpperCase();

    if (decision === 'APPROVED') {
      return res.status(503).json({
        success: false,
        message: 'Deposit approval and balance credit require the database ledger and verified blockchain confirmation service.'
      });
    }

    if (decision !== 'REJECTED') {
      return res.status(400).json({
        success: false,
        message: 'Decision must be APPROVED or REJECTED.'
      });
    }

    try {
      const result = wallet.reviewDeposit(
        req.params.id,
        'REJECTED',
        String(req.user.sub)
      );

      res.json({
        success: true,
        deposit: result
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
);

module.exports = router;
