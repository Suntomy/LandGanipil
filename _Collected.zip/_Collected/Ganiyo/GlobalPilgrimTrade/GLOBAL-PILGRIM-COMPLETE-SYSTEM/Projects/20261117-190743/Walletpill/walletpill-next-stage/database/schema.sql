
CREATE TABLE IF NOT EXISTS wp_chain_deposit_events (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    asset VARCHAR(20) NOT NULL,
    amount NUMERIC(38,18) NOT NULL CHECK (amount > 0),
    transaction_id VARCHAR(150) NOT NULL,
    network VARCHAR(80) NOT NULL,
    confirmations INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(network, transaction_id)
);

CREATE TABLE IF NOT EXISTS wp_withdrawal_requests (
    id BIGSERIAL PRIMARY KEY,
    reference UUID NOT NULL UNIQUE,
    customer_id BIGINT NOT NULL,
    asset VARCHAR(20) NOT NULL,
    amount NUMERIC(38,18) NOT NULL CHECK (amount > 0),
    destination VARCHAR(200) NOT NULL,
    network VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING_REVIEW',
    blockchain_transaction_id VARCHAR(150),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS wp_security_audit (
    id BIGSERIAL PRIMARY KEY,
    actor_id BIGINT,
    action VARCHAR(100) NOT NULL,
    reference_id VARCHAR(150),
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS wp_deposits_customer_idx
ON wp_chain_deposit_events(customer_id);

CREATE INDEX IF NOT EXISTS wp_withdrawals_customer_idx
ON wp_withdrawal_requests(customer_id);

CREATE INDEX IF NOT EXISTS wp_audit_created_idx
ON wp_security_audit(created_at DESC);

