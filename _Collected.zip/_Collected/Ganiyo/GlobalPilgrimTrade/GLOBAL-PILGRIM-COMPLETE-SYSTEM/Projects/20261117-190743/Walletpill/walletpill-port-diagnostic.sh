#!/data/data/com.termux/files/usr/bin/bash

echo "======================================"
echo " WALLETPILL PORT CONFLICT DIAGNOSTIC"
echo "======================================"

echo
echo "[1] ALL PM2 PROCESSES"
npx --no-install pm2 status

echo
echo "[2] PM2 PROCESS DETAILS"
npx --no-install pm2 jlist | node -e '
let s="";
process.stdin.on("data",d=>s+=d);
process.stdin.on("end",()=>{
 try {
  for(const p of JSON.parse(s)) {
   console.log({
    id:p.pm_id,
    name:p.name,
    status:p.pm2_env.status,
    script:p.pm2_env.pm_exec_path,
    cwd:p.pm2_env.pm_cwd,
    restarts:p.pm2_env.restart_time
   });
  }
 } catch(e) { console.log("Could not parse PM2 list:",e.message); }
});
'

echo
echo "[3] PORT 3000 OWNER"
if command -v ss >/dev/null 2>&1; then
  ss -ltnp 2>&1 | grep ':3000' || echo "No listener shown."
fi

if command -v fuser >/dev/null 2>&1; then
  fuser -v -n tcp 3000 2>&1 || true
fi

echo
echo "[4] SERVER LISTEN COMMANDS"
grep -nE 'app\.listen|server\.listen|\.listen\(' server.js

echo
echo "[5] HEALTH CHECK"
curl -i --max-time 5 http://127.0.0.1:3000/api/health 2>&1

echo
echo "======================================"
echo "DIAGNOSTIC COMPLETE"
echo "======================================"
