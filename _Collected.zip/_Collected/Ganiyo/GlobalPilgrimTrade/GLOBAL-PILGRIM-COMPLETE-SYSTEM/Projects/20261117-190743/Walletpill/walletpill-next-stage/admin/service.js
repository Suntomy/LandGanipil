'use strict';

const { recordAudit } = require('../security/audit');

async function getSystemOverview(pool) {
  const [deposits, withdrawals, audit] = await Promise.all([
    pool.query(
      `SELECT status, COUNT(*)::int AS total
       FROM wp_chain_deposit_events GROUP BY status`
    ),
    pool.query(
      `SELECT status, COUNT(*)::int AS total
       FROM wp_withdrawal_requests GROUP BY status`
    ),
    pool.query(
      `SELECT COUNT(*)::int AS total
       FROM wp_security_audit`
    )
  ]);

  return {
    deposits: deposits.rows,
    withdrawals: withdrawals.rows,
    auditEvents: audit.rows[0].total
  };
}

async function logAdminAction(pool, adminId, action, referenceId, details) {
  return recordAudit(pool, {
    actorId: adminId,
    action,
    referenceId,
    details
  });
}

module.exports = {
  getSystemOverview,
  logAdminAction
};
