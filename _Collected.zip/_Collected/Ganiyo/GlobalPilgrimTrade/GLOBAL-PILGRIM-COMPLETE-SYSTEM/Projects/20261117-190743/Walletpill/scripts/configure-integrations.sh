#!/data/data/com.termux/files/usr/bin/bash

set -e

cd ~/Walletpill || exit 1

echo "========================================"
echo " WALLETPILL BLOCKCHAIN & PAYMENT SETUP"
echo "========================================"

# Back up existing integration files
BACKUP="backups/integrations-$(date +%Y%m%d-%H%M%S).tar.gz"

tar -czf "$BACKUP" \
    integrations .env.integrations.example \
    2>/dev/null || true

echo "Backup: $BACKUP"

# ------------------------------------------------
# CENTRAL CONFIGURATION
# ------------------------------------------------

cat > integrations/config/index.js <<'EOF'
'use strict';

const enabled = value => String(value).toLowerCase() === 'true';

module.exports = {
  app: {
    name: 'Walletpill',
    environment: process.env.NODE_ENV || 'development'
  },

  security: {
    realWithdrawalsEnabled: enabled(process.env.ENABLE_WITHDRAWALS),
    realDepositsEnabled: enabled(process.env.ENABLE_REAL_DEPOSITS),
    requireWithdrawalApproval: true
  },

  blockchain: {
    bitcoin: {
      enabled: enabled(process.env.BTC_ENABLED),
      network: process.env.BTC_NETWORK || 'testnet',
      rpcUrl: process.env.BTC_RPC_URL || ''
    },

    ethereum: {
      enabled: enabled(process.env.ETH_ENABLED),
      network: process.env.ETH_NETWORK || 'sepolia',
      rpcUrl: process.env.ETH_RPC_URL || ''
    },

    litecoin: {
      enabled: enabled(process.env.LTC_ENABLED),
      network: process.env.LTC_NETWORK || 'testnet',
      rpcUrl: process.env.LTC_RPC_URL || ''
    },

    dogecoin: {
      enabled: enabled(process.env.DOGE_ENABLED),
      network: process.env.DOGE_NETWORK || 'testnet',
      rpcUrl: process.env.DOGE_RPC_URL || ''
    },

    solana: {
      enabled: enabled(process.env.SOL_ENABLED),
      network: process.env.SOL_NETWORK || 'devnet',
      rpcUrl: process.env.SOL_RPC_URL || ''
    },

    pilgrimCoin: {
      enabled: enabled(process.env.PGC_ENABLED),
      network: process.env.PGC_NETWORK || 'development',
      rpcUrl: process.env.PGC_RPC_URL || '',
      chainId: process.env.PGC_CHAIN_ID || '',
      contractAddress: process.env.PGC_CONTRACT_ADDRESS || ''
    }
  },

  payments: {
    flutterwave: {
      enabled: enabled(process.env.FLUTTERWAVE_ENABLED),
      secretKey: process.env.FLUTTERWAVE_SECRET_KEY || '',
      publicKey: process.env.FLUTTERWAVE_PUBLIC_KEY || ''
    },

    paystack: {
      enabled: enabled(process.env.PAYSTACK_ENABLED),
      secretKey: process.env.PAYSTACK_SECRET_KEY || '',
      publicKey: process.env.PAYSTACK_PUBLIC_KEY || ''
    },

    stripe: {
      enabled: enabled(process.env.STRIPE_ENABLED),
      secretKey: process.env.STRIPE_SECRET_KEY || '',
      publicKey: process.env.STRIPE_PUBLIC_KEY || ''
    }
  }
};
EOF

# ------------------------------------------------
# BLOCKCHAIN REGISTRY
# ------------------------------------------------

cat > integrations/blockchains/index.js <<'EOF'
'use strict';

const config = require('../config');

const networks = config.blockchain;

function listNetworks() {
  return Object.entries(networks).map(([name, item]) => ({
    name,
    enabled: item.enabled,
    network: item.network,
    configured: Boolean(item.rpcUrl),
    rpcConfigured: Boolean(item.rpcUrl),
    withdrawalReady: false
  }));
}

function getNetwork(name) {
  const network = networks[name];

  if (!network) {
    throw new Error(`Unsupported blockchain: ${name}`);
  }

  return network;
}

async function checkRpc(name) {
  const network = getNetwork(name);

  if (!network.enabled || !network.rpcUrl) {
    return {
      network: name,
      status: 'NOT_CONFIGURED'
    };
  }

  try {
    const response = await fetch(network.rpcUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_chainId',
        params: []
      }),
      signal: AbortSignal.timeout(8000)
    });

    const data = await response.json();

    return {
      network: name,
      status: response.ok && !data.error ? 'RESPONDING' : 'RPC_ERROR',
      result: data.result || null,
      error: data.error?.message || null
    };
  } catch (error) {
    return {
      network: name,
      status: 'CONNECTION_FAILED',
      error: error.message
    };
  }
}

module.exports = {
  listNetworks,
  getNetwork,
  checkRpc
};
EOF

# ------------------------------------------------
# PAYMENT PROVIDER REGISTRY
# ------------------------------------------------

cat > integrations/payments/index.js <<'EOF'
'use strict';

const config = require('../config');

function listProviders() {
  return Object.entries(config.payments).map(([name, provider]) => ({
    name,
    enabled: provider.enabled,
    credentialsConfigured: Boolean(provider.secretKey),
    status: provider.enabled && provider.secretKey
      ? 'CONFIGURED'
      : 'NOT_CONFIGURED'
  }));
}

function getProvider(name) {
  const provider = config.payments[name];

  if (!provider) {
    throw new Error(`Unsupported payment provider: ${name}`);
  }

  return provider;
}

function requireProvider(name) {
  const provider = getProvider(name);

  if (!provider.enabled || !provider.secretKey) {
    throw new Error(`${name} is not configured or enabled`);
  }

  return provider;
}

module.exports = {
  listProviders,
  getProvider,
  requireProvider
};
EOF

# ------------------------------------------------
# INTEGRATION HEALTH CHECK
# ------------------------------------------------

cat > integrations/health.js <<'EOF'
'use strict';

const config = require('./config');
const chains = require('./blockchains');
const payments = require('./payments');

function getIntegrationStatus() {
  return {
    application: config.app.name,
    environment: config.app.environment,
    security: {
      realWithdrawalsEnabled:
        config.security.realWithdrawalsEnabled,
      realDepositsEnabled:
        config.security.realDepositsEnabled,
      withdrawalApprovalRequired:
        config.security.requireWithdrawalApproval
    },
    blockchains: chains.listNetworks(),
    paymentProviders: payments.listProviders()
  };
}

module.exports = { getIntegrationStatus };
EOF

# ------------------------------------------------
# ENVIRONMENT TEMPLATE
# ------------------------------------------------

cat > .env.integrations.example <<'EOF'
# Copy the required values into your private .env file.
# Never publish your real .env file.

NODE_ENV=development

# Keep real-money functions disabled until tested.
ENABLE_WITHDRAWALS=false
ENABLE_REAL_DEPOSITS=false

# BITCOIN
BTC_ENABLED=false
BTC_NETWORK=testnet
BTC_RPC_URL=

# ETHEREUM
ETH_ENABLED=false
ETH_NETWORK=sepolia
ETH_RPC_URL=

# LITECOIN
LTC_ENABLED=false
LTC_NETWORK=testnet
LTC_RPC_URL=

# DOGECOIN
DOGE_ENABLED=false
DOGE_NETWORK=testnet
DOGE_RPC_URL=

# SOLANA
SOL_ENABLED=false
SOL_NETWORK=devnet
SOL_RPC_URL=

# PILGRIM COIN
PGC_ENABLED=false
PGC_NETWORK=development
PGC_RPC_URL=
PGC_CHAIN_ID=
PGC_CONTRACT_ADDRESS=

# FLUTTERWAVE
FLUTTERWAVE_ENABLED=false
FLUTTERWAVE_PUBLIC_KEY=
FLUTTERWAVE_SECRET_KEY=

# PAYSTACK
PAYSTACK_ENABLED=false
PAYSTACK_PUBLIC_KEY=
PAYSTACK_SECRET_KEY=

# STRIPE
STRIPE_ENABLED=false
STRIPE_PUBLIC_KEY=
STRIPE_SECRET_KEY=
EOF

# ------------------------------------------------
# TEST SCRIPT
# ------------------------------------------------

cat > scripts/test-integrations.js <<'EOF'
'use strict';

require('dotenv').config();

const config = require('../integrations/config');
const chains = require('../integrations/blockchains');
const payments = require('../integrations/payments');
const health = require('../integrations/health');

console.log('\n========== WALLETPILL INTEGRATIONS ==========\n');

console.log('Application:', config.app.name);
console.log('Environment:', config.app.environment);

console.log('\nBLOCKCHAIN NETWORKS');
console.table(chains.listNetworks());

console.log('\nPAYMENT PROVIDERS');
console.table(payments.listProviders());

console.log('\nSECURITY');
console.log({
  realWithdrawalsEnabled:
    config.security.realWithdrawalsEnabled,
  realDepositsEnabled:
    config.security.realDepositsEnabled
});

console.log('\nFULL STATUS');
console.log(JSON.stringify(health.getIntegrationStatus(), null, 2));

console.log('\nConfiguration test completed.');
EOF

# ------------------------------------------------
# DOCUMENTATION
# ------------------------------------------------

cat > integrations/README.md <<'EOF'
# Walletpill Blockchain and Payment Integrations

## Supported blockchain configurations

- Bitcoin
- Ethereum
- Litecoin
- Dogecoin
- Solana
- Pilgrim Coin (PGC)

## Supported payment provider configurations

- Flutterwave
- Paystack
- Stripe

## Configuration

Copy .env.integrations.example values into your private .env file.

Set RPC URLs and credentials only from the official provider dashboards.

## Test configuration

Run:

node scripts/test-integrations.js

## Important

This package provides configuration and provider registries.
It does not independently implement blockchain signing,
broadcast transactions, payment verification or withdrawals.

Production transactions require:
- Verified RPC/network configuration.
- Secure wallet signing.
- Address validation.
- Transaction fee calculation.
- Blockchain confirmation monitoring.
- Payment-provider webhook signature verification.
- Idempotency and duplicate-payment protection.
- Database ledger entries and reconciliation.
- Authentication, authorization and audit logs.

Real withdrawals are disabled by default.
Do not store private keys in frontend JavaScript.
EOF

# ------------------------------------------------
# CHECK FILES
# ------------------------------------------------

echo
echo "Checking JavaScript syntax..."

node --check integrations/config/index.js
node --check integrations/blockchains/index.js
node --check integrations/payments/index.js
node --check integrations/health.js
node --check scripts/test-integrations.js

echo
echo "========================================"
echo " INTEGRATION CONFIGURATION INSTALLED"
echo "========================================"
echo
echo "Run the configuration test with:"
echo "node scripts/test-integrations.js"
echo
echo "Read:"
echo "integrations/README.md"
echo
echo "Real withdrawals remain disabled."
