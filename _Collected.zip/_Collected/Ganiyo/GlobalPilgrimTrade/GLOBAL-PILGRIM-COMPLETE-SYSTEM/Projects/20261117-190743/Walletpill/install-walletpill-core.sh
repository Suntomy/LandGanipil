#!/data/data/com.termux/files/usr/bin/bash
set -e

cd "$HOME/Walletpill" || exit 1

echo "=========================================="
echo " WALLETPILL DATABASE AND LEDGER INSTALLER"
echo "=========================================="

mkdir -p core database scripts reports

echo "[1/8] Installing required packages..."
npm install pg bcryptjs jsonwebtoken dotenv

echo "[2/8] Backing up existing server..."
cp server.js "server.js.backup.$(date +%Y%m%d%H%M%S)"

# Safely set a .env value without printing secrets.
set_env() {
  ENV_KEY="$1" ENV_VALUE="$2" node <<'NODE'
const fs = require("fs");
const key = process.env.ENV_KEY;
const value = JSON.stringify(process.env.ENV_VALUE);
const file = ".env";
let content = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
const line = `${key}=${value}`;
const re = new RegExp(`^${key}=.*$`, "m");
if (re.test(content)) content = content.replace(re, line);
else content += (content.endsWith("\n") || !content ? "" : "\n") + line + "\n";
fs.writeFileSync(file, content, { mode: 0o600 });
NODE
}

touch .env
chmod 600 .env

echo
echo "PostgreSQL connection"
echo "Example: postgresql://username:password@host:5432/database"
read -r -p "Enter your PostgreSQL DATABASE_URL: " DB_URL

if [ -z "$DB_URL" ]; then
  echo "DATABASE_URL is required. Installer stopped."
  exit 1
fi

read -r -p "Administrator email: " ADMIN_EMAIL
if [ -z "$ADMIN_EMAIL" ]; then
  echo "Administrator email is required."
  exit 1
fi

read -r -s -p "Create administrator password (minimum 12 characters): " ADMIN_PASSWORD
echo

if [ "${#ADMIN_PASSWORD}" -lt 12 ]; then
  echo "Password must contain at least 12 characters."
  exit 1
fi

JWT_SECRET="$(openssl rand -hex 48)"
WORKER_TOKEN="$(openssl rand -hex 32)"

set_env DATABASE_URL "$DB_URL"
set_env ADMIN_EMAIL "$ADMIN_EMAIL"
set_env ADMIN_PASSWORD "$ADMIN_PASSWORD"
set_env JWT_SECRET "$JWT_SECRET"
set_env BLOCKCHAIN_WORKER_TOKEN "$WORKER_TOKEN"
set_env ENABLE_WITHDRAWALS "false"
set_env ENABLE_REAL_DEPOSITS "false"

unset DB_URL ADMIN_PASSWORD JWT_SECRET WORKER_TOKEN

echo "[3/8] Creating PostgreSQL database schema..."

cat > database/schema.sql <<'SQL'
CREATE TABLE IF NOT EXISTS customers (
    id BIGSERIAL PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'customer'
        CHECK (role IN ('customer', 'admin')),
    status TEXT NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'SUSPENDED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallet_accounts (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL REFERENCES customers(id),
    asset VARCHAR(20) NOT NULL,
    balance NUMERIC(36,18) NOT NULL DEFAULT 0
        CHECK (balance >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(customer_id, asset)
);

CREATE TABLE IF NOT EXISTS deposits (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL REFERENCES customers(id),
    asset VARCHAR(20) NOT NULL,
    network VARCHAR(40) NOT NULL,
    tx_hash TEXT NOT NULL,
    amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
    status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (status IN (
            'PENDING', 'CONFIRMED', 'APPROVED', 'REJECTED'
        )),
    confirmations INTEGER NOT NULL DEFAULT 0,
    required_confirmations INTEGER NOT NULL DEFAULT 1,
    blockchain_verified BOOLEAN NOT NULL DEFAULT FALSE,
    verified_at TIMESTAMPTZ,
    approved_by BIGINT REFERENCES customers(id),
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(network, asset, tx_hash)
);

CREATE TABLE IF NOT EXISTS ledger_transactions (
    id BIGSERIAL PRIMARY KEY,
    account_id BIGINT NOT NULL REFERENCES wallet_accounts(id),
    customer_id BIGINT NOT NULL REFERENCES customers(id),
    asset VARCHAR(20) NOT NULL,
    transaction_type TEXT NOT NULL,
    direction TEXT NOT NULL CHECK (direction IN ('CREDIT', 'DEBIT')),
    amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
    balance_after NUMERIC(36,18) NOT NULL,
    reference TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_deposits_status
    ON deposits(status);

CREATE INDEX IF NOT EXISTS idx_ledger_customer
    ON ledger_transactions(customer_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ledger_account
    ON ledger_transactions(account_id, created_at DESC);
SQL

echo "[4/8] Creating PostgreSQL connection..."

cat > core/db.js <<'JS'
const { Pool } = require("pg");

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is missing from .env");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true"
    ? {
        rejectUnauthorized:
          process.env.DATABASE_SSL_REJECT_UNAUTHORIZED !== "false"
      }
    : undefined,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

pool.on("error", err => {
  console.error("PostgreSQL pool error:", err.message);
});

module.exports = pool;
JS

echo "[5/8] Creating authentication and ledger routes..."

cat > core/routes.js <<'JS'
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const pool = require("./db");

const router = express.Router();

const ASSETS = ["BTC", "ETH", "USDT", "SOL", "LTC", "DOGE", "PGC"];

function makeToken(user) {
  if (!process.env.JWT_SECRET) {
    throw new Error("JWT_SECRET is not configured");
  }

  return jwt.sign(
    { sub: String(user.id), role: user.role, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: "12h" }
  );
}

function authRequired(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ")
    ? header.slice(7)
    : "";

  if (!token) {
    return res.status(401).json({ error: "Authentication required" });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

function customerOnly(req, res, next) {
  if (req.user.role !== "customer") {
    return res.status(403).json({ error: "Customer access required" });
  }
  next();
}

function adminOnly(req, res, next) {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Administrator access required" });
  }
  next();
}

function workerOnly(req, res, next) {
  const supplied = req.headers["x-blockchain-worker-token"] || "";
  const expected = process.env.BLOCKCHAIN_WORKER_TOKEN || "";

  const a = Buffer.from(String(supplied));
  const b = Buffer.from(String(expected));

  if (!expected || a.length !== b.length ||
      !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Worker authentication failed" });
  }
  next();
}

function validAmount(value) {
  return typeof value === "string" &&
    /^(?:0|[1-9]\d{0,17})(?:\.\d{1,18})?$/.test(value) &&
    Number(value) > 0;
}

async function getOrCreateAccount(client, customerId, asset) {
  const result = await client.query(
    `INSERT INTO wallet_accounts(customer_id, asset)
     VALUES($1, $2)
     ON CONFLICT(customer_id, asset)
     DO UPDATE SET asset = EXCLUDED.asset
     RETURNING *`,
    [customerId, asset]
  );
  return result.rows[0];
}

// CUSTOMER REGISTRATION
router.post("/auth/register", async (req, res) => {
  try {
    const { email, password, fullName } = req.body || {};

    if (!email || !password || !fullName ||
        String(password).length < 10) {
      return res.status(400).json({
        error: "Email, full name and password (minimum 10 characters) required"
      });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const passwordHash = await bcrypt.hash(String(password), 12);

    const result = await pool.query(
      `INSERT INTO customers(email, password_hash, full_name)
       VALUES($1, $2, $3)
       RETURNING id, email, full_name, role`,
      [normalizedEmail, passwordHash, String(fullName).trim()]
    );

    const user = result.rows[0];

    res.status(201).json({
      success: true,
      customer: user,
      token: makeToken(user)
    });
  } catch (err) {
    if (err.code === "23505") {
      return res.status(409).json({ error: "Email already registered" });
    }
    console.error(err);
    res.status(500).json({ error: "Registration failed" });
  }
});

// CUSTOMER LOGIN
router.post("/auth/login", async (req, res) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");

    const result = await pool.query(
      `SELECT id, email, full_name, role, status, password_hash
       FROM customers WHERE email = $1`,
      [email]
    );

    const user = result.rows[0];

    if (!user || user.role !== "customer" ||
        user.status !== "ACTIVE" ||
        !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Invalid login details" });
    }

    res.json({
      success: true,
      customer: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        role: user.role
      },
      token: makeToken(user)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

// SEPARATE ADMINISTRATOR LOGIN
router.post("/admin/login", async (req, res) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");

    const result = await pool.query(
      `SELECT id, email, full_name, role, status, password_hash
       FROM customers WHERE email = $1 AND role = 'admin'`,
      [email]
    );

    const user = result.rows[0];

    if (!user || user.status !== "ACTIVE" ||
        !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Invalid administrator login" });
    }

    res.json({
      success: true,
      administrator: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        role: user.role
      },
      token: makeToken(user)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Administrator login failed" });
  }
});

// CUSTOMER WALLET BALANCES
router.get("/customer/balances",
  authRequired, customerOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT asset, balance
         FROM wallet_accounts
         WHERE customer_id = $1
         ORDER BY asset`,
        [req.user.sub]
      );
      res.json({ success: true, balances: result.rows });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Could not load balances" });
    }
  }
);

// CUSTOMER TRANSACTION HISTORY
router.get("/customer/ledger",
  authRequired, customerOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT id, asset, transaction_type, direction,
                amount, balance_after, reference, description, created_at
         FROM ledger_transactions
         WHERE customer_id = $1
         ORDER BY created_at DESC
         LIMIT 200`,
        [req.user.sub]
      );
      res.json({ success: true, transactions: result.rows });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Could not load ledger" });
    }
  }
);

// CUSTOMER SUBMITS A DEPOSIT TRANSACTION FOR VERIFICATION.
// This does NOT credit a wallet.
router.post("/customer/deposit-intents",
  authRequired, customerOnly, async (req, res) => {
    try {
      const { asset, network, txHash, amount } = req.body || {};
      const cleanAsset = String(asset || "").toUpperCase();

      if (!ASSETS.includes(cleanAsset) || !network ||
          !txHash || !validAmount(String(amount || ""))) {
        return res.status(400).json({
          error: "Valid asset, network, transaction hash and amount required"
        });
      }

      const result = await pool.query(
        `INSERT INTO deposits
          (customer_id, asset, network, tx_hash, amount)
         VALUES($1, $2, $3, $4, $5)
         RETURNING id, asset, network, tx_hash, amount, status, created_at`,
        [req.user.sub, cleanAsset, String(network), String(txHash), String(amount)]
      );

      res.status(201).json({
        success: true,
        message: "Deposit submitted. Awaiting independent blockchain verification.",
        deposit: result.rows[0]
      });
    } catch (err) {
      if (err.code === "23505") {
        return res.status(409).json({
          error: "This transaction has already been submitted"
        });
      }
      console.error(err);
      res.status(500).json({ error: "Deposit submission failed" });
    }
  }
);

// TRUSTED BLOCKCHAIN SCANNER ONLY.
// Scanner must independently verify chain, network, asset, hash,
// destination address, amount and required confirmations before calling.
router.post("/internal/deposits/confirm",
  workerOnly, async (req, res) => {
    try {
      const {
        depositId, txHash, asset, network,
        amount, confirmations, requiredConfirmations,
        destinationVerified
      } = req.body || {};

      if (!depositId || !txHash || !asset || !network ||
          !validAmount(String(amount || "")) ||
          !Number.isInteger(confirmations) ||
          !Number.isInteger(requiredConfirmations) ||
          requiredConfirmations < 1 ||
          confirmations < requiredConfirmations ||
          destinationVerified !== true) {
        return res.status(400).json({
          error: "Complete verified blockchain evidence is required"
        });
      }

      const result = await pool.query(
        `UPDATE deposits
         SET status = 'CONFIRMED',
             confirmations = $1,
             required_confirmations = $2,
             blockchain_verified = TRUE,
             verified_at = NOW()
         WHERE id = $3
           AND tx_hash = $4
           AND UPPER(asset) = UPPER($5)
           AND network = $6
           AND amount = $7
           AND status = 'PENDING'
         RETURNING id, status, confirmations, required_confirmations`,
        [
          confirmations, requiredConfirmations, depositId,
          txHash, asset, network, amount
        ]
      );

      if (!result.rowCount) {
        return res.status(409).json({
          error: "Deposit not found, mismatched or not pending"
        });
      }

      res.json({ success: true, deposit: result.rows[0] });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Deposit verification update failed" });
    }
  }
);

// ADMIN: VIEW DEPOSITS
router.get("/admin/deposits",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT d.*, c.email AS customer_email
         FROM deposits d
         JOIN customers c ON c.id = d.customer_id
         ORDER BY d.created_at DESC
         LIMIT 300`
      );
      res.json({ success: true, deposits: result.rows });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Could not load deposits" });
    }
  }
);

// ADMIN APPROVAL: ATOMIC, ONE-TIME LEDGER CREDIT.
router.post("/admin/deposits/:id/approve",
  authRequired, adminOnly, async (req, res) => {
    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      const found = await client.query(
        `SELECT * FROM deposits WHERE id = $1 FOR UPDATE`,
        [req.params.id]
      );

      const deposit = found.rows[0];

      if (!deposit) {
        await client.query("ROLLBACK");
        return res.status(404).json({ error: "Deposit not found" });
      }

      if (deposit.status !== "CONFIRMED" ||
          deposit.blockchain_verified !== true ||
          deposit.confirmations < deposit.required_confirmations) {
        await client.query("ROLLBACK");
        return res.status(409).json({
          error: "Deposit cannot be approved before blockchain confirmation"
        });
      }

      const account = await getOrCreateAccount(
        client, deposit.customer_id, deposit.asset
      );

      const locked = await client.query(
        `SELECT * FROM wallet_accounts WHERE id = $1 FOR UPDATE`,
        [account.id]
      );

      const oldBalance = locked.rows[0].balance;
      const newBalance = (
        BigInt(Math.round(Number(oldBalance) * 1e8)) +
        BigInt(Math.round(Number(deposit.amount) * 1e8))
      );

      // Use PostgreSQL numeric arithmetic for the actual stored balance.
      const updated = await client.query(
        `UPDATE wallet_accounts
         SET balance = balance + $1
         WHERE id = $2
         RETURNING balance`,
        [deposit.amount, account.id]
      );

      const reference =
        `DEPOSIT-${deposit.network}-${deposit.asset}-${deposit.tx_hash}`;

      await client.query(
        `INSERT INTO ledger_transactions
          (account_id, customer_id, asset, transaction_type,
           direction, amount, balance_after, reference, description)
         VALUES($1, $2, $3, 'BLOCKCHAIN_DEPOSIT',
                'CREDIT', $4, $5, $6, $7)`,
        [
          account.id, deposit.customer_id, deposit.asset,
          deposit.amount, updated.rows[0].balance, reference,
          `Confirmed blockchain deposit: ${deposit.tx_hash}`
        ]
      );

      await client.query(
        `UPDATE deposits
         SET status = 'APPROVED', approved_by = $1, approved_at = NOW()
         WHERE id = $2`,
        [req.user.sub, deposit.id]
      );

      await client.query("COMMIT");

      res.json({
        success: true,
        message: "Confirmed deposit credited to customer wallet",
        asset: deposit.asset,
        creditedAmount: deposit.amount,
        newBalance: updated.rows[0].balance,
        ledgerReference: reference
      });
    } catch (err) {
      await client.query("ROLLBACK").catch(() => {});
      if (err.code === "23505") {
        return res.status(409).json({
          error: "This deposit has already been credited"
        });
      }
      console.error(err);
      res.status(500).json({ error: "Deposit approval failed" });
    } finally {
      client.release();
    }
  }
);

module.exports = router;
JS

echo "[6/8] Creating database migration and administrator setup..."

cat > scripts/setup-walletpill-core.js <<'JS'
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const pool = require("../core/db");

async function main() {
  const schema = fs.readFileSync(
    path.join(__dirname, "../database/schema.sql"),
    "utf8"
  );

  await pool.query(schema);
  console.log("PostgreSQL schema installed.");

  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";

  if (!email || password.length < 12) {
    throw new Error("ADMIN_EMAIL or ADMIN_PASSWORD is missing/invalid");
  }

  const hash = await bcrypt.hash(password, 12);

  const result = await pool.query(
    `INSERT INTO customers(email, password_hash, full_name, role)
     VALUES($1, $2, 'Walletpill Administrator', 'admin')
     ON CONFLICT(email) DO NOTHING
     RETURNING id, email, role`,
    [email, hash]
  );

  if (result.rowCount) {
    console.log("Initial administrator account created.");
  } else {
    console.log("Administrator email already exists; existing password retained.");
  }

  const check = await pool.query("SELECT NOW() AS database_time");
  console.log("Database connection successful:", check.rows[0].database_time);

  await pool.end();
}

main().catch(async err => {
  console.error("SETUP FAILED:", err.message);
  await pool.end().catch(() => {});
  process.exit(1);
});
JS

echo "[7/8] Connecting the routes to server.js..."

node <<'NODE'
const fs = require("fs");
const file = "server.js";
let source = fs.readFileSync(file, "utf8");
const mount = 'app.use("/api/core", require("./core/routes"));';

if (!source.includes(mount)) {
  const anchor = 'app.get("/",';
  if (!source.includes(anchor)) {
    throw new Error("Could not find server.js insertion point. No route mount added.");
  }
  source = source.replace(anchor, mount + "\n\n" + anchor);
  fs.writeFileSync(file, source);
}
console.log("Core routes mounted at /api/core");
NODE

echo "[8/8] Checking JavaScript syntax..."

node --check server.js
node --check core/db.js
node --check core/routes.js
node --check scripts/setup-walletpill-core.js

echo
echo "Running PostgreSQL migration and admin setup..."
node scripts/setup-walletpill-core.js

cat > reports/WALLETPILL_CORE_STATUS.txt <<'REPORT'
WALLETPILL CORE INSTALLATION

Installed:
- PostgreSQL connection pool
- Customer registration and login
- Administrator login
- JWT authentication
- Customer wallet balance endpoint
- Customer transaction ledger endpoint
- Deposit intent records
- Trusted blockchain-worker confirmation endpoint
- Atomic administrator deposit approval
- Duplicate transaction protection

API prefix: /api/core

Customer:
POST /api/core/auth/register
POST /api/core/auth/login
GET  /api/core/customer/balances
GET  /api/core/customer/ledger
POST /api/core/customer/deposit-intents

Administrator:
POST /api/core/admin/login
GET  /api/core/admin/deposits
POST /api/core/admin/deposits/:id/approve

Trusted blockchain worker:
POST /api/core/internal/deposits/confirm

Withdrawals remain disabled.
No blockchain scanner is installed by this migration.
A trusted scanner must independently verify every deposit before
calling the internal confirmation endpoint.
REPORT

echo
echo "=========================================="
echo " WALLETPILL CORE INSTALLATION COMPLETE"
echo "=========================================="
echo "API prefix: http://127.0.0.1:3000/api/core"
echo "Admin login: POST /api/core/admin/login"
echo "Customer login: POST /api/core/auth/login"
echo
echo "Next: run the tests shown in the instructions."
