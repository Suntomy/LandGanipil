'use strict';

const crypto = require('crypto');
const assets = require('../networks/assets');
const {
  validAsset,
  validAmount
} = require('../security/validation');

async function requestWithdrawal(pool, input, customerId) {
  if (process.env.ENABLE_WITHDRAWALS !== 'true') {
    throw new Error('Withdrawals are disabled by the administrator.');
  }

  const { asset, amount, destination, network } = input;

  if (!validAsset(asset, assets)) {
    throw new Error('Unsupported or disabled asset.');
  }

  if (!validAmount(amount)) {
    throw new Error('Invalid withdrawal amount.');
  }

  if (typeof destination !== 'string' ||
      destination.length < 20 ||
      destination.length > 150) {
    throw new Error('Invalid destination address.');
  }

  if (!network || typeof network !== 'string') {
    throw new Error('Network is required.');
  }

  /*
   * This only records a request.
   * Actual signing and broadcast require a separately audited signer.
   */

  const reference = crypto.randomUUID();

  const result = await pool.query(
    `INSERT INTO wp_withdrawal_requests
     (reference, customer_id, asset, amount,
      destination, network, status, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,'PENDING_REVIEW',NOW())
     RETURNING id, reference, status`,
    [
      reference,
      customerId,
      asset.toUpperCase(),
      String(amount),
      destination,
      network
    ]
  );

  return result.rows[0];
}

module.exports = { requestWithdrawal };
