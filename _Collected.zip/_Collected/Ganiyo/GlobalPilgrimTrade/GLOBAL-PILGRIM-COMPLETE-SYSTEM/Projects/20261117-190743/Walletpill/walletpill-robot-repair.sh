#!/data/data/com.termux/files/usr/bin/bash

set -u

APP="$HOME/Walletpill"
cd "$APP" || exit 1

echo "=========================================="
echo "       WALLETPILL ROBOT REPAIR 2.0"
echo "=========================================="

STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP="$APP/robot-backup-$STAMP"

mkdir -p "$BACKUP"

echo "[1/8] Backing up important project files..."

for f in server.js package.json core/routes.js public/index.html admin/dashboard.html; do
    if [ -f "$f" ]; then
        mkdir -p "$BACKUP/$(dirname "$f")"
        cp -p "$f" "$BACKUP/$f"
        echo "BACKUP OK: $f"
    fi
done

echo
echo "[2/8] Checking Node.js and PM2..."

node --version
npm --version

if ! command -v pm2 >/dev/null 2>&1 && ! npx --no-install pm2 --version >/dev/null 2>&1; then
    echo "Installing PM2..."
    npm install pm2
fi

PM2="npx --no-install pm2"

echo
echo "[3/8] Checking server syntax..."

if [ -f server.js ]; then
    if node --check server.js; then
        echo "PASS: server.js syntax"
    else
        echo "STOP: server.js has a syntax error."
        echo "Backup is at: $BACKUP"
        exit 1
    fi
else
    echo "STOP: server.js is missing."
    exit 1
fi

if [ -f core/routes.js ]; then
    if node --check core/routes.js; then
        echo "PASS: core/routes.js syntax"
    else
        echo "STOP: core/routes.js has a syntax error."
        echo "Backup is at: $BACKUP"
        exit 1
    fi
fi

echo
echo "[4/8] Inspecting port 3000..."

if command -v ss >/dev/null 2>&1; then
    ss -ltnp 2>/dev/null | grep ':3000' || echo "No port 3000 listener reported by ss."
fi

echo
echo "[5/8] Removing duplicate Walletpill PM2 entries..."

$PM2 jlist > "$BACKUP/pm2-before.json" 2>/dev/null || true

node - "$BACKUP/pm2-before.json" <<'NODE'
const fs = require('fs');
const file = process.argv[2];

try {
  const list = JSON.parse(fs.readFileSync(file, 'utf8'));
  for (const p of list) {
    const name = String(p.name || '').toLowerCase();
    if (['walletpill', 'walletpi'].includes(name)) {
      console.log(`Found PM2 process: ${p.name}, id ${p.pm_id}`);
    }
  }
} catch {
  console.log('Could not read PM2 process list.');
}
NODE

# Stop/delete only PM2 processes named walletpill or walletpi.
$PM2 jlist 2>/dev/null | node -e '
let s="";
process.stdin.on("data",d=>s+=d);
process.stdin.on("end",()=>{
 try {
  for(const p of JSON.parse(s)){
   const n=String(p.name||"").toLowerCase();
   if(n==="walletpill" || n==="walletpi") console.log(p.pm_id);
  }
 } catch {}
});
' > "$BACKUP/walletpill-pm2-ids.txt"

while read -r id; do
    [ -n "$id" ] || continue
    echo "Removing duplicate Walletpill PM2 entry ID $id"
    $PM2 delete "$id" >/dev/null 2>&1 || true
done < "$BACKUP/walletpill-pm2-ids.txt"

echo
echo "[6/8] Checking whether port 3000 is still occupied..."

PORT_PIDS=""

if command -v fuser >/dev/null 2>&1; then
    PORT_PIDS=$(fuser -n tcp 3000 2>/dev/null || true)
fi

if [ -n "$PORT_PIDS" ]; then
    for pid in $PORT_PIDS; do
        [ -r "/proc/$pid/cmdline" ] || continue
        CMD=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)

        echo "Port owner PID: $pid"
        echo "Process: $CMD"

        case "$CMD" in
            *"$APP"*|*"$APP/server.js"*)
                echo "This process belongs to Walletpill. Stopping duplicate..."
                kill "$pid" 2>/dev/null || true
                ;;
            *)
                echo "WARNING: Port 3000 belongs to another or unidentified process."
                echo "Robot will NOT kill it."
                echo "Walletpill will not be started on this occupied port."
                echo "Inspect the process before proceeding."
                exit 2
                ;;
        esac
    done
    sleep 2
fi

if command -v ss >/dev/null 2>&1 && ss -ltn 2>/dev/null | grep -q ':3000'; then
    echo "WARNING: Port 3000 is still listening."
    echo "Robot will not force-kill an unidentified process."
    echo "Check the listener before starting Walletpill."
    exit 2
fi

echo
echo "[7/8] Starting one Walletpill PM2 process..."

$PM2 start server.js --name walletpill --cwd "$APP" --time

if [ $? -ne 0 ]; then
    echo "ERROR: PM2 could not start Walletpill."
    exit 1
fi

$PM2 save

echo
echo "[8/8] Running final health checks..."

sleep 3

$PM2 status

echo
echo "Checking local server response..."

if command -v curl >/dev/null 2>&1; then
    curl -sS --max-time 5 http://127.0.0.1:3000/api/health || true
    echo
else
    echo "curl is not installed; skipping HTTP check."
fi

echo
echo "=========================================="
echo "       ROBOT REPAIR FINISHED"
echo "=========================================="
echo "Backup: $BACKUP"
echo "Review logs with:"
echo "npx pm2 logs walletpill --lines 40"
echo
echo "IMPORTANT:"
echo "A running server does not prove real blockchain"
echo "deposits or withdrawals are operational."
