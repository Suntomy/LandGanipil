'use strict';

const config = require('../config');

function listProviders() {
  return Object.entries(config.payments).map(([name, provider]) => ({
    name,
    enabled: provider.enabled,
    credentialsConfigured: Boolean(provider.secretKey),
    status: provider.enabled && provider.secretKey
      ? 'CONFIGURED'
      : 'NOT_CONFIGURED'
  }));
}

function getProvider(name) {
  const provider = config.payments[name];

  if (!provider) {
    throw new Error(`Unsupported payment provider: ${name}`);
  }

  return provider;
}

function requireProvider(name) {
  const provider = getProvider(name);

  if (!provider.enabled || !provider.secretKey) {
    throw new Error(`${name} is not configured or enabled`);
  }

  return provider;
}

module.exports = {
  listProviders,
  getProvider,
  requireProvider
};
