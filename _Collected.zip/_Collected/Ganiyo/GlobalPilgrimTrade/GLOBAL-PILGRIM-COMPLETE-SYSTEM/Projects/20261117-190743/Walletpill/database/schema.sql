CREATE TABLE IF NOT EXISTS customers (
    id BIGSERIAL PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'customer'
        CHECK (role IN ('customer', 'admin')),
    status TEXT NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'SUSPENDED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallet_accounts (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL REFERENCES customers(id),
    asset VARCHAR(20) NOT NULL,
    balance NUMERIC(36,18) NOT NULL DEFAULT 0
        CHECK (balance >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(customer_id, asset)
);

CREATE TABLE IF NOT EXISTS deposits (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL REFERENCES customers(id),
    asset VARCHAR(20) NOT NULL,
    network VARCHAR(40) NOT NULL,
    tx_hash TEXT NOT NULL,
    amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
    status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (status IN (
            'PENDING', 'CONFIRMED', 'APPROVED', 'REJECTED'
        )),
    confirmations INTEGER NOT NULL DEFAULT 0,
    required_confirmations INTEGER NOT NULL DEFAULT 1,
    blockchain_verified BOOLEAN NOT NULL DEFAULT FALSE,
    verified_at TIMESTAMPTZ,
    approved_by BIGINT REFERENCES customers(id),
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(network, asset, tx_hash)
);

CREATE TABLE IF NOT EXISTS ledger_transactions (
    id BIGSERIAL PRIMARY KEY,
    account_id BIGINT NOT NULL REFERENCES wallet_accounts(id),
    customer_id BIGINT NOT NULL REFERENCES customers(id),
    asset VARCHAR(20) NOT NULL,
    transaction_type TEXT NOT NULL,
    direction TEXT NOT NULL CHECK (direction IN ('CREDIT', 'DEBIT')),
    amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
    balance_after NUMERIC(36,18) NOT NULL,
    reference TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_deposits_status
    ON deposits(status);

CREATE INDEX IF NOT EXISTS idx_ledger_customer
    ON ledger_transactions(customer_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ledger_account
    ON ledger_transactions(account_id, created_at DESC);
