require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const path = require("path");

const app = express();

app.use(helmet({
 contentSecurityPolicy: false
}));

app.use(cors());
app.use(express.json({limit:"100kb"}));

app.use(express.static(path.join(__dirname,"public")));

app.get("/api/health",(req,res)=>{
 res.json({
  application:"WALLETPILL",
  version:"2.0.0",
  status:"RUNNING",
  withdrawalsEnabled:false
 });
});

app.get("/api/coins",(req,res)=>{
 res.json([
  {name:"Bitcoin",symbol:"BTC"},
  {name:"Ethereum",symbol:"ETH"},
  {name:"Litecoin",symbol:"LTC"},
  {name:"Dogecoin",symbol:"DOGE"},
  {name:"Solana",symbol:"SOL"},
  {name:"Pilgrim Coin",symbol:"PGC"},
  {name:"Bitcoin Lightning",symbol:"LIGHTNING"}
 ]);
});

app.use("/api/engines",require("./engines/routes"));

app.use("/api", require("./integrations/routes"));

app.post("/api/transfer",(req,res)=>{
 res.status(503).json({
  success:false,
  message:"Real transfers require secure wallet signing, balance verification and transaction broadcasting."
 });
});

app.use("/api/core", require("./core/routes"));

app.get("/",(req,res)=>{
 res.sendFile(path.join(__dirname,"public","index.html"));
});

const PORT=process.env.PORT || 3000;

app.listen(PORT, process.env.HOST || '0.0.0.0',()=>{
 console.log("");
 console.log("================================");
 console.log(" WALLETPILL IS RUNNING");
 console.log("================================");
 console.log("Address: http://127.0.0.1:"+PORT);
 console.log("Health: /api/health");
 console.log("Engines: /api/engines");
 console.log("================================");
});
