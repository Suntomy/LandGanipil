#!/data/data/com.termux/files/usr/bin/bash
set -e

cd "$HOME/Walletpill"

echo "=========================================="
echo " WALLETPILL DASHBOARD DATABASE CONNECTOR"
echo "=========================================="

mkdir -p public admin reports

echo "[1/6] Backing up existing files..."

cp public/index.html public/index.html.backup 2>/dev/null || true
cp admin/dashboard.html admin/dashboard.html.backup 2>/dev/null || true
cp core/routes.js core/routes.js.backup

echo "[2/6] Adding administrator database APIs..."

node <<'NODE'
const fs = require("fs");

const file = "core/routes.js";
let source = fs.readFileSync(file, "utf8");

if (source.includes("/admin/ledger")) {
  console.log("Administrator APIs already installed.");
  process.exit(0);
}

const addition = `

// ADMINISTRATOR: CUSTOMER WALLET BALANCES
router.get("/admin/balances",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        \`SELECT c.id AS customer_id,
                c.email,
                c.full_name,
                w.asset,
                w.balance
         FROM wallet_accounts w
         JOIN customers c ON c.id = w.customer_id
         ORDER BY c.email, w.asset
         LIMIT 1000\`
      );

      res.json({success:true, balances:result.rows});
    } catch(err) {
      console.error(err);
      res.status(500).json({error:"Could not load customer balances"});
    }
  }
);

// ADMINISTRATOR: COMPLETE TRANSACTION LEDGER
router.get("/admin/ledger",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        \`SELECT l.id,
                l.customer_id,
                c.email AS customer_email,
                l.asset,
                l.transaction_type,
                l.direction,
                l.amount,
                l.balance_after,
                l.reference,
                l.description,
                l.created_at
         FROM ledger_transactions l
         JOIN customers c ON c.id = l.customer_id
         ORDER BY l.created_at DESC
         LIMIT 500\`
      );

      res.json({success:true, transactions:result.rows});
    } catch(err) {
      console.error(err);
      res.status(500).json({error:"Could not load transaction ledger"});
    }
  }
);

// ADMINISTRATOR: CUSTOMER LIST
router.get("/admin/customers",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        \`SELECT id, email, full_name, status, created_at
         FROM customers
         WHERE role = 'customer'
         ORDER BY created_at DESC
         LIMIT 500\`
      );

      res.json({success:true, customers:result.rows});
    } catch(err) {
      console.error(err);
      res.status(500).json({error:"Could not load customers"});
    }
  }
);

`;

const marker = "module.exports = router;";

if (!source.includes(marker)) {
  throw new Error("Could not find routes export.");
}

source = source.replace(marker, addition + "\n" + marker);
fs.writeFileSync(file, source);

console.log("Administrator APIs installed.");
NODE

echo "[3/6] Creating customer dashboard connector..."

cat > public/walletpill-dashboard.js <<'JS'
(() => {
  const API = "/api/core";
  const TOKEN_KEY = "walletpill_customer_token";

  const root = document.createElement("section");
  root.id = "walletpill-customer-app";

  root.innerHTML = `
  <style>
  #walletpill-customer-app {
    font-family: Arial, sans-serif;
    padding: 20px;
    max-width: 1100px;
    margin: 20px auto;
    color: #172033;
  }
  #walletpill-customer-app .wp-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 12px;
    padding: 18px;
    margin-bottom: 15px;
    overflow-x: auto;
  }
  #walletpill-customer-app input,
  #walletpill-customer-app button {
    padding: 12px;
    margin: 5px 0;
    border-radius: 7px;
    border: 1px solid #ccc;
  }
  #walletpill-customer-app button {
    cursor: pointer;
    background: #153d70;
    color: white;
  }
  #walletpill-customer-app table {
    width: 100%;
    border-collapse: collapse;
  }
  #walletpill-customer-app td,
  #walletpill-customer-app th {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
  }
  </style>

  <div class="wp-card">
    <h2>Walletpill Customer Wallet</h2>
    <p id="wp-customer-message">Connect to your Walletpill account.</p>
  </div>

  <div id="wp-customer-login" class="wp-card">
    <h3>Customer Login</h3>
    <form id="wp-login-form">
      <input id="wp-email" type="email" placeholder="Email address" required>
      <input id="wp-password" type="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>

    <hr>
    <h3>Create Customer Account</h3>
    <form id="wp-register-form">
      <input id="wp-name" placeholder="Full name" required>
      <input id="wp-new-email" type="email" placeholder="Email address" required>
      <input id="wp-new-password" type="password" minlength="10"
       placeholder="Password (minimum 10 characters)" required>
      <button type="submit">Register</button>
    </form>
  </div>

  <div id="wp-customer-dashboard" hidden>
    <div class="wp-card">
      <h3>My Wallet Balances</h3>
      <div id="wp-balances">Loading...</div>
      <button id="wp-refresh">Refresh Balances</button>
      <button id="wp-logout">Logout</button>
    </div>

    <div class="wp-card">
      <h3>My Transaction History</h3>
      <div id="wp-history">Loading...</div>
    </div>
  </div>
  `;

  document.body.appendChild(root);

  const $ = id => root.querySelector("#" + id);

  function message(text) {
    $("wp-customer-message").textContent = text;
  }

  async function api(path, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);

    const response = await fetch(API + path, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(token ? {Authorization:"Bearer " + token} : {}),
        ...(options.headers || {})
      }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    return data;
  }

  function cell(value) {
    const td = document.createElement("td");
    td.textContent = value == null ? "" : String(value);
    return td;
  }

  function renderTable(target, columns, rows) {
    const table = document.createElement("table");
    const head = document.createElement("tr");

    columns.forEach(c => {
      const th = document.createElement("th");
      th.textContent = c.label;
      head.appendChild(th);
    });

    table.appendChild(head);

    rows.forEach(row => {
      const tr = document.createElement("tr");
      columns.forEach(c => tr.appendChild(cell(row[c.key])));
      table.appendChild(tr);
    });

    target.replaceChildren(table);

    if (!rows.length) {
      target.textContent = "No records found.";
    }
  }

  async function loadDashboard() {
    $("wp-customer-login").hidden = true;
    $("wp-customer-dashboard").hidden = false;

    try {
      const [balances, ledger] = await Promise.all([
        api("/customer/balances"),
        api("/customer/ledger")
      ]);

      renderTable(
        $("wp-balances"),
        [
          {key:"asset",label:"Coin"},
          {key:"balance",label:"Available Balance"}
        ],
        balances.balances
      );

      renderTable(
        $("wp-history"),
        [
          {key:"created_at",label:"Date"},
          {key:"asset",label:"Coin"},
          {key:"transaction_type",label:"Type"},
          {key:"direction",label:"Direction"},
          {key:"amount",label:"Amount"},
          {key:"balance_after",label:"Balance After"},
          {key:"reference",label:"Reference"}
        ],
        ledger.transactions
      );

      message("Connected to your PostgreSQL wallet ledger.");
    } catch(err) {
      message(err.message);
      if (/token|authentication|expired/i.test(err.message)) {
        logout();
      }
    }
  }

  function logout() {
    localStorage.removeItem(TOKEN_KEY);
    $("wp-customer-login").hidden = false;
    $("wp-customer-dashboard").hidden = true;
    message("You have logged out.");
  }

  $("wp-login-form").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const data = await api("/auth/login", {
        method:"POST",
        body:JSON.stringify({
          email:$("wp-email").value,
          password:$("wp-password").value
        })
      });

      localStorage.setItem(TOKEN_KEY, data.token);
      await loadDashboard();
    } catch(err) {
      message(err.message);
    }
  });

  $("wp-register-form").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const data = await api("/auth/register", {
        method:"POST",
        body:JSON.stringify({
          fullName:$("wp-name").value,
          email:$("wp-new-email").value,
          password:$("wp-new-password").value
        })
      });

      localStorage.setItem(TOKEN_KEY, data.token);
      await loadDashboard();
    } catch(err) {
      message(err.message);
    }
  });

  $("wp-refresh").addEventListener("click", loadDashboard);
  $("wp-logout").addEventListener("click", logout);

  if (localStorage.getItem(TOKEN_KEY)) {
    loadDashboard();
  }
})();
JS

echo "[4/6] Creating administrator dashboard connector..."

cat > admin/walletpill-admin.js <<'JS'
(() => {
  const API = "/api/core";
  const TOKEN_KEY = "walletpill_admin_token";

  const root = document.createElement("section");
  root.id = "walletpill-admin-app";

  root.innerHTML = `
  <style>
  #walletpill-admin-app {
    font-family:Arial,sans-serif;
    max-width:1200px;
    margin:20px auto;
    padding:20px;
    color:#172033;
  }
  #walletpill-admin-app .card {
    background:white;
    border:1px solid #ddd;
    border-radius:12px;
    padding:18px;
    margin-bottom:18px;
    overflow-x:auto;
  }
  #walletpill-admin-app input,
  #walletpill-admin-app button {
    padding:11px;
    margin:5px 0;
    border:1px solid #ccc;
    border-radius:6px;
  }
  #walletpill-admin-app button {
    background:#153d70;
    color:white;
    cursor:pointer;
  }
  #walletpill-admin-app table {
    width:100%;
    border-collapse:collapse;
  }
  #walletpill-admin-app th,
  #walletpill-admin-app td {
    border-bottom:1px solid #ddd;
    padding:10px;
    text-align:left;
  }
  </style>

  <div class="card">
    <h2>Walletpill Administrator</h2>
    <p id="admin-message">Administrator authentication required.</p>
  </div>

  <div class="card" id="admin-login">
    <h3>Administrator Login</h3>
    <form id="admin-login-form">
      <input id="admin-email" type="email"
        placeholder="Administrator email" required>
      <input id="admin-password" type="password"
        placeholder="Administrator password" required>
      <button type="submit">Administrator Login</button>
    </form>
  </div>

  <div id="admin-dashboard" hidden>
    <div class="card">
      <h3>Customer Wallet Balances</h3>
      <div id="admin-balances">Loading...</div>
    </div>

    <div class="card">
      <h3>Transaction Ledger</h3>
      <div id="admin-ledger">Loading...</div>
    </div>

    <div class="card">
      <h3>Deposit Management</h3>
      <div id="admin-deposits">Loading...</div>
    </div>

    <div class="card">
      <button id="admin-refresh">Refresh All Records</button>
      <button id="admin-logout">Logout</button>
    </div>
  </div>
  `;

  document.body.appendChild(root);

  const $ = id => root.querySelector("#" + id);

  function message(value) {
    $("admin-message").textContent = value;
  }

  async function api(path, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);

    const response = await fetch(API + path, {
      ...options,
      headers: {
        "Content-Type":"application/json",
        ...(token ? {Authorization:"Bearer " + token} : {}),
        ...(options.headers || {})
      }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    return data;
  }

  function makeTable(target, columns, rows, action) {
    const table = document.createElement("table");
    const head = document.createElement("tr");

    columns.forEach(c => {
      const th = document.createElement("th");
      th.textContent = c.label;
      head.appendChild(th);
    });

    if (action) {
      const th = document.createElement("th");
      th.textContent = "Action";
      head.appendChild(th);
    }

    table.appendChild(head);

    rows.forEach(row => {
      const tr = document.createElement("tr");

      columns.forEach(c => {
        const td = document.createElement("td");
        td.textContent = row[c.key] == null
          ? ""
          : String(row[c.key]);
        tr.appendChild(td);
      });

      if (action) {
        const td = document.createElement("td");
        action(row, td);
        tr.appendChild(td);
      }

      table.appendChild(tr);
    });

    target.replaceChildren(table);

    if (!rows.length) {
      target.textContent = "No records found.";
    }
  }

  async function loadDashboard() {
    $("admin-login").hidden = true;
    $("admin-dashboard").hidden = false;

    try {
      const [balances, ledger, deposits] = await Promise.all([
        api("/admin/balances"),
        api("/admin/ledger"),
        api("/admin/deposits")
      ]);

      makeTable(
        $("admin-balances"),
        [
          {key:"customer_id",label:"Customer ID"},
          {key:"email",label:"Customer"},
          {key:"asset",label:"Coin"},
          {key:"balance",label:"Balance"}
        ],
        balances.balances
      );

      makeTable(
        $("admin-ledger"),
        [
          {key:"created_at",label:"Date"},
          {key:"customer_email",label:"Customer"},
          {key:"asset",label:"Coin"},
          {key:"transaction_type",label:"Type"},
          {key:"direction",label:"Direction"},
          {key:"amount",label:"Amount"},
          {key:"balance_after",label:"Balance After"},
          {key:"reference",label:"Reference"}
        ],
        ledger.transactions
      );

      makeTable(
        $("admin-deposits"),
        [
          {key:"id",label:"ID"},
          {key:"customer_email",label:"Customer"},
          {key:"asset",label:"Coin"},
          {key:"network",label:"Network"},
          {key:"tx_hash",label:"Transaction Hash"},
          {key:"amount",label:"Amount"},
          {key:"confirmations",label:"Confirmations"},
          {key:"status",label:"Status"}
        ],
        deposits.deposits,
        (row, td) => {
          if (row.status !== "CONFIRMED") {
            td.textContent = "Not ready for approval";
            return;
          }

          const button = document.createElement("button");
          button.textContent = "Approve Deposit";

          button.addEventListener("click", async () => {
            if (!confirm(
              "Approve this independently verified blockchain deposit?"
            )) return;

            try {
              await api(
                "/admin/deposits/" + encodeURIComponent(row.id) + "/approve",
                {method:"POST",body:"{}"}
              );

              message("Deposit credited successfully.");
              await loadDashboard();
            } catch(err) {
              message(err.message);
            }
          });

          td.appendChild(button);
        }
      );

      message("Administrator connected to PostgreSQL.");
    } catch(err) {
      message(err.message);

      if (/token|authentication|expired/i.test(err.message)) {
        logout();
      }
    }
  }

  function logout() {
    localStorage.removeItem(TOKEN_KEY);
    $("admin-login").hidden = false;
    $("admin-dashboard").hidden = true;
    message("Administrator logged out.");
  }

  $("admin-login-form").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const data = await api("/admin/login", {
        method:"POST",
        body:JSON.stringify({
          email:$("admin-email").value,
          password:$("admin-password").value
        })
      });

      localStorage.setItem(TOKEN_KEY, data.token);
      await loadDashboard();
    } catch(err) {
      message(err.message);
    }
  });

  $("admin-refresh").addEventListener("click", loadDashboard);
  $("admin-logout").addEventListener("click", logout);

  if (localStorage.getItem(TOKEN_KEY)) {
    loadDashboard();
  }
})();
JS

echo "[5/6] Connecting scripts to dashboard HTML..."

node <<'NODE'
const fs = require("fs");

function connect(file, script) {
  if (!fs.existsSync(file)) {
    console.log("Creating missing dashboard:", file);
    fs.writeFileSync(file,
      "<!doctype html><html><head><meta charset=\"utf-8\">" +
      "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
      "<title>Walletpill</title></head><body>" +
      "<h1>Walletpill</h1></body></html>"
    );
  }

  let html = fs.readFileSync(file, "utf8");
  const tag = `<script src="${script}" defer></script>`;

  if (!html.includes(script)) {
    if (/<\/body>/i.test(html)) {
      html = html.replace(/<\/body>/i, tag + "\n</body>");
    } else {
      html += "\n" + tag;
    }
  }

  fs.writeFileSync(file, html);
  console.log("Connected:", file);
}

connect("public/index.html", "/walletpill-dashboard.js");
connect("admin/dashboard.html", "/admin/walletpill-admin.js");
NODE

echo "[6/6] Checking all JavaScript..."

node --check core/routes.js
node --check public/walletpill-dashboard.js
node --check admin/walletpill-admin.js
node --check server.js

cat > reports/DASHBOARD_DATABASE_CONNECTION.txt <<'REPORT'
WALLETPILL DASHBOARD CONNECTION

Customer dashboard:
public/index.html
public/walletpill-dashboard.js

Administrator dashboard:
admin/dashboard.html
admin/walletpill-admin.js

Database:
PostgreSQL through core/db.js

Customer APIs:
GET /api/core/customer/balances
GET /api/core/customer/ledger
POST /api/core/auth/login
POST /api/core/auth/register

Administrator APIs:
GET /api/core/admin/balances
GET /api/core/admin/ledger
GET /api/core/admin/deposits
POST /api/core/admin/deposits/:id/approve
POST /api/core/admin/login

Wallet balances are read from wallet_accounts.
Transaction history is read from ledger_transactions.
Customers can only access their own records.
Administrators can inspect all customer records.

Blockchain approval remains dependent on independent verification.
Withdrawals remain disabled.
REPORT

echo
echo "=========================================="
echo " DASHBOARD CONNECTION INSTALLED"
echo "=========================================="

echo "Customer: http://127.0.0.1:3000/"
echo "Admin:    http://127.0.0.1:3000/admin/dashboard.html"

echo
echo "Restarting Walletpill..."

npx pm2 restart walletpill --update-env || npx pm2 start server.js --name walletpill
npx pm2 save

echo
echo "WALLETPILL DASHBOARDS CONNECTED."
