WALLETPILL VERSION 2.0

MAIN INTERFACE:
public/index.html

BACKEND:
server.js

BLOCKCHAIN ENGINE:
engines/live-engine.js

LOCAL ADDRESS:
http://127.0.0.1:3000

API:
GET /api/health
GET /api/coins
GET /api/engines
GET /api/engines/BTC
GET /api/engines/ETH
GET /api/engines/LTC

IMPORTANT:
Blockchain status checks do not constitute completed
wallet creation, deposits or withdrawals.

Real transfers require secure private-key management,
transaction signing, fee estimation, broadcasting,
confirmation and reconciliation.

Never place private keys in public HTML files.
