'use strict';

/*
 * A real blockchain provider must implement this interface.
 * This default verifier intentionally rejects every transaction.
 * Never credit a customer merely because a transaction ID was submitted.
 */

async function verifyDeposit() {
  return {
    verified: false,
    confirmations: 0,
    reason: 'BLOCKCHAIN_VERIFIER_NOT_CONFIGURED'
  };
}

module.exports = { verifyDeposit };
