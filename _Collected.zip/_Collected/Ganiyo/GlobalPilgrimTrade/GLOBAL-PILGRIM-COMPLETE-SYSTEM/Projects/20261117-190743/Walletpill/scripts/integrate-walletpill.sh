#!/data/data/com.termux/files/usr/bin/bash

set -e

cd ~/Walletpill || exit 1

echo "======================================"
echo " WALLETPILL CENTRAL INTEGRATION"
echo "======================================"

# 1. Backup existing files
BACKUP="backups/pre-integration-$(date +%Y%m%d-%H%M%S)"

mkdir -p "$BACKUP"

cp server.js "$BACKUP/" 2>/dev/null || true
cp integrations/wallets/hd-wallet.js "$BACKUP/" 2>/dev/null || true

# 2. Install authentication dependency
npm install jsonwebtoken

# 3. Ensure private environment file exists
touch .env
chmod 600 .env

# Generate a secret only if one does not already exist
if ! grep -q '^JWT_SECRET=.' .env; then
  SECRET=$(node -e "process.stdout.write(require('crypto').randomBytes(48).toString('hex'))")
  echo "JWT_SECRET=$SECRET" >> .env
  echo "A new private JWT secret has been created."
fi

# 4. Connect customer identity to generated addresses
node <<'NODE'
const fs = require('fs');

const file = 'integrations/wallets/hd-wallet.js';

let code = fs.readFileSync(file, 'utf8');

if (!code.includes('async function generateAddress(asset, customerId)')) {
  code = code.replace(
    'async function generateAddress(asset) {',
    'async function generateAddress(asset, customerId) {'
  );
}

if (!code.includes('customerId: customerId || null')) {
  code = code.replace(
    'const record = {\n    id: `${asset}-${index}`,',
    'const record = {\n    customerId: customerId || null,\n    id: `${asset}-${index}`,'
  );
}

fs.writeFileSync(file, code);
NODE

# 5. Central API integration routes
cat > integrations/routes.js <<'EOF'
'use strict';

const express = require('express');
const jwt = require('jsonwebtoken');

const router = express.Router();

const wallet = require('./wallets/hd-wallet');
const health = require('./health');

function authenticate(req, res, next) {
  const secret = process.env.JWT_SECRET;

  if (!secret) {
    return res.status(503).json({
      success: false,
      message: 'Authentication secret is not configured.'
    });
  }

  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ')
    ? header.slice(7)
    : null;

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required.'
    });
  }

  try {
    req.user = jwt.verify(token, secret);

    if (!req.user.sub) {
      throw new Error('Missing user identity');
    }

    next();
  } catch {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired authentication token.'
    });
  }
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Administrator permission required.'
    });
  }

  next();
}

// Public service health information. No secrets are returned.
router.get('/integrations/status', (req, res) => {
  res.json(health.getIntegrationStatus());
});

// Authenticated customer: generate a fresh deposit address.
router.post(
  '/wallets/:asset/deposit-address',
  authenticate,
  async (req, res) => {
    try {
      const result = await wallet.generateAddress(
        req.params.asset,
        String(req.user.sub)
      );

      res.status(201).json({
        success: true,
        message: 'New receiving address generated.',
        wallet: result
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
);

// Customer sees only their own generated addresses.
router.get('/wallets/addresses', authenticate, (req, res) => {
  const all = wallet.listAddresses();

  const result = req.user.role === 'admin'
    ? all
    : all.filter(
        item => String(item.customerId) === String(req.user.sub)
      );

  res.json({
    success: true,
    addresses: result
  });
});

// Administrator: view pending deposits.
router.get(
  '/admin/deposits/pending',
  authenticate,
  adminOnly,
  (req, res) => {
    res.json({
      success: true,
      deposits: wallet.listPendingDeposits()
    });
  }
);

// Approval cannot credit a balance until a real database ledger
// and atomic credit operation have been connected.
router.post(
  '/admin/deposits/:id/review',
  authenticate,
  adminOnly,
  (req, res) => {
    const decision = String(req.body.decision || '').toUpperCase();

    if (decision === 'APPROVED') {
      return res.status(503).json({
        success: false,
        message: 'Deposit approval and balance credit require the database ledger and verified blockchain confirmation service.'
      });
    }

    if (decision !== 'REJECTED') {
      return res.status(400).json({
        success: false,
        message: 'Decision must be APPROVED or REJECTED.'
      });
    }

    try {
      const result = wallet.reviewDeposit(
        req.params.id,
        'REJECTED',
        String(req.user.sub)
      );

      res.json({
        success: true,
        deposit: result
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
);

module.exports = router;
EOF

# 6. Mount integration routes into the main server
node <<'NODE'
const fs = require('fs');

const file = 'server.js';
let code = fs.readFileSync(file, 'utf8');

const mount = 'app.use("/api", require("./integrations/routes"));';

if (!code.includes(mount)) {
  const marker = 'app.post("/api/transfer"';

  if (!code.includes(marker)) {
    throw new Error('Cannot find server transfer route. Server not modified.');
  }

  code = code.replace(marker, mount + '\n\n' + marker);
}

fs.writeFileSync(file, code);
NODE

# 7. Check JavaScript files
echo
echo "Checking integration files..."

node --check server.js
node --check integrations/routes.js
node --check integrations/wallets/hd-wallet.js
node --check integrations/health.js
node --check integrations/blockchains/index.js
node --check integrations/payments/index.js

# 8. Record integration status
cat > integrations/INTEGRATION_STATUS.txt <<'EOF'
WALLETPILL CENTRAL INTEGRATION

Connected:
- Main Express server
- Blockchain configuration
- Payment provider configuration
- HD wallet address generator
- Customer-scoped deposit address routes
- Administrator deposit listing
- Authentication middleware
- Integration health endpoint

Not yet production-ready:
- Customer/admin login and token issuance
- Persistent production database
- Blockchain deposit monitoring
- Blockchain confirmation verification
- Atomic customer ledger crediting
- Secure withdrawal signing and broadcasting
- Payment-provider webhook verification
- External payment credentials

Real-money deposits and withdrawals remain disabled.
EOF

echo
echo "======================================"
echo " INTEGRATION INSTALLATION COMPLETE"
echo "======================================"
echo
echo "Backup: $BACKUP"
echo "Run tests before starting the server."
