#!/data/data/com.termux/files/usr/bin/bash

set -u

APP="$HOME/Walletpill"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_ROOT="$HOME/Walletpill_BACKUPS"
BACKUP="$BACKUP_ROOT/Walletpill_$DATE"
REPORT="$BACKUP_ROOT/Walletpill_REPAIR_REPORT_$DATE.txt"

mkdir -p "$BACKUP" || exit 1
mkdir -p "$BACKUP_ROOT"

cd "$APP" || exit 1

exec > >(tee "$REPORT") 2>&1

echo "================================================"
echo "       WALLETPILL COMPLETE REPAIR ROBOT"
echo "                 VERSION 2.0"
echo "================================================"
echo "Date: $DATE"
echo "Project: $APP"
echo

echo "[1] CREATING COMPLETE PROJECT BACKUP"

if ! command -v zip >/dev/null 2>&1; then
    pkg install zip -y
fi

if ! command -v zip >/dev/null 2>&1; then
    echo "ERROR: ZIP installation failed."
    exit 1
fi

cd "$HOME" || exit 1

zip -qr "$BACKUP/Walletpill_FULL_BACKUP.zip" Walletpill \
    -x "Walletpill/node_modules/*" \
       "Walletpill/.git/*" \
       "Walletpill/Walletpill_BACKUPS/*" \
       "Walletpill/robot-backup-*/*"

if [ $? -ne 0 ]; then
    echo "WARNING: ZIP backup reported an error."
else
    echo "PASS: Full source backup created."
fi

cd "$APP" || exit 1

echo
echo "[2] CHECKING PROJECT STRUCTURE"

find . -maxdepth 4 -type f \
    ! -path './node_modules/*' \
    ! -path './.git/*' \
    | sort > "$BACKUP/PROJECT_FILE_LIST.txt"

cat "$BACKUP/PROJECT_FILE_LIST.txt"

echo
echo "[3] CHECKING REQUIRED FILES"

for f in \
    server.js \
    package.json \
    public/index.html \
    admin/dashboard.html \
    core/db.js \
    core/routes.js \
    database/schema.sql
do
    if [ -f "$f" ]; then
        echo "PASS: $f"
    else
        echo "MISSING: $f"
    fi
done

echo
echo "[4] CHECKING JAVASCRIPT SYNTAX"

JS_ERRORS=0
JS_COUNT=0

while IFS= read -r -d '' file; do
    JS_COUNT=$((JS_COUNT + 1))

    if node --check "$file" >/dev/null 2>&1; then
        echo "PASS: $file"
    else
        echo "SYNTAX ERROR: $file"
        node --check "$file" 2>&1
        JS_ERRORS=$((JS_ERRORS + 1))
    fi
done < <(
    find . -type f -name '*.js' \
        ! -path './node_modules/*' \
        ! -path './.git/*' -print0
)

echo "JavaScript files checked: $JS_COUNT"
echo "JavaScript syntax errors: $JS_ERRORS"

echo
echo "[5] CHECKING JSON FILES"

JSON_ERRORS=0
JSON_COUNT=0

while IFS= read -r -d '' file; do
    JSON_COUNT=$((JSON_COUNT + 1))

    if node -e '
      const fs=require("fs");
      JSON.parse(fs.readFileSync(process.argv[1],"utf8"));
    ' "$file" >/dev/null 2>&1; then
        echo "PASS: $file"
    else
        echo "INVALID JSON: $file"
        JSON_ERRORS=$((JSON_ERRORS + 1))
    fi
done < <(
    find . -type f -name '*.json' \
        ! -path './node_modules/*' \
        ! -path './.git/*' -print0
)

echo "JSON files checked: $JSON_COUNT"
echo "JSON errors: $JSON_ERRORS"

echo
echo "[6] CHECKING PACKAGE DEPENDENCIES"

if [ -f package.json ]; then
    node -e '
      const p=require("./package.json");
      console.log("Package:",p.name || "unnamed");
      console.log("Version:",p.version || "unknown");
      console.log("Start script:",p.scripts?.start || "missing");
      console.log("Test script:",p.scripts?.test || "missing");
      console.log("Dependencies:");
      for(const x of Object.keys(p.dependencies || {})) console.log(" -",x);
    '

    echo
    echo "Attempting dependency installation..."

    npm install --no-audit --no-fund

    if [ $? -eq 0 ]; then
        echo "PASS: npm dependency installation."
    else
        echo "WARNING: npm installation failed. Check internet and npm errors."
    fi
else
    echo "ERROR: package.json missing. Cannot safely rebuild dependencies."
fi

echo
echo "[7] CHECKING SERVER STARTUP CONFIGURATION"

grep -nE 'app\.listen|server\.listen|\.listen\(' server.js || true

echo
echo "[8] CHECKING PORT 3000"

if command -v ss >/dev/null 2>&1; then
    ss -ltnp 2>/dev/null | grep ':3000' || \
        echo "No port 3000 listener found."
fi

echo
echo "[9] CHECKING DASHBOARD AND DATABASE INTEGRATION"

for f in \
    public/index.html \
    public/walletpill-dashboard.js \
    admin/dashboard.html \
    admin/walletpill-admin.js \
    core/db.js \
    core/routes.js \
    database/schema.sql
do
    if [ -f "$f" ]; then
        echo "FOUND: $f"
    else
        echo "NOT FOUND: $f"
    fi
done

echo
echo "[10] CHECKING DATABASE ENVIRONMENT WITHOUT REVEALING SECRETS"

if [ -f .env ]; then
    echo "PASS: .env exists."

    for key in DATABASE_URL JWT_SECRET ADMIN_EMAIL ADMIN_PASSWORD; do
        if grep -q "^${key}=" .env; then
            echo "FOUND: $key"
        else
            echo "MISSING: $key"
        fi
    done
else
    echo "WARNING: .env is missing."
fi

echo
echo "[11] CHECKING PM2 PROCESSES"

npx --no-install pm2 status 2>&1 || true

echo
echo "[12] CHECKING PROJECT HEALTH ENDPOINT"

if command -v curl >/dev/null 2>&1; then
    curl -sS --max-time 5 http://127.0.0.1:3000/api/health \
        || echo "Health endpoint not responding."
fi

echo
echo "================================================"
echo "              REPAIR SUMMARY"
echo "================================================"

echo "JavaScript files checked: $JS_COUNT"
echo "JavaScript syntax errors: $JS_ERRORS"
echo "JSON files checked: $JSON_COUNT"
echo "JSON errors: $JSON_ERRORS"
echo
echo "Backup archive:"
echo "$BACKUP/Walletpill_FULL_BACKUP.zip"
echo
echo "Project file inventory:"
echo "$BACKUP/PROJECT_FILE_LIST.txt"
echo
echo "Full diagnostic report:"
echo "$REPORT"
echo
echo "================================================"
echo "ROBOT SCAN COMPLETE"
echo "================================================"
echo
echo "No source files were automatically deleted."
echo "No customer balances were changed."
echo "No withdrawals or real deposits were enabled."
echo "Review the report before applying code changes."

