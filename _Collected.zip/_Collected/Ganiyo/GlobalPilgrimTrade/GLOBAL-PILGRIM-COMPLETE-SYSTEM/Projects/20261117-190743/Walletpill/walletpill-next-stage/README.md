# Walletpill Next Development Stage

This directory contains additive wallet development modules.

## Supported asset registry

BTC, ETH, USDT, SOL, LTC, DOGE and PGC.

PGC is disabled until its actual network and transaction verification
configuration have been established.

## Modules

- security/validation.js
- security/audit.js
- networks/assets.js
- deposits/verifier.js
- deposits/service.js
- withdrawals/service.js
- admin/service.js
- database/schema.sql

## Database

Review database/schema.sql before applying it to PostgreSQL.

The tables use independent wp_ prefixes and do not replace existing
Walletpill customer, account or ledger tables.

## Important limitations

1. The default deposit verifier rejects all transactions.
2. A real blockchain scanner/provider must be configured.
3. Verified deposit events are not automatically credited to balances.
4. Withdrawal requests are not signed or broadcast.
5. ENABLE_WITHDRAWALS must remain false until a secure signer,
   balance reservation, fee calculation, authorization and review
   process are implemented.
6. Do not store private keys in frontend JavaScript or public folders.
7. Do not expose .env or database credentials.
