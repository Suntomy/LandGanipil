#!/data/data/com.termux/files/usr/bin/bash

set -e
cd ~/Walletpill || exit 1

echo "Installing Walletpill wallet addresses..."

# Save the receiving addresses
cat > integrations/wallets/receiving-addresses.json <<'EOF'
{
  "BTC": {
    "name": "Bitcoin",
    "network": "bitcoin",
    "address": "3PwBEGbAQHwfuGdagHx9HTaVLFWCfZgKoB",
    "enabled": true
  },
  "ETH": {
    "name": "Ethereum",
    "network": "ethereum",
    "address": "0xfd3f6fc9de5ef69dd3a7981011f70dc3a14c175a",
    "enabled": true
  },
  "USDT": {
    "name": "Tether USD",
    "network": "tron",
    "tokenStandard": "TRC20",
    "address": "TAySR7Qvjkw7JVe43FoBFKEvorKAYnsmga",
    "enabled": true
  },
  "SOL": {
    "name": "Solana",
    "network": "solana",
    "address": "4Wiypyj919kersskbw91vqqLRTKSGDa5TQ9yCopGq4yM",
    "enabled": true
  },
  "LTC": {
    "name": "Litecoin",
    "network": "litecoin",
    "address": "LeLT81LAVUVN93EU3U42pEGQT6anUnzHKh",
    "enabled": true
  }
}
EOF

# Wallet address service
cat > integrations/wallets/address-service.js <<'EOF'
'use strict';

const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, 'receiving-addresses.json');

function loadAddresses() {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function getAllAddresses() {
  return loadAddresses();
}

function getAddress(symbol) {
  const addresses = loadAddresses();
  const coin = String(symbol).toUpperCase();

  if (!addresses[coin] || !addresses[coin].enabled) {
    throw new Error('Unsupported or disabled asset');
  }

  return addresses[coin];
}

module.exports = {
  getAllAddresses,
  getAddress
};
EOF

# Transaction capability registry
cat > integrations/wallets/transaction-capabilities.js <<'EOF'
'use strict';

const addresses = require('./address-service');

function getCapabilities() {
  return Object.entries(addresses.getAllAddresses()).map(
    ([symbol, wallet]) => ({
      symbol,
      network: wallet.network,
      receivingAddress: wallet.address,
      receivingConfigured: true,
      sendingConfigured: false,
      transactionSigningConfigured: false,
      blockchainConfirmationMonitoring: false,
      status: 'RECEIVE_ADDRESS_CONFIGURED'
    })
  );
}

module.exports = { getCapabilities };
EOF

# Test addresses and configuration
cat > scripts/test-wallet-addresses.js <<'EOF'
'use strict';

const service = require('../integrations/wallets/address-service');
const capabilities = require(
  '../integrations/wallets/transaction-capabilities'
);

console.log('\n===== WALLETPILL RECEIVING ADDRESSES =====\n');

for (const [symbol, wallet] of Object.entries(
  service.getAllAddresses()
)) {
  console.log(`${symbol}: ${wallet.address}`);
  console.log(`Network: ${wallet.network}`);
  console.log(`Enabled: ${wallet.enabled}`);
  console.log('-------------------------------');
}

console.log('\n===== TRANSACTION CAPABILITIES =====\n');

console.table(capabilities.getCapabilities());

console.log('\nAddress configuration test completed.');
console.log('Address syntax still requires blockchain verification.');
EOF

node --check integrations/wallets/address-service.js
node --check integrations/wallets/transaction-capabilities.js
node --check scripts/test-wallet-addresses.js

echo
echo "WALLETPILL RECEIVING ADDRESSES INSTALLED"
echo
echo "Run:"
echo "node scripts/test-wallet-addresses.js"

