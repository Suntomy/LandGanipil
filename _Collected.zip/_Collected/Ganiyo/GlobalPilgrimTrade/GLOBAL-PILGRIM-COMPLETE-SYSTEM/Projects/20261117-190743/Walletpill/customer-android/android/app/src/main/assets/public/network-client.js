(function () {
'use strict';

const Network = {

    connected: false,
    socket: null,
    listeners: {},

    log(message) {
        console.log('[WALLETPILL NETWORK]', message);
    },

    on(event, callback) {

        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }

        this.listeners[event].push(callback);

    },

    emit(event, data) {

        (this.listeners[event] || []).forEach(callback => {

            try {
                callback(data);
            } catch(error) {
                console.error(error);
            }

        });

        window.dispatchEvent(
            new CustomEvent('walletpill:' + event, {
                detail: data
            })
        );

    },

    connect() {

        if (this.socket &&
            (this.socket.readyState === WebSocket.OPEN ||
             this.socket.readyState === WebSocket.CONNECTING)) {
            return;
        }

        const protocol =
            location.protocol === 'https:' ? 'wss:' : 'ws:';

        const address =
            protocol + '//' +
            location.host +
            '/admin-live';

        this.socket = new WebSocket(address);

        this.socket.onopen = () => {

            this.connected = true;

            this.emit('connected', {
                status: 'ONLINE'
            });

            this.log('Connected');

        };

        this.socket.onmessage = event => {

            try {

                const message = JSON.parse(event.data);

                this.emit('message', message);

                this.emit(message.type, message);

            } catch(error) {

                this.log('Invalid network message');

            }

        };

        this.socket.onclose = () => {

            this.connected = false;

            this.emit('disconnected', {
                status: 'OFFLINE'
            });

            setTimeout(() => this.connect(), 5000);

        };

        this.socket.onerror = error => {

            this.log('Connection error');

        };

    },

    async request(endpoint, options = {}) {

        const response = await fetch(endpoint, {

            credentials: 'same-origin',

            ...options,

            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }

        });

        const data = await response.json();

        if (!response.ok) {

            throw new Error(
                data.error || 'Network request failed'
            );

        }

        return data;

    },

    async health() {

        try {

            const result = await this.request('/api/health');

            this.emit('health', result);

            return result;

        } catch(error) {

            this.emit('health-error', error.message);

            return {
                status: 'OFFLINE',
                error: error.message
            };

        }

    }

};

window.WalletpillNetwork = Network;

Network.connect();

Network.health();

})();
