#!/data/data/com.termux/files/usr/bin/bash

BASE="${1:-http://127.0.0.1:3000}"

echo "===================================="
echo "       WALLETPILL API TEST"
echo "===================================="

test_endpoint() {
    NAME="$1"
    PATHNAME="$2"
    METHOD="${3:-GET}"

    echo
    echo "Testing: $NAME"

    curl -sS \
      --connect-timeout 5 \
      --max-time 15 \
      -X "$METHOD" \
      -o /tmp/walletpill-api-response \
      -w "HTTP STATUS: %{http_code}\n" \
      "$BASE$PATHNAME" || echo "Connection failed."

    if [ -s /tmp/walletpill-api-response ]; then
        head -c 700 /tmp/walletpill-api-response
        echo
    fi
}

test_endpoint "Backend health" "/api/health"

test_endpoint "Customer balances authentication check" \
    "/api/core/customer/balances"

test_endpoint "Customer ledger authentication check" \
    "/api/core/customer/ledger"

test_endpoint "Admin deposits authentication check" \
    "/api/core/admin/deposits"

echo
echo "API tests completed."
echo "Protected endpoints may correctly return HTTP 401."
