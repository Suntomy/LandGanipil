'use strict';

const enabled = value => String(value).toLowerCase() === 'true';

module.exports = {
  app: {
    name: 'Walletpill',
    environment: process.env.NODE_ENV || 'development'
  },

  security: {
    realWithdrawalsEnabled: enabled(process.env.ENABLE_WITHDRAWALS),
    realDepositsEnabled: enabled(process.env.ENABLE_REAL_DEPOSITS),
    requireWithdrawalApproval: true
  },

  blockchain: {
    bitcoin: {
      enabled: enabled(process.env.BTC_ENABLED),
      network: process.env.BTC_NETWORK || 'testnet',
      rpcUrl: process.env.BTC_RPC_URL || ''
    },

    ethereum: {
      enabled: enabled(process.env.ETH_ENABLED),
      network: process.env.ETH_NETWORK || 'sepolia',
      rpcUrl: process.env.ETH_RPC_URL || ''
    },

    litecoin: {
      enabled: enabled(process.env.LTC_ENABLED),
      network: process.env.LTC_NETWORK || 'testnet',
      rpcUrl: process.env.LTC_RPC_URL || ''
    },

    dogecoin: {
      enabled: enabled(process.env.DOGE_ENABLED),
      network: process.env.DOGE_NETWORK || 'testnet',
      rpcUrl: process.env.DOGE_RPC_URL || ''
    },

    solana: {
      enabled: enabled(process.env.SOL_ENABLED),
      network: process.env.SOL_NETWORK || 'devnet',
      rpcUrl: process.env.SOL_RPC_URL || ''
    },

    pilgrimCoin: {
      enabled: enabled(process.env.PGC_ENABLED),
      network: process.env.PGC_NETWORK || 'development',
      rpcUrl: process.env.PGC_RPC_URL || '',
      chainId: process.env.PGC_CHAIN_ID || '',
      contractAddress: process.env.PGC_CONTRACT_ADDRESS || ''
    }
  },

  payments: {
    flutterwave: {
      enabled: enabled(process.env.FLUTTERWAVE_ENABLED),
      secretKey: process.env.FLUTTERWAVE_SECRET_KEY || '',
      publicKey: process.env.FLUTTERWAVE_PUBLIC_KEY || ''
    },

    paystack: {
      enabled: enabled(process.env.PAYSTACK_ENABLED),
      secretKey: process.env.PAYSTACK_SECRET_KEY || '',
      publicKey: process.env.PAYSTACK_PUBLIC_KEY || ''
    },

    stripe: {
      enabled: enabled(process.env.STRIPE_ENABLED),
      secretKey: process.env.STRIPE_SECRET_KEY || '',
      publicKey: process.env.STRIPE_PUBLIC_KEY || ''
    }
  }
};
