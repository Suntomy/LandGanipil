'use strict';

const { verifyDeposit } = require('./verifier');
const {
  validAsset,
  validAmount,
  validTransactionId
} = require('../security/validation');

const assets = require('../networks/assets');

async function submitDeposit(pool, input, customerId) {
  const { asset, amount, transactionId, network } = input;

  if (!validAsset(asset, assets)) {
    throw new Error('Unsupported or disabled asset.');
  }

  if (!validAmount(amount)) {
    throw new Error('Invalid deposit amount.');
  }

  if (!validTransactionId(transactionId)) {
    throw new Error('Invalid transaction ID.');
  }

  const result = await verifyDeposit({
    asset,
    amount: String(amount),
    transactionId,
    network
  });

  if (!result.verified) {
    throw new Error(result.reason || 'Deposit verification failed.');
  }

  const saved = await pool.query(
    `INSERT INTO wp_chain_deposit_events
     (customer_id, asset, amount, transaction_id,
      network, confirmations, status, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,'VERIFIED',NOW())
     ON CONFLICT (network, transaction_id)
     DO NOTHING
     RETURNING id`,
    [
      customerId,
      asset.toUpperCase(),
      String(amount),
      transactionId,
      network,
      result.confirmations
    ]
  );

  if (!saved.rowCount) {
    throw new Error('This blockchain transaction has already been recorded.');
  }

  return {
    id: saved.rows[0].id,
    status: 'VERIFIED',
    message: 'Verification recorded. Ledger credit requires approved settlement.'
  };
}

module.exports = { submitDeposit };
