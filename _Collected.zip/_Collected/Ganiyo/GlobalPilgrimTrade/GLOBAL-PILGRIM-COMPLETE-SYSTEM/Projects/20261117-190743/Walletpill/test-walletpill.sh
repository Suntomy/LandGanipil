#!/data/data/com.termux/files/usr/bin/bash

BASE="http://127.0.0.1:3000"

echo
echo "======================================"
echo "       WALLETPILL SYSTEM TEST"
echo "======================================"

echo
echo "[1] NODE.JS VERSION"
node -v

echo
echo "[2] NPM VERSION"
npm -v

echo
echo "[3] CHECKING PROJECT FILES"

for FILE in server.js package.json public/index.html engines/live-engine.js engines/routes.js
do
    if [ -f "$FILE" ]; then
        echo "PASS: $FILE exists"
    else
        echo "FAIL: $FILE is missing"
    fi
done

echo
echo "[4] CHECKING SERVER JAVASCRIPT"

node --check server.js
if [ $? -eq 0 ]; then
    echo "PASS: server.js syntax is valid"
else
    echo "FAIL: server.js has a syntax error"
fi

echo
echo "[5] CHECKING INSTALLED DEPENDENCIES"

for PACKAGE in express cors dotenv axios ethers @solana/web3.js bitcoinjs-lib helmet
do
    if npm ls "$PACKAGE" --depth=0 >/dev/null 2>&1; then
        echo "PASS: $PACKAGE"
    else
        echo "FAIL: $PACKAGE is missing or not installed correctly"
    fi
done

echo
echo "[6] TESTING BACKEND HEALTH"

curl -sS --max-time 10 \
  -w "\nHTTP STATUS: %{http_code}\n" \
  "$BASE/api/health"

echo
echo "[7] TESTING COIN API"

curl -sS --max-time 10 \
  -w "\nHTTP STATUS: %{http_code}\n" \
  "$BASE/api/coins"

echo
echo "[8] TESTING BLOCKCHAIN ENGINE API"

curl -sS --max-time 20 \
  -w "\nHTTP STATUS: %{http_code}\n" \
  "$BASE/api/engines"

echo
echo "[9] TESTING WALLET DASHBOARD"

curl -sS --max-time 10 \
  -o /dev/null \
  -w "HTTP STATUS: %{http_code}\n" \
  "$BASE/"

echo
echo "[10] TESTING NETWORK CONNECTIVITY"

for URL in \
"https://mempool.space/api/blocks/tip/height" \
"https://ethereum-rpc.publicnode.com" \
"https://api.mainnet-beta.solana.com"
do
    echo
    echo "Testing: $URL"
    curl -sS -L --max-time 10 -o /dev/null \
      -w "HTTP STATUS: %{http_code}\n" "$URL" || echo "Network request failed"
done

echo
echo "======================================"
echo "       WALLETPILL TEST FINISHED"
echo "======================================"
echo "Send the complete output for analysis."
