const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const pool = require("./db");

const router = express.Router();

const ASSETS = ["BTC", "ETH", "USDT", "SOL", "LTC", "DOGE", "PGC"];

function makeToken(user) {
  if (!process.env.JWT_SECRET) {
    throw new Error("JWT_SECRET is not configured");
  }

  return jwt.sign(
    { sub: String(user.id), role: user.role, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: "12h" }
  );
}

function authRequired(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ")
    ? header.slice(7)
    : "";

  if (!token) {
    return res.status(401).json({ error: "Authentication required" });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

function customerOnly(req, res, next) {
  if (req.user.role !== "customer") {
    return res.status(403).json({ error: "Customer access required" });
  }
  next();
}

function adminOnly(req, res, next) {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Administrator access required" });
  }
  next();
}

function workerOnly(req, res, next) {
  const supplied = req.headers["x-blockchain-worker-token"] || "";
  const expected = process.env.BLOCKCHAIN_WORKER_TOKEN || "";

  const a = Buffer.from(String(supplied));
  const b = Buffer.from(String(expected));

  if (!expected || a.length !== b.length ||
      !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Worker authentication failed" });
  }
  next();
}

function validAmount(value) {
  return typeof value === "string" &&
    /^(?:0|[1-9]\d{0,17})(?:\.\d{1,18})?$/.test(value) &&
    Number(value) > 0;
}

async function getOrCreateAccount(client, customerId, asset) {
  const result = await client.query(
    `INSERT INTO wallet_accounts(customer_id, asset)
     VALUES($1, $2)
     ON CONFLICT(customer_id, asset)
     DO UPDATE SET asset = EXCLUDED.asset
     RETURNING *`,
    [customerId, asset]
  );
  return result.rows[0];
}

// CUSTOMER REGISTRATION
router.post("/auth/register", async (req, res) => {
  try {
    const { email, password, fullName } = req.body || {};

    if (!email || !password || !fullName ||
        String(password).length < 10) {
      return res.status(400).json({
        error: "Email, full name and password (minimum 10 characters) required"
      });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const passwordHash = await bcrypt.hash(String(password), 12);

    const result = await pool.query(
      `INSERT INTO customers(email, password_hash, full_name)
       VALUES($1, $2, $3)
       RETURNING id, email, full_name, role`,
      [normalizedEmail, passwordHash, String(fullName).trim()]
    );

    const user = result.rows[0];

    res.status(201).json({
      success: true,
      customer: user,
      token: makeToken(user)
    });
  } catch (err) {
    if (err.code === "23505") {
      return res.status(409).json({ error: "Email already registered" });
    }
    console.error(err);
    res.status(500).json({ error: "Registration failed" });
  }
});

// CUSTOMER LOGIN
router.post("/auth/login", async (req, res) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");

    const result = await pool.query(
      `SELECT id, email, full_name, role, status, password_hash
       FROM customers WHERE email = $1`,
      [email]
    );

    const user = result.rows[0];

    if (!user || user.role !== "customer" ||
        user.status !== "ACTIVE" ||
        !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Invalid login details" });
    }

    res.json({
      success: true,
      customer: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        role: user.role
      },
      token: makeToken(user)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

// SEPARATE ADMINISTRATOR LOGIN
router.post("/admin/login", async (req, res) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");

    const result = await pool.query(
      `SELECT id, email, full_name, role, status, password_hash
       FROM customers WHERE email = $1 AND role = 'admin'`,
      [email]
    );

    const user = result.rows[0];

    if (!user || user.status !== "ACTIVE" ||
        !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Invalid administrator login" });
    }

    res.json({
      success: true,
      administrator: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        role: user.role
      },
      token: makeToken(user)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Administrator login failed" });
  }
});

// CUSTOMER WALLET BALANCES
router.get("/customer/balances",
  authRequired, customerOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT asset, balance
         FROM wallet_accounts
         WHERE customer_id = $1
         ORDER BY asset`,
        [req.user.sub]
      );
      res.json({ success: true, balances: result.rows });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Could not load balances" });
    }
  }
);

// CUSTOMER TRANSACTION HISTORY
router.get("/customer/ledger",
  authRequired, customerOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT id, asset, transaction_type, direction,
                amount, balance_after, reference, description, created_at
         FROM ledger_transactions
         WHERE customer_id = $1
         ORDER BY created_at DESC
         LIMIT 200`,
        [req.user.sub]
      );
      res.json({ success: true, transactions: result.rows });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Could not load ledger" });
    }
  }
);

// CUSTOMER SUBMITS A DEPOSIT TRANSACTION FOR VERIFICATION.
// This does NOT credit a wallet.
router.post("/customer/deposit-intents",
  authRequired, customerOnly, async (req, res) => {
    try {
      const { asset, network, txHash, amount } = req.body || {};
      const cleanAsset = String(asset || "").toUpperCase();

      if (!ASSETS.includes(cleanAsset) || !network ||
          !txHash || !validAmount(String(amount || ""))) {
        return res.status(400).json({
          error: "Valid asset, network, transaction hash and amount required"
        });
      }

      const result = await pool.query(
        `INSERT INTO deposits
          (customer_id, asset, network, tx_hash, amount)
         VALUES($1, $2, $3, $4, $5)
         RETURNING id, asset, network, tx_hash, amount, status, created_at`,
        [req.user.sub, cleanAsset, String(network), String(txHash), String(amount)]
      );

      res.status(201).json({
        success: true,
        message: "Deposit submitted. Awaiting independent blockchain verification.",
        deposit: result.rows[0]
      });
    } catch (err) {
      if (err.code === "23505") {
        return res.status(409).json({
          error: "This transaction has already been submitted"
        });
      }
      console.error(err);
      res.status(500).json({ error: "Deposit submission failed" });
    }
  }
);

// TRUSTED BLOCKCHAIN SCANNER ONLY.
// Scanner must independently verify chain, network, asset, hash,
// destination address, amount and required confirmations before calling.
router.post("/internal/deposits/confirm",
  workerOnly, async (req, res) => {
    try {
      const {
        depositId, txHash, asset, network,
        amount, confirmations, requiredConfirmations,
        destinationVerified
      } = req.body || {};

      if (!depositId || !txHash || !asset || !network ||
          !validAmount(String(amount || "")) ||
          !Number.isInteger(confirmations) ||
          !Number.isInteger(requiredConfirmations) ||
          requiredConfirmations < 1 ||
          confirmations < requiredConfirmations ||
          destinationVerified !== true) {
        return res.status(400).json({
          error: "Complete verified blockchain evidence is required"
        });
      }

      const result = await pool.query(
        `UPDATE deposits
         SET status = 'CONFIRMED',
             confirmations = $1,
             required_confirmations = $2,
             blockchain_verified = TRUE,
             verified_at = NOW()
         WHERE id = $3
           AND tx_hash = $4
           AND UPPER(asset) = UPPER($5)
           AND network = $6
           AND amount = $7
           AND status = 'PENDING'
         RETURNING id, status, confirmations, required_confirmations`,
        [
          confirmations, requiredConfirmations, depositId,
          txHash, asset, network, amount
        ]
      );

      if (!result.rowCount) {
        return res.status(409).json({
          error: "Deposit not found, mismatched or not pending"
        });
      }

      res.json({ success: true, deposit: result.rows[0] });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Deposit verification update failed" });
    }
  }
);

// ADMIN: VIEW DEPOSITS
router.get("/admin/deposits",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT d.*, c.email AS customer_email
         FROM deposits d
         JOIN customers c ON c.id = d.customer_id
         ORDER BY d.created_at DESC
         LIMIT 300`
      );
      res.json({ success: true, deposits: result.rows });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Could not load deposits" });
    }
  }
);

// ADMIN APPROVAL: ATOMIC, ONE-TIME LEDGER CREDIT.
router.post("/admin/deposits/:id/approve",
  authRequired, adminOnly, async (req, res) => {
    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      const found = await client.query(
        `SELECT * FROM deposits WHERE id = $1 FOR UPDATE`,
        [req.params.id]
      );

      const deposit = found.rows[0];

      if (!deposit) {
        await client.query("ROLLBACK");
        return res.status(404).json({ error: "Deposit not found" });
      }

      if (deposit.status !== "CONFIRMED" ||
          deposit.blockchain_verified !== true ||
          deposit.confirmations < deposit.required_confirmations) {
        await client.query("ROLLBACK");
        return res.status(409).json({
          error: "Deposit cannot be approved before blockchain confirmation"
        });
      }

      const account = await getOrCreateAccount(
        client, deposit.customer_id, deposit.asset
      );

      const locked = await client.query(
        `SELECT * FROM wallet_accounts WHERE id = $1 FOR UPDATE`,
        [account.id]
      );

      const oldBalance = locked.rows[0].balance;
      const newBalance = (
        BigInt(Math.round(Number(oldBalance) * 1e8)) +
        BigInt(Math.round(Number(deposit.amount) * 1e8))
      );

      // Use PostgreSQL numeric arithmetic for the actual stored balance.
      const updated = await client.query(
        `UPDATE wallet_accounts
         SET balance = balance + $1
         WHERE id = $2
         RETURNING balance`,
        [deposit.amount, account.id]
      );

      const reference =
        `DEPOSIT-${deposit.network}-${deposit.asset}-${deposit.tx_hash}`;

      await client.query(
        `INSERT INTO ledger_transactions
          (account_id, customer_id, asset, transaction_type,
           direction, amount, balance_after, reference, description)
         VALUES($1, $2, $3, 'BLOCKCHAIN_DEPOSIT',
                'CREDIT', $4, $5, $6, $7)`,
        [
          account.id, deposit.customer_id, deposit.asset,
          deposit.amount, updated.rows[0].balance, reference,
          `Confirmed blockchain deposit: ${deposit.tx_hash}`
        ]
      );

      await client.query(
        `UPDATE deposits
         SET status = 'APPROVED', approved_by = $1, approved_at = NOW()
         WHERE id = $2`,
        [req.user.sub, deposit.id]
      );

      await client.query("COMMIT");

      res.json({
        success: true,
        message: "Confirmed deposit credited to customer wallet",
        asset: deposit.asset,
        creditedAmount: deposit.amount,
        newBalance: updated.rows[0].balance,
        ledgerReference: reference
      });
    } catch (err) {
      await client.query("ROLLBACK").catch(() => {});
      if (err.code === "23505") {
        return res.status(409).json({
          error: "This deposit has already been credited"
        });
      }
      console.error(err);
      res.status(500).json({ error: "Deposit approval failed" });
    } finally {
      client.release();
    }
  }
);



// ADMINISTRATOR: CUSTOMER WALLET BALANCES
router.get("/admin/balances",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT c.id AS customer_id,
                c.email,
                c.full_name,
                w.asset,
                w.balance
         FROM wallet_accounts w
         JOIN customers c ON c.id = w.customer_id
         ORDER BY c.email, w.asset
         LIMIT 1000`
      );

      res.json({success:true, balances:result.rows});
    } catch(err) {
      console.error(err);
      res.status(500).json({error:"Could not load customer balances"});
    }
  }
);

// ADMINISTRATOR: COMPLETE TRANSACTION LEDGER
router.get("/admin/ledger",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT l.id,
                l.customer_id,
                c.email AS customer_email,
                l.asset,
                l.transaction_type,
                l.direction,
                l.amount,
                l.balance_after,
                l.reference,
                l.description,
                l.created_at
         FROM ledger_transactions l
         JOIN customers c ON c.id = l.customer_id
         ORDER BY l.created_at DESC
         LIMIT 500`
      );

      res.json({success:true, transactions:result.rows});
    } catch(err) {
      console.error(err);
      res.status(500).json({error:"Could not load transaction ledger"});
    }
  }
);

// ADMINISTRATOR: CUSTOMER LIST
router.get("/admin/customers",
  authRequired, adminOnly, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT id, email, full_name, status, created_at
         FROM customers
         WHERE role = 'customer'
         ORDER BY created_at DESC
         LIMIT 500`
      );

      res.json({success:true, customers:result.rows});
    } catch(err) {
      console.error(err);
      res.status(500).json({error:"Could not load customers"});
    }
  }
);


module.exports = router;
