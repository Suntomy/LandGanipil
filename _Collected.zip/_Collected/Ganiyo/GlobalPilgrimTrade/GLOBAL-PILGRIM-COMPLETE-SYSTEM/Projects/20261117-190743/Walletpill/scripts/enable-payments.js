const fs = require('fs');

const file = '.env';

let content = fs.existsSync(file)
  ? fs.readFileSync(file, 'utf8')
  : '';

const settings = {
  FLUTTERWAVE_ENABLED: 'true',
  PAYSTACK_ENABLED: 'true',
  STRIPE_ENABLED: 'true'
};

for (const [key, value] of Object.entries(settings)) {
  const pattern = new RegExp(`^${key}=.*$`, 'm');

  if (pattern.test(content)) {
    content = content.replace(pattern, `${key}=${value}`);
  } else {
    content += `\n${key}=${value}`;
  }
}

fs.writeFileSync(file, content.trim() + '\n', { mode: 0o600 });

console.log('Payment provider switches enabled:');
for (const key of Object.keys(settings)) {
  console.log(`${key}=true`);
}
