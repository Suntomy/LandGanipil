require("dotenv").config();
const axios = require("axios");

const networks = {
 BTC: process.env.BTC_API,
 ETH: process.env.ETH_RPC,
 SOL: process.env.SOL_RPC,
 LTC: process.env.LTC_RPC,
 DOGE: process.env.DOGE_RPC,
 PGC: process.env.PGC_RPC,
 LIGHTNING: process.env.LIGHTNING_RPC
};

async function checkNetwork(coin) {
 try {
  const endpoint = networks[coin];

  if (!endpoint) {
   return {coin,status:"NOT CONFIGURED"};
  }

  if (["BTC","LTC"].includes(coin)) {
   const r = await axios.get(
    endpoint + "/blocks/tip/height",
    {timeout:20000}
   );

   return {
    coin,
    status:"LIVE",
    blockHeight:r.data
   };
  }

  if (coin === "ETH") {
   const r = await axios.post(endpoint,{
    jsonrpc:"2.0",
    method:"eth_blockNumber",
    params:[],
    id:1
   },{timeout:20000});

   return {
    coin,
    status:"LIVE",
    blockHeight:parseInt(r.data.result,16)
   };
  }

  if (coin === "SOL") {
   const r = await axios.post(endpoint,{
    jsonrpc:"2.0",
    method:"getSlot",
    params:[],
    id:1
   },{timeout:20000});

   return {
    coin,
    status:"LIVE",
    blockHeight:r.data.result
   };
  }

  return {
   coin,
   status:"RPC CONFIGURED - ADAPTER REQUIRED"
  };

 } catch(e) {
  return {
   coin,
   status:"CONNECTION ERROR",
   message:e.message
  };
 }
}

async function checkAll() {
 return Promise.all(
  Object.keys(networks).map(checkNetwork)
 );
}

module.exports={checkNetwork,checkAll};
