'use strict';

const config = require('./config');
const chains = require('./blockchains');
const payments = require('./payments');

function getIntegrationStatus() {
  return {
    application: config.app.name,
    environment: config.app.environment,
    security: {
      realWithdrawalsEnabled:
        config.security.realWithdrawalsEnabled,
      realDepositsEnabled:
        config.security.realDepositsEnabled,
      withdrawalApprovalRequired:
        config.security.requireWithdrawalApproval
    },
    blockchains: chains.listNetworks(),
    paymentProviders: payments.listProviders()
  };
}

module.exports = { getIntegrationStatus };
