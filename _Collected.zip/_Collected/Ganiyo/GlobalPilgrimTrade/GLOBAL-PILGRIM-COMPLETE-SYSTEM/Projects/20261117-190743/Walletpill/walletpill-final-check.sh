#!/data/data/com.termux/files/usr/bin/bash

APP="$HOME/Walletpill"
REPORT="$HOME/Walletpill_BACKUPS/FINAL_CHECK_$(date +%Y%m%d_%H%M%S).txt"

mkdir -p "$HOME/Walletpill_BACKUPS"
cd "$APP" || exit 1

exec > >(tee "$REPORT") 2>&1

echo "========================================"
echo "       WALLETPILL FINAL SYSTEM CHECK"
echo "========================================"

FAIL=0

echo
echo "[1] NODE AND NPM"
node --version
npm --version

echo
echo "[2] REQUIRED FILES"

for f in server.js package.json public/index.html \
admin/dashboard.html core/db.js core/routes.js database/schema.sql; do
    if [ -f "$f" ]; then
        echo "PASS: $f"
    else
        echo "FAIL: $f missing"
        FAIL=$((FAIL+1))
    fi
done

echo
echo "[3] JAVASCRIPT SYNTAX"

while IFS= read -r -d '' f; do
    if node --check "$f" >/dev/null 2>&1; then
        echo "PASS: $f"
    else
        echo "FAIL: $f"
        node --check "$f"
        FAIL=$((FAIL+1))
    fi
done < <(find . -type f -name '*.js' \
    ! -path './node_modules/*' \
    ! -path './.git/*' -print0)

echo
echo "[4] JSON VALIDATION"

while IFS= read -r -d '' f; do
    if node -e 'JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"))' "$f" 2>/dev/null; then
        echo "PASS: $f"
    else
        echo "FAIL: $f"
        FAIL=$((FAIL+1))
    fi
done < <(find . -type f -name '*.json' \
    ! -path './node_modules/*' \
    ! -path './.git/*' -print0)

echo
echo "[5] DEPENDENCIES"

if npm ls --depth=0; then
    echo "PASS: dependency check"
else
    echo "WARNING: dependency problems found"
    FAIL=$((FAIL+1))
fi

echo
echo "[6] ENVIRONMENT FILE"

if [ -f .env ]; then
    echo "PASS: .env exists"
else
    echo "FAIL: .env missing"
    FAIL=$((FAIL+1))
fi

echo
echo "[7] PM2 STATUS"
npx --no-install pm2 status

echo
echo "[8] PORT 3000"
if command -v ss >/dev/null 2>&1; then
    ss -ltnp 2>/dev/null | grep ':3000' || echo "No listener on port 3000"
fi

echo
echo "[9] CUSTOMER DASHBOARD HTTP CHECK"
curl -sS -o /dev/null -w "HTTP status: %{http_code}\n" \
--max-time 8 http://127.0.0.1:3000/

echo
echo "[10] ADMIN DASHBOARD HTTP CHECK"
curl -sS -o /dev/null -w "HTTP status: %{http_code}\n" \
--max-time 8 http://127.0.0.1:3000/admin/dashboard.html

echo
echo "[11] HEALTH API CHECK"
curl -sS --max-time 8 http://127.0.0.1:3000/api/health
echo

echo
echo "[12] RECENT SERVER ERRORS"
npx --no-install pm2 logs walletpill --lines 30 --nostream 2>&1

echo
echo "========================================"
echo "FINAL CHECK SUMMARY"
echo "========================================"
echo "Failed checks counted: $FAIL"
echo "Report: $REPORT"

if [ "$FAIL" -eq 0 ]; then
    echo "RESULT: BASIC CHECKS PASSED"
else
    echo "RESULT: PROBLEMS FOUND - REVIEW REPORT"
fi

echo "========================================"
