(() => {
  const API = "/api/core";
  const TOKEN_KEY = "walletpill_customer_token";

  const root = document.createElement("section");
  root.id = "walletpill-customer-app";

  root.innerHTML = `
  <style>
  #walletpill-customer-app {
    font-family: Arial, sans-serif;
    padding: 20px;
    max-width: 1100px;
    margin: 20px auto;
    color: #172033;
  }
  #walletpill-customer-app .wp-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 12px;
    padding: 18px;
    margin-bottom: 15px;
    overflow-x: auto;
  }
  #walletpill-customer-app input,
  #walletpill-customer-app button {
    padding: 12px;
    margin: 5px 0;
    border-radius: 7px;
    border: 1px solid #ccc;
  }
  #walletpill-customer-app button {
    cursor: pointer;
    background: #153d70;
    color: white;
  }
  #walletpill-customer-app table {
    width: 100%;
    border-collapse: collapse;
  }
  #walletpill-customer-app td,
  #walletpill-customer-app th {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
  }
  </style>

  <div class="wp-card">
    <h2>Walletpill Customer Wallet</h2>
    <p id="wp-customer-message">Connect to your Walletpill account.</p>
  </div>

  <div id="wp-customer-login" class="wp-card">
    <h3>Customer Login</h3>
    <form id="wp-login-form">
      <input id="wp-email" type="email" placeholder="Email address" required>
      <input id="wp-password" type="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>

    <hr>
    <h3>Create Customer Account</h3>
    <form id="wp-register-form">
      <input id="wp-name" placeholder="Full name" required>
      <input id="wp-new-email" type="email" placeholder="Email address" required>
      <input id="wp-new-password" type="password" minlength="10"
       placeholder="Password (minimum 10 characters)" required>
      <button type="submit">Register</button>
    </form>
  </div>

  <div id="wp-customer-dashboard" hidden>
    <div class="wp-card">
      <h3>My Wallet Balances</h3>
      <div id="wp-balances">Loading...</div>
      <button id="wp-refresh">Refresh Balances</button>
      <button id="wp-logout">Logout</button>
    </div>

    <div class="wp-card">
      <h3>My Transaction History</h3>
      <div id="wp-history">Loading...</div>
    </div>
  </div>
  `;

  document.body.appendChild(root);

  const $ = id => root.querySelector("#" + id);

  function message(text) {
    $("wp-customer-message").textContent = text;
  }

  async function api(path, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);

    const response = await fetch(API + path, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(token ? {Authorization:"Bearer " + token} : {}),
        ...(options.headers || {})
      }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    return data;
  }

  function cell(value) {
    const td = document.createElement("td");
    td.textContent = value == null ? "" : String(value);
    return td;
  }

  function renderTable(target, columns, rows) {
    const table = document.createElement("table");
    const head = document.createElement("tr");

    columns.forEach(c => {
      const th = document.createElement("th");
      th.textContent = c.label;
      head.appendChild(th);
    });

    table.appendChild(head);

    rows.forEach(row => {
      const tr = document.createElement("tr");
      columns.forEach(c => tr.appendChild(cell(row[c.key])));
      table.appendChild(tr);
    });

    target.replaceChildren(table);

    if (!rows.length) {
      target.textContent = "No records found.";
    }
  }

  async function loadDashboard() {
    $("wp-customer-login").hidden = true;
    $("wp-customer-dashboard").hidden = false;

    try {
      const [balances, ledger] = await Promise.all([
        api("/customer/balances"),
        api("/customer/ledger")
      ]);

      renderTable(
        $("wp-balances"),
        [
          {key:"asset",label:"Coin"},
          {key:"balance",label:"Available Balance"}
        ],
        balances.balances
      );

      renderTable(
        $("wp-history"),
        [
          {key:"created_at",label:"Date"},
          {key:"asset",label:"Coin"},
          {key:"transaction_type",label:"Type"},
          {key:"direction",label:"Direction"},
          {key:"amount",label:"Amount"},
          {key:"balance_after",label:"Balance After"},
          {key:"reference",label:"Reference"}
        ],
        ledger.transactions
      );

      message("Connected to your PostgreSQL wallet ledger.");
    } catch(err) {
      message(err.message);
      if (/token|authentication|expired/i.test(err.message)) {
        logout();
      }
    }
  }

  function logout() {
    localStorage.removeItem(TOKEN_KEY);
    $("wp-customer-login").hidden = false;
    $("wp-customer-dashboard").hidden = true;
    message("You have logged out.");
  }

  $("wp-login-form").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const data = await api("/auth/login", {
        method:"POST",
        body:JSON.stringify({
          email:$("wp-email").value,
          password:$("wp-password").value
        })
      });

      localStorage.setItem(TOKEN_KEY, data.token);
      await loadDashboard();
    } catch(err) {
      message(err.message);
    }
  });

  $("wp-register-form").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const data = await api("/auth/register", {
        method:"POST",
        body:JSON.stringify({
          fullName:$("wp-name").value,
          email:$("wp-new-email").value,
          password:$("wp-new-password").value
        })
      });

      localStorage.setItem(TOKEN_KEY, data.token);
      await loadDashboard();
    } catch(err) {
      message(err.message);
    }
  });

  $("wp-refresh").addEventListener("click", loadDashboard);
  $("wp-logout").addEventListener("click", logout);

  if (localStorage.getItem(TOKEN_KEY)) {
    loadDashboard();
  }
})();
