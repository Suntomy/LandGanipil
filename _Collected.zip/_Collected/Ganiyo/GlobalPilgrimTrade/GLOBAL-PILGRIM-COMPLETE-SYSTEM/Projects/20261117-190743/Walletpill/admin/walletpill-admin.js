(() => {
  const API = "/api/core";
  const TOKEN_KEY = "walletpill_admin_token";

  const root = document.createElement("section");
  root.id = "walletpill-admin-app";

  root.innerHTML = `
  <style>
  #walletpill-admin-app {
    font-family:Arial,sans-serif;
    max-width:1200px;
    margin:20px auto;
    padding:20px;
    color:#172033;
  }
  #walletpill-admin-app .card {
    background:white;
    border:1px solid #ddd;
    border-radius:12px;
    padding:18px;
    margin-bottom:18px;
    overflow-x:auto;
  }
  #walletpill-admin-app input,
  #walletpill-admin-app button {
    padding:11px;
    margin:5px 0;
    border:1px solid #ccc;
    border-radius:6px;
  }
  #walletpill-admin-app button {
    background:#153d70;
    color:white;
    cursor:pointer;
  }
  #walletpill-admin-app table {
    width:100%;
    border-collapse:collapse;
  }
  #walletpill-admin-app th,
  #walletpill-admin-app td {
    border-bottom:1px solid #ddd;
    padding:10px;
    text-align:left;
  }
  </style>

  <div class="card">
    <h2>Walletpill Administrator</h2>
    <p id="admin-message">Administrator authentication required.</p>
  </div>

  <div class="card" id="admin-login">
    <h3>Administrator Login</h3>
    <form id="admin-login-form">
      <input id="admin-email" type="email"
        placeholder="Administrator email" required>
      <input id="admin-password" type="password"
        placeholder="Administrator password" required>
      <button type="submit">Administrator Login</button>
    </form>
  </div>

  <div id="admin-dashboard" hidden>
    <div class="card">
      <h3>Customer Wallet Balances</h3>
      <div id="admin-balances">Loading...</div>
    </div>

    <div class="card">
      <h3>Transaction Ledger</h3>
      <div id="admin-ledger">Loading...</div>
    </div>

    <div class="card">
      <h3>Deposit Management</h3>
      <div id="admin-deposits">Loading...</div>
    </div>

    <div class="card">
      <button id="admin-refresh">Refresh All Records</button>
      <button id="admin-logout">Logout</button>
    </div>
  </div>
  `;

  document.body.appendChild(root);

  const $ = id => root.querySelector("#" + id);

  function message(value) {
    $("admin-message").textContent = value;
  }

  async function api(path, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);

    const response = await fetch(API + path, {
      ...options,
      headers: {
        "Content-Type":"application/json",
        ...(token ? {Authorization:"Bearer " + token} : {}),
        ...(options.headers || {})
      }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    return data;
  }

  function makeTable(target, columns, rows, action) {
    const table = document.createElement("table");
    const head = document.createElement("tr");

    columns.forEach(c => {
      const th = document.createElement("th");
      th.textContent = c.label;
      head.appendChild(th);
    });

    if (action) {
      const th = document.createElement("th");
      th.textContent = "Action";
      head.appendChild(th);
    }

    table.appendChild(head);

    rows.forEach(row => {
      const tr = document.createElement("tr");

      columns.forEach(c => {
        const td = document.createElement("td");
        td.textContent = row[c.key] == null
          ? ""
          : String(row[c.key]);
        tr.appendChild(td);
      });

      if (action) {
        const td = document.createElement("td");
        action(row, td);
        tr.appendChild(td);
      }

      table.appendChild(tr);
    });

    target.replaceChildren(table);

    if (!rows.length) {
      target.textContent = "No records found.";
    }
  }

  async function loadDashboard() {
    $("admin-login").hidden = true;
    $("admin-dashboard").hidden = false;

    try {
      const [balances, ledger, deposits] = await Promise.all([
        api("/admin/balances"),
        api("/admin/ledger"),
        api("/admin/deposits")
      ]);

      makeTable(
        $("admin-balances"),
        [
          {key:"customer_id",label:"Customer ID"},
          {key:"email",label:"Customer"},
          {key:"asset",label:"Coin"},
          {key:"balance",label:"Balance"}
        ],
        balances.balances
      );

      makeTable(
        $("admin-ledger"),
        [
          {key:"created_at",label:"Date"},
          {key:"customer_email",label:"Customer"},
          {key:"asset",label:"Coin"},
          {key:"transaction_type",label:"Type"},
          {key:"direction",label:"Direction"},
          {key:"amount",label:"Amount"},
          {key:"balance_after",label:"Balance After"},
          {key:"reference",label:"Reference"}
        ],
        ledger.transactions
      );

      makeTable(
        $("admin-deposits"),
        [
          {key:"id",label:"ID"},
          {key:"customer_email",label:"Customer"},
          {key:"asset",label:"Coin"},
          {key:"network",label:"Network"},
          {key:"tx_hash",label:"Transaction Hash"},
          {key:"amount",label:"Amount"},
          {key:"confirmations",label:"Confirmations"},
          {key:"status",label:"Status"}
        ],
        deposits.deposits,
        (row, td) => {
          if (row.status !== "CONFIRMED") {
            td.textContent = "Not ready for approval";
            return;
          }

          const button = document.createElement("button");
          button.textContent = "Approve Deposit";

          button.addEventListener("click", async () => {
            if (!confirm(
              "Approve this independently verified blockchain deposit?"
            )) return;

            try {
              await api(
                "/admin/deposits/" + encodeURIComponent(row.id) + "/approve",
                {method:"POST",body:"{}"}
              );

              message("Deposit credited successfully.");
              await loadDashboard();
            } catch(err) {
              message(err.message);
            }
          });

          td.appendChild(button);
        }
      );

      message("Administrator connected to PostgreSQL.");
    } catch(err) {
      message(err.message);

      if (/token|authentication|expired/i.test(err.message)) {
        logout();
      }
    }
  }

  function logout() {
    localStorage.removeItem(TOKEN_KEY);
    $("admin-login").hidden = false;
    $("admin-dashboard").hidden = true;
    message("Administrator logged out.");
  }

  $("admin-login-form").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const data = await api("/admin/login", {
        method:"POST",
        body:JSON.stringify({
          email:$("admin-email").value,
          password:$("admin-password").value
        })
      });

      localStorage.setItem(TOKEN_KEY, data.token);
      await loadDashboard();
    } catch(err) {
      message(err.message);
    }
  });

  $("admin-refresh").addEventListener("click", loadDashboard);
  $("admin-logout").addEventListener("click", logout);

  if (localStorage.getItem(TOKEN_KEY)) {
    loadDashboard();
  }
})();
