#!/data/data/com.termux/files/usr/bin/bash

set -u

APP="$HOME/Walletpill"
cd "$APP" || exit 1

echo "=========================================="
echo " WALLETPILL PM2 FINAL REPAIR ROBOT"
echo "=========================================="

echo "[1] Checking server syntax..."

node --check server.js || {
    echo "ERROR: server.js has syntax errors."
    exit 1
}

echo "[2] Stopping duplicate Walletpill PM2 processes..."

npx --no-install pm2 jlist > /tmp/walletpill-pm2.json

node -e '
const fs=require("fs");
const list=JSON.parse(fs.readFileSync("/tmp/walletpill-pm2.json"));
for(const p of list) {
  if(["walletpill","walletpi"].includes(String(p.name).toLowerCase())) {
    console.log(p.pm_id);
  }
}
' > /tmp/walletpill-ids.txt

while read -r id; do
    [ -n "$id" ] || continue
    echo "Stopping PM2 process ID $id"
    npx --no-install pm2 delete "$id" || true
done < /tmp/walletpill-ids.txt

echo "[3] Inspecting port 3000..."

PIDS=""

if command -v fuser >/dev/null 2>&1; then
    PIDS=$(fuser -n tcp 3000 2>/dev/null || true)
fi

for pid in $PIDS; do
    [ -r "/proc/$pid/cmdline" ] || continue

    CMD=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)

    echo "Port owner PID: $pid"
    echo "Command: $CMD"

    case "$CMD" in
        *"$APP"*)
            echo "Confirmed Walletpill process. Stopping it."
            kill "$pid" 2>/dev/null || true
            ;;
        *)
            echo "STOP: Port 3000 belongs to another or unidentified process."
            echo "No process was killed. Please send this diagnostic:"
            echo "$CMD"
            exit 2
            ;;
    esac
done

sleep 3

echo "[4] Checking port availability..."

if command -v ss >/dev/null 2>&1 &&
   ss -ltn 2>/dev/null | grep -q ':3000'; then
    echo "ERROR: Port 3000 is still occupied."
    echo "No force-kill attempted."
    exit 2
fi

echo "[5] Starting exactly one Walletpill PM2 process..."

npx --no-install pm2 start server.js \
    --name walletpill \
    --cwd "$APP" \
    --time

if [ $? -ne 0 ]; then
    echo "ERROR: PM2 could not start Walletpill."
    exit 1
fi

echo "[6] Saving PM2 process list..."

npx --no-install pm2 save

sleep 4

echo "[7] Checking PM2 status..."
npx --no-install pm2 status

echo
echo "[8] Testing Walletpill HTTP service..."

curl -i --max-time 8 http://127.0.0.1:3000/api/health

echo
echo "=========================================="
echo " WALLETPILL REPAIR FINISHED"
echo "=========================================="

echo "For server logs run:"
echo "npx pm2 logs walletpill --lines 40"
