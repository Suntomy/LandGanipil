'use strict';

const config = require('../config');

const networks = config.blockchain;

function listNetworks() {
  return Object.entries(networks).map(([name, item]) => ({
    name,
    enabled: item.enabled,
    network: item.network,
    configured: Boolean(item.rpcUrl),
    rpcConfigured: Boolean(item.rpcUrl),
    withdrawalReady: false
  }));
}

function getNetwork(name) {
  const network = networks[name];

  if (!network) {
    throw new Error(`Unsupported blockchain: ${name}`);
  }

  return network;
}

async function checkRpc(name) {
  const network = getNetwork(name);

  if (!network.enabled || !network.rpcUrl) {
    return {
      network: name,
      status: 'NOT_CONFIGURED'
    };
  }

  try {
    const response = await fetch(network.rpcUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_chainId',
        params: []
      }),
      signal: AbortSignal.timeout(8000)
    });

    const data = await response.json();

    return {
      network: name,
      status: response.ok && !data.error ? 'RESPONDING' : 'RPC_ERROR',
      result: data.result || null,
      error: data.error?.message || null
    };
  } catch (error) {
    return {
      network: name,
      status: 'CONNECTION_FAILED',
      error: error.message
    };
  }
}

module.exports = {
  listNetworks,
  getNetwork,
  checkRpc
};
