#!/data/data/com.termux/files/usr/bin/bash

set -e

cd "$(dirname "$0")"

echo "======================================"
echo " WALLETPILL CENTRAL NETWORK INSTALLER"
echo "======================================"

mkdir -p network public/network logs backups

# Backup existing project configuration
tar --exclude=node_modules \
    --exclude=backups \
    -czf "backups/network-backup-$(date +%Y%m%d-%H%M%S).tar.gz" \
    . 2>/dev/null || true

# ======================================
# CENTRAL NETWORK CONFIGURATION
# ======================================

cat > network/config.js <<'EOF'
'use strict';

module.exports = {
    host: process.env.HOST || '0.0.0.0',
    port: Number(process.env.PORT || 3000),

    websocketPath: '/admin-live',

    healthEndpoint: '/api/health',

    reconnectInterval: 5000,

    heartbeatInterval: 15000,

    modules: [
        'admin',
        'customers',
        'wallets',
        'payments',
        'deposits',
        'withdrawals',
        'transfers',
        'mining',
        'trading',
        'futures',
        'pgc',
        'blockchain',
        'database',
        'security',
        'reports',
        'notifications'
    ]
};
EOF

# ======================================
# LIVE NETWORK CLIENT
# ======================================

cat > public/network-client.js <<'EOF'
(function () {
'use strict';

const Network = {

    connected: false,
    socket: null,
    listeners: {},

    log(message) {
        console.log('[WALLETPILL NETWORK]', message);
    },

    on(event, callback) {

        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }

        this.listeners[event].push(callback);

    },

    emit(event, data) {

        (this.listeners[event] || []).forEach(callback => {

            try {
                callback(data);
            } catch(error) {
                console.error(error);
            }

        });

        window.dispatchEvent(
            new CustomEvent('walletpill:' + event, {
                detail: data
            })
        );

    },

    connect() {

        if (this.socket &&
            (this.socket.readyState === WebSocket.OPEN ||
             this.socket.readyState === WebSocket.CONNECTING)) {
            return;
        }

        const protocol =
            location.protocol === 'https:' ? 'wss:' : 'ws:';

        const address =
            protocol + '//' +
            location.host +
            '/admin-live';

        this.socket = new WebSocket(address);

        this.socket.onopen = () => {

            this.connected = true;

            this.emit('connected', {
                status: 'ONLINE'
            });

            this.log('Connected');

        };

        this.socket.onmessage = event => {

            try {

                const message = JSON.parse(event.data);

                this.emit('message', message);

                this.emit(message.type, message);

            } catch(error) {

                this.log('Invalid network message');

            }

        };

        this.socket.onclose = () => {

            this.connected = false;

            this.emit('disconnected', {
                status: 'OFFLINE'
            });

            setTimeout(() => this.connect(), 5000);

        };

        this.socket.onerror = error => {

            this.log('Connection error');

        };

    },

    async request(endpoint, options = {}) {

        const response = await fetch(endpoint, {

            credentials: 'same-origin',

            ...options,

            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }

        });

        const data = await response.json();

        if (!response.ok) {

            throw new Error(
                data.error || 'Network request failed'
            );

        }

        return data;

    },

    async health() {

        try {

            const result = await this.request('/api/health');

            this.emit('health', result);

            return result;

        } catch(error) {

            this.emit('health-error', error.message);

            return {
                status: 'OFFLINE',
                error: error.message
            };

        }

    }

};

window.WalletpillNetwork = Network;

Network.connect();

Network.health();

})();
EOF

# ======================================
# MODULE REGISTRY
# ======================================

cat > network/modules.json <<'EOF'
{
  "admin": "Admin dashboard",
  "customers": "Customer management",
  "wallets": "Wallet management",
  "payments": "Payment processing",
  "deposits": "Deposit management",
  "withdrawals": "Withdrawal management",
  "transfers": "External transfers",
  "mining": "Mining engine",
  "trading": "Spot trading",
  "futures": "Futures trading",
  "pgc": "Pilgrim Coin",
  "blockchain": "Blockchain connections",
  "database": "Database management",
  "security": "Security monitoring",
  "reports": "Financial reports",
  "notifications": "Notifications"
}
EOF

# ======================================
# INSTALL CLIENT IN ALL HTML FILES
# ======================================

node <<'NODE'
const fs = require('fs');
const path = require('path');

const root = process.cwd();

const excluded = new Set([
    'node_modules',
    '.git',
    'backups'
]);

let scanned = 0;
let updated = 0;
let skipped = 0;

function scan(directory) {

    for (const item of fs.readdirSync(directory, {
        withFileTypes: true
    })) {

        if (excluded.has(item.name)) continue;

        const file = path.join(directory, item.name);

        if (item.isDirectory()) {
            scan(file);
            continue;
        }

        if (!item.name.endsWith('.html')) continue;

        scanned++;

        let content = fs.readFileSync(file, 'utf8');

        if (content.includes('network-client.js')) {
            skipped++;
            continue;
        }

        const tag =
            '<script src="/network-client.js" defer></script>';

        if (/<\/body>/i.test(content)) {

            content = content.replace(
                /<\/body>/i,
                tag + '\n</body>'
            );

        } else {

            content += '\n' + tag + '\n';

        }

        fs.writeFileSync(file, content);

        updated++;

        console.log('CONNECTED:', path.relative(root, file));

    }

}

scan(root);

console.log('\nHTML FILES SCANNED:', scanned);
console.log('HTML FILES CONNECTED:', updated);
console.log('ALREADY CONNECTED:', skipped);
NODE

# ======================================
# NETWORK INSTALLATION REPORT
# ======================================

cat > network/INSTALLATION_REPORT.txt <<EOF
WALLETPILL NETWORK INSTALLATION

Installation date: $(date)

Central configuration: network/config.js

Network client: public/network-client.js

Module registry: network/modules.json

WebSocket path: /admin-live

Health endpoint: /api/health

Status: FRONTEND NETWORK CLIENT INSTALLED

IMPORTANT:
Backend WebSocket and health endpoints must
exist and be registered in the main server.
EOF

echo ""
echo "======================================"
echo " NETWORK INSTALLATION COMPLETED"
echo "======================================"

echo "Checking JavaScript syntax..."

node --check public/network-client.js

echo ""
echo "Installed network files:"
find network public -maxdepth 2 -type f

echo ""
echo "Report:"
cat network/INSTALLATION_REPORT.txt

echo ""
echo "NEXT: Connect network-client.js to server.js"
