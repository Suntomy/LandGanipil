'use strict';

require('dotenv').config();

const config = require('../integrations/config');
const chains = require('../integrations/blockchains');
const payments = require('../integrations/payments');
const health = require('../integrations/health');

console.log('\n========== WALLETPILL INTEGRATIONS ==========\n');

console.log('Application:', config.app.name);
console.log('Environment:', config.app.environment);

console.log('\nBLOCKCHAIN NETWORKS');
console.table(chains.listNetworks());

console.log('\nPAYMENT PROVIDERS');
console.table(payments.listProviders());

console.log('\nSECURITY');
console.log({
  realWithdrawalsEnabled:
    config.security.realWithdrawalsEnabled,
  realDepositsEnabled:
    config.security.realDepositsEnabled
});

console.log('\nFULL STATUS');
console.log(JSON.stringify(health.getIntegrationStatus(), null, 2));

console.log('\nConfiguration test completed.');
