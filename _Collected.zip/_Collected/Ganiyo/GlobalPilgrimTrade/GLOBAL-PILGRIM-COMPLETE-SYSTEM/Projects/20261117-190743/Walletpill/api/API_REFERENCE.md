# Walletpill Backend API

Base URL:
https://YOUR-PERMANENT-WALLETPILL-DOMAIN

Existing API endpoints to verify:

## Authentication

POST /api/core/auth/register
POST /api/core/auth/login
POST /api/core/admin/login

## Customer

GET /api/core/customer/balances
GET /api/core/customer/ledger
POST /api/core/customer/deposit-intents

## Administrator

GET /api/core/admin/deposits
POST /api/core/admin/deposits/:id/approve
GET /api/core/admin/balances
GET /api/core/admin/ledger
GET /api/core/admin/customers

## Internal worker

POST /api/core/internal/deposits/confirm

The internal worker endpoint must remain protected by its
private authentication secret.

## Health

GET /api/health

Customer and administrator endpoints require the
authentication expected by the existing backend.

This document describes existing routes; it does not
certify that every route is operational.
