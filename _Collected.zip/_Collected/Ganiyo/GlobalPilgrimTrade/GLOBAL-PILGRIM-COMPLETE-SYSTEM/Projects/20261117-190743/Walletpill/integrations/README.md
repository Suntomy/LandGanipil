# Walletpill Blockchain and Payment Integrations

## Supported blockchain configurations

- Bitcoin
- Ethereum
- Litecoin
- Dogecoin
- Solana
- Pilgrim Coin (PGC)

## Supported payment provider configurations

- Flutterwave
- Paystack
- Stripe

## Configuration

Copy .env.integrations.example values into your private .env file.

Set RPC URLs and credentials only from the official provider dashboards.

## Test configuration

Run:

node scripts/test-integrations.js

## Important

This package provides configuration and provider registries.
It does not independently implement blockchain signing,
broadcast transactions, payment verification or withdrawals.

Production transactions require:
- Verified RPC/network configuration.
- Secure wallet signing.
- Address validation.
- Transaction fee calculation.
- Blockchain confirmation monitoring.
- Payment-provider webhook signature verification.
- Idempotency and duplicate-payment protection.
- Database ledger entries and reconciliation.
- Authentication, authorization and audit logs.

Real withdrawals are disabled by default.
Do not store private keys in frontend JavaScript.
