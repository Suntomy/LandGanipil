const express = require("express");
const router = express.Router();
const engine = require("./live-engine");

router.get("/", async (req, res) => {
 try {
  const networks = await engine.checkAll();
  res.json({
   application: "WALLETPILL",
   networks
  });
 } catch (e) {
  res.status(500).json({error:e.message});
 }
});

router.get("/:coin", async (req, res) => {
 const coin = req.params.coin.toUpperCase();
 const allowed = [
  "BTC","ETH","LTC","DOGE","SOL","PGC","LIGHTNING"
 ];

 if (!allowed.includes(coin)) {
  return res.status(404).json({error:"Unknown coin"});
 }

 res.json(await engine.check(coin));
});

module.exports = router;
