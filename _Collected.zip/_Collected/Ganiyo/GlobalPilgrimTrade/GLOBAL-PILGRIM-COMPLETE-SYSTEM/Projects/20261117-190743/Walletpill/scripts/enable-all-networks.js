const fs = require('fs');

const file = '.env';
let content = fs.existsSync(file)
  ? fs.readFileSync(file, 'utf8')
  : '';

const settings = {
  BTC_ENABLED: 'true',
  ETH_ENABLED: 'true',
  LTC_ENABLED: 'true',
  DOGE_ENABLED: 'true',
  SOL_ENABLED: 'true',
  PGC_ENABLED: 'true',

  FLUTTERWAVE_ENABLED: 'true',
  PAYSTACK_ENABLED: 'true',
  STRIPE_ENABLED: 'true',

  ENABLE_WITHDRAWALS: 'false',
  ENABLE_REAL_DEPOSITS: 'false'
};

for (const [key, value] of Object.entries(settings)) {
  const pattern = new RegExp(`^${key}=.*$`, 'm');

  if (pattern.test(content)) {
    content = content.replace(pattern, `${key}=${value}`);
  } else {
    content += `\n${key}=${value}`;
  }
}

fs.writeFileSync(file, content.trim() + '\n', {
  mode: 0o600
});

console.log('Blockchain and payment modules enabled.');
console.log('Real-money transfers remain protected pending verification.');
