'use strict';

module.exports = {
  BTC: {
    name: 'Bitcoin',
    network: 'Bitcoin',
    decimals: 8,
    enabled: true
  },
  ETH: {
    name: 'Ethereum',
    network: 'Ethereum',
    decimals: 18,
    enabled: true
  },
  USDT: {
    name: 'Tether USD',
    network: 'Ethereum',
    decimals: 6,
    enabled: true,
    note: 'Network must match the actual token contract.'
  },
  SOL: {
    name: 'Solana',
    network: 'Solana',
    decimals: 9,
    enabled: true
  },
  LTC: {
    name: 'Litecoin',
    network: 'Litecoin',
    decimals: 8,
    enabled: true
  },
  DOGE: {
    name: 'Dogecoin',
    network: 'Dogecoin',
    decimals: 8,
    enabled: true
  },
  PGC: {
    name: 'Pilgrim Coin',
    network: 'PGC network',
    decimals: 8,
    enabled: false,
    note: 'Configure and verify the actual PGC network before enabling.'
  }
};
