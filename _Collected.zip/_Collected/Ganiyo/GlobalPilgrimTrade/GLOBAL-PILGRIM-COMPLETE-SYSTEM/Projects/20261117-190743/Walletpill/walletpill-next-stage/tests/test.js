'use strict';

const assert = require('assert');
const assets = require('../networks/assets');
const validation = require('../security/validation');
const { verifyDeposit } = require('../deposits/verifier');

assert(validation.validAsset('BTC', assets));
assert(validation.validAsset('ETH', assets));
assert(validation.validAsset('SOL', assets));
assert(!validation.validAsset('UNKNOWN', assets));
assert(!validation.validAsset('PGC', assets));

assert(validation.validAmount('1'));
assert(validation.validAmount('0.00001'));
assert(!validation.validAmount('-1'));
assert(!validation.validAmount('0'));
assert(!validation.validAmount('invalid'));

assert(validation.validTransactionId('a'.repeat(64)));
assert(!validation.validTransactionId('not-a-transaction'));

(async () => {
  const result = await verifyDeposit({});
  assert.strictEqual(result.verified, false);

  console.log('PASS: Walletpill development module tests');
  console.log('PASS: Asset validation');
  console.log('PASS: Amount validation');
  console.log('PASS: Transaction ID validation');
  console.log('PASS: Unconfigured deposit verifier rejects transactions');
  console.log('PASS: PGC remains disabled pending network configuration');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
