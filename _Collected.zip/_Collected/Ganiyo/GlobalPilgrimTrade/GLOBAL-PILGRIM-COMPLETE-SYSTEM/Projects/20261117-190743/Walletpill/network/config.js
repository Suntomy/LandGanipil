'use strict';

module.exports = {
    host: process.env.HOST || '0.0.0.0',
    port: Number(process.env.PORT || 3000),

    websocketPath: '/admin-live',

    healthEndpoint: '/api/health',

    reconnectInterval: 5000,

    heartbeatInterval: 15000,

    modules: [
        'admin',
        'customers',
        'wallets',
        'payments',
        'deposits',
        'withdrawals',
        'transfers',
        'mining',
        'trading',
        'futures',
        'pgc',
        'blockchain',
        'database',
        'security',
        'reports',
        'notifications'
    ]
};
