'use strict';

const service = require('../integrations/wallets/address-service');
const capabilities = require(
  '../integrations/wallets/transaction-capabilities'
);

console.log('\n===== WALLETPILL RECEIVING ADDRESSES =====\n');

for (const [symbol, wallet] of Object.entries(
  service.getAllAddresses()
)) {
  console.log(`${symbol}: ${wallet.address}`);
  console.log(`Network: ${wallet.network}`);
  console.log(`Enabled: ${wallet.enabled}`);
  console.log('-------------------------------');
}

console.log('\n===== TRANSACTION CAPABILITIES =====\n');

console.table(capabilities.getCapabilities());

console.log('\nAddress configuration test completed.');
console.log('Address syntax still requires blockchain verification.');
