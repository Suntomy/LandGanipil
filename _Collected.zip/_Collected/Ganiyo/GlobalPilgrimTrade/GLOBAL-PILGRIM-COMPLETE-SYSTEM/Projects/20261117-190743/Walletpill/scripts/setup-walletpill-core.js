require("dotenv").config();

const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const pool = require("../core/db");

async function main() {
  const schema = fs.readFileSync(
    path.join(__dirname, "../database/schema.sql"),
    "utf8"
  );

  await pool.query(schema);
  console.log("PostgreSQL schema installed.");

  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";

  if (!email || password.length < 12) {
    throw new Error("ADMIN_EMAIL or ADMIN_PASSWORD is missing/invalid");
  }

  const hash = await bcrypt.hash(password, 12);

  const result = await pool.query(
    `INSERT INTO customers(email, password_hash, full_name, role)
     VALUES($1, $2, 'Walletpill Administrator', 'admin')
     ON CONFLICT(email) DO NOTHING
     RETURNING id, email, role`,
    [email, hash]
  );

  if (result.rowCount) {
    console.log("Initial administrator account created.");
  } else {
    console.log("Administrator email already exists; existing password retained.");
  }

  const check = await pool.query("SELECT NOW() AS database_time");
  console.log("Database connection successful:", check.rows[0].database_time);

  await pool.end();
}

main().catch(async err => {
  console.error("SETUP FAILED:", err.message);
  await pool.end().catch(() => {});
  process.exit(1);
});
