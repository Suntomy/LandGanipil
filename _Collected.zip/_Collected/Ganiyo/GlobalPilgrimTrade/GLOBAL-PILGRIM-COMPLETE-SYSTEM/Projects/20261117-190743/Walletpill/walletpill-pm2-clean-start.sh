#!/data/data/com.termux/files/usr/bin/bash

set -u

APP="$HOME/Walletpill"
cd "$APP" || exit 1

echo "===================================="
echo " WALLETPILL PM2 CLEAN START"
echo "===================================="

echo "[1] Checking JavaScript syntax..."
node --check server.js || exit 1

echo "[2] Removing Walletpill PM2 registrations..."

npx --no-install pm2 delete walletpill 2>/dev/null || true
npx --no-install pm2 delete walletpi 2>/dev/null || true

echo "[3] Checking port 3000..."

if command -v ss >/dev/null 2>&1; then
    ss -ltnp 2>/dev/null | grep ':3000' || true
fi

if command -v fuser >/dev/null 2>&1; then
    fuser -v -n tcp 3000 2>&1 || true
fi

echo "[4] Starting Walletpill once..."

npx --no-install pm2 start "$APP/server.js" \
    --name walletpill \
    --cwd "$APP" \
    --time

if [ $? -ne 0 ]; then
    echo "START FAILED. No force execution attempted."
    exit 1
fi

echo "[5] Saving PM2 configuration..."
npx --no-install pm2 save

sleep 4

echo "[6] Checking PM2..."
npx --no-install pm2 status

echo "[7] Checking HTTP health..."
curl -i --max-time 8 http://127.0.0.1:3000/api/health

echo
echo "===================================="
echo " CLEAN START FINISHED"
echo "===================================="
echo "Logs: npx pm2 logs walletpill --lines 40"
