'use strict';

const addresses = require('./address-service');

function getCapabilities() {
  return Object.entries(addresses.getAllAddresses()).map(
    ([symbol, wallet]) => ({
      symbol,
      network: wallet.network,
      receivingAddress: wallet.address,
      receivingConfigured: true,
      sendingConfigured: false,
      transactionSigningConfigured: false,
      blockchainConfirmationMonitoring: false,
      status: 'RECEIVE_ADDRESS_CONFIGURED'
    })
  );
}

module.exports = { getCapabilities };
