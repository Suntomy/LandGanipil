const crypto = require("crypto");
const db = require("../database/db");

function makeReference(prefix) {
    return prefix + "-" +
        Date.now() + "-" +
        crypto.randomBytes(6).toString("hex").toUpperCase();
}

async function createTransaction(data) {

    const serial = makeReference("AG-SN");
    const reference = makeReference("AG-TRX");
    const tracking = makeReference("AG-TRACK");

    const result = await db.query(
        `INSERT INTO gpb_transactions (
            serial_number,
            transaction_reference,
            tracking_number,
            idempotency_key,
            sender_name,
            sender_account,
            sender_bank,
            recipient_name,
            recipient_account,
            recipient_bank,
            payment_provider,
            transaction_type,
            amount,
            currency,
            description,
            transaction_status
        )
        VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,'PENDING'
        )
        ON CONFLICT (idempotency_key) DO NOTHING
        RETURNING *`,
        [
            serial,
            reference,
            tracking,
            data.idempotencyKey,
            data.senderName || null,
            data.senderAccount || null,
            data.senderBank || null,
            data.recipientName,
            data.recipientAccount,
            data.recipientBank || null,
            data.provider || "INTERNAL",
            data.type,
            data.amount,
            data.currency,
            data.description || null
        ]
    );

    if (!result.rows.length) {
        const existing = await db.query(
            `SELECT * FROM gpb_transactions
             WHERE idempotency_key = $1`,
            [data.idempotencyKey]
        );

        if (existing.rows.length) return existing.rows[0];

        throw new Error("Transaction could not be recorded");
    }

    return result.rows[0];
}

module.exports = { createTransaction };
