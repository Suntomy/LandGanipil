const express = require("express");
const router = express.Router();
const config = require("../config");

router.get("/information", (req, res) => {
  res.json({
    success: true,
    bank: config.bank,
    transaction: config.transaction,
    message: "Global Pilgrim Bank development banking module"
  });
});

module.exports = router;
