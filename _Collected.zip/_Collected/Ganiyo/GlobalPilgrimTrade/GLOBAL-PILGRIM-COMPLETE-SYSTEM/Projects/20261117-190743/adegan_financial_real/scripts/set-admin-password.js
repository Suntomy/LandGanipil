'use strict';

require('dotenv').config();
const crypto = require('node:crypto');
const db = require('../backend/database/db');

async function main() {
    const username = 'admin';
    const password = 'Adegan@PGP2026!Secure';

    const salt = crypto.randomBytes(16);
    const hash = crypto.scryptSync(password, salt, 64);

    const passwordHash =
        `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;

    await db.query(`
        CREATE TABLE IF NOT EXISTS gpb_admins (
            id BIGSERIAL PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role VARCHAR(30) NOT NULL DEFAULT 'ADMIN',
            active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
    `);

    await db.query(`
        INSERT INTO gpb_admins (username, password_hash)
        VALUES ($1, $2)
        ON CONFLICT (username)
        DO UPDATE SET
            password_hash = EXCLUDED.password_hash,
            active = TRUE
    `, [username, passwordHash]);

    console.log('Administrator password installed successfully.');
    console.log('Username:', username);
    console.log('Password:', password);

    await db.end();
}

main().catch(error => {
    console.error('Installation failed:', error.message);
    process.exit(1);
});
