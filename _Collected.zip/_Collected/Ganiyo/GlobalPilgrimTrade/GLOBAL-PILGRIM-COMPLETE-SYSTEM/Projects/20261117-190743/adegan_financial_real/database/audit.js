const { pool } = require("./balance");

async function auditTransactions() {
  const result = await pool.query(`
    SELECT
      t.reference,
      t.status,
      COUNT(l.id) AS entries,
      COALESCE(SUM(
        CASE WHEN l.entry_type = 'debit'
        THEN l.amount ELSE 0 END
      ), 0) AS total_debit,
      COALESCE(SUM(
        CASE WHEN l.entry_type = 'credit'
        THEN l.amount ELSE 0 END
      ), 0) AS total_credit
    FROM transactions t
    LEFT JOIN ledger_entries l
      ON l.transaction_id = t.id
    GROUP BY t.id
    ORDER BY t.created_at DESC
  `);

  console.table(result.rows);
}

auditTransactions()
  .catch(console.error)
  .finally(() => pool.end());
