const express = require("express");
const { z } = require("zod");

const protect = require("../security/auth");
const { createAccount } = require("../services/accounts");
const { createTransaction } = require("../services/transactions");
const db = require("../database/db");

const router = express.Router();

router.get("/health", async (req, res) => {

    let database = "OFFLINE";

    try {
        await db.query("SELECT 1");
        database = "CONNECTED";
    } catch {}

    res.json({
        service: "ADEGAN GLOBAL UNIVERSAL NETWORK",
        bank: "GLOBAL PILGRIM BANK",
        cryptocurrency: "PILGRIM COIN",
        status: database === "CONNECTED" ? "ONLINE" : "DEGRADED",
        database,
        timestamp: new Date().toISOString()
    });
});

router.post("/accounts", protect, async (req, res) => {

    try {
        const schema = z.object({
            accountName: z.string().min(2).max(200),
            currency: z.enum(["NGN", "USD", "GBP", "EUR"])
        });

        const input = schema.parse(req.body);

        const account = await createAccount(
            input.accountName,
            input.currency
        );

        res.status(201).json({
            message: "Internal account created",
            account
        });

    } catch (error) {
        res.status(400).json({
            error: error.message
        });
    }
});

router.post("/transactions", protect, async (req, res) => {

    try {
        const schema = z.object({
            idempotencyKey: z.string().min(8).max(100),
            senderName: z.string().max(200).optional(),
            senderAccount: z.string().max(100).optional(),
            senderBank: z.string().max(200).optional(),
            recipientName: z.string().min(2).max(200),
            recipientAccount: z.string().min(1).max(100),
            recipientBank: z.string().max(200).optional(),
            provider: z.string().max(100).optional(),
            type: z.enum([
                "TRANSFER",
                "DEPOSIT",
                "WITHDRAWAL",
                "PAYMENT"
            ]),
            amount: z.number().positive(),
            currency: z.enum(["NGN", "USD", "GBP", "EUR"]),
            description: z.string().max(500).optional()
        });

        const input = schema.parse(req.body);

        const transaction = await createTransaction(input);

        res.status(201).json({
            message: "Transaction recorded for verification",
            transaction
        });

    } catch (error) {
        res.status(400).json({
            error: error.message
        });
    }
});

router.get("/transactions/:tracking", protect, async (req, res) => {

    try {
        const result = await db.query(
            `SELECT * FROM gpb_transactions
             WHERE tracking_number = $1`,
            [req.params.tracking]
        );

        if (!result.rows.length) {
            return res.status(404).json({
                error: "Transaction not found"
            });
        }

        res.json(result.rows[0]);

    } catch (error) {
        res.status(500).json({
            error: "Transaction lookup failed"
        });
    }
});

module.exports = router;
