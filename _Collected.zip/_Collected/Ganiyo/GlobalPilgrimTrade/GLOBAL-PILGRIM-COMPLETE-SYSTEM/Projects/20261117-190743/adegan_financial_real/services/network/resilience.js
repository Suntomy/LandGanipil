const axios = require("axios");
const crypto = require("crypto");

class AdeganNetwork {

  constructor() {
    this.servers = [];
    this.activeServer = null;
    this.timeout = 15000;
    this.maxRetries = 3;
  }

  configure(servers) {
    this.servers = servers.filter(s => s.enabled);
  }

  async checkServer(server) {
    try {
      const response = await axios.get(
        `${server.url}/health`,
        {
          timeout: 5000,
          headers: {
            "Cache-Control": "no-cache"
          }
        }
      );

      return response.status === 200;
    } catch {
      return false;
    }
  }

  async connect() {

    for (const server of this.servers) {

      const healthy = await this.checkServer(server);

      if (healthy) {
        this.activeServer = server;

        console.log(
          "CONNECTED:",
          server.name
        );

        return server;
      }

      console.log(
        "SERVER UNAVAILABLE:",
        server.name
      );
    }

    this.activeServer = null;

    console.log(
      "NO AVAILABLE SERVER. OFFLINE MODE."
    );

    return null;
  }

  async request(method, path, data = null, options = {}) {

    const safeMethod = ["GET", "HEAD", "OPTIONS"]
      .includes(method.toUpperCase());

    const idempotencyKey =
      options.idempotencyKey ||
      (safeMethod ? undefined : null);

    if (!safeMethod && !idempotencyKey) {
      throw new Error(
        "Payment or write requests require an idempotency key"
      );
    }

    const retries = safeMethod ? this.maxRetries : 1;

    for (let attempt = 0; attempt < retries; attempt++) {

      if (!this.activeServer) {
        await this.connect();
      }

      if (!this.activeServer) {
        throw new Error(
          "Network unavailable. Request not submitted."
        );
      }

      try {

        const response = await axios({
          method,
          url: `${this.activeServer.url}${path}`,
          data,
          timeout: this.timeout,
          headers: {
            ...(idempotencyKey
              ? { "Idempotency-Key": idempotencyKey }
              : {}),
            "Content-Type": "application/json"
          }
        });

        return response.data;

      } catch (error) {

        console.error(
          "NETWORK REQUEST FAILED:",
          error.message
        );

        this.activeServer = null;

        await this.connect();

        if (attempt < retries - 1) {
          const delay =
            Math.min(1000 * (2 ** attempt), 8000) +
            crypto.randomInt(100, 500);

          await new Promise(resolve =>
            setTimeout(resolve, delay)
          );
        }
      }
    }

    throw new Error(
      "Request failed. Check transaction status before retrying."
    );
  }

  getStatus() {
    return {
      network: "ADEGAN GLOBAL",
      connected: Boolean(this.activeServer),
      activeServer: this.activeServer?.name || null,
      time: new Date().toISOString()
    };
  }
}

module.exports = AdeganNetwork;
