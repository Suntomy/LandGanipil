function protect(req, res, next) {

    const configuredKey = process.env.INTERNAL_API_KEY;

    if (!configuredKey) {
        return res.status(503).json({
            error: "API authentication is not configured"
        });
    }

    const suppliedKey = req.get("x-api-key");

    if (!suppliedKey || suppliedKey !== configuredKey) {
        return res.status(401).json({
            error: "Authentication required"
        });
    }

    next();
}

module.exports = protect;
