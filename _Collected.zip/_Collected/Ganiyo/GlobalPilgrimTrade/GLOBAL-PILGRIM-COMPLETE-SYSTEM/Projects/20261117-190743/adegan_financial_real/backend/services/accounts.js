const crypto = require("crypto");
const db = require("../database/db");

function generateAccountNumber() {
    return String(
        crypto.randomInt(1000000000, 10000000000)
    );
}

async function createAccount(name, currency = "NGN") {

    if (!name || name.trim().length < 2) {
        throw new Error("Valid account name required");
    }

    if (!["NGN", "USD", "GBP", "EUR"].includes(currency)) {
        throw new Error("Unsupported account currency");
    }

    for (let attempt = 0; attempt < 5; attempt++) {

        const number = generateAccountNumber();

        const result = await db.query(
            `INSERT INTO gpb_accounts
            (account_number, account_name, currency)
            VALUES ($1, $2, $3)
            ON CONFLICT (account_number) DO NOTHING
            RETURNING account_number, account_name, currency, status`,
            [number, name.trim(), currency]
        );

        if (result.rows.length) {
            return result.rows[0];
        }
    }

    throw new Error("Could not allocate unique account number");
}

module.exports = { createAccount };
