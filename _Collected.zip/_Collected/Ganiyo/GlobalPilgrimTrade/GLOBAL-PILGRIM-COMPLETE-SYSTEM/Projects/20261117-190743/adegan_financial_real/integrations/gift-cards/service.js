const axios = require("axios");

async function getGiftCardToken() {
  const response = await axios.post(
    process.env.GIFT_CARD_AUTH_URL,
    {
      client_id: process.env.GIFT_CARD_CLIENT_ID,
      client_secret: process.env.GIFT_CARD_CLIENT_SECRET,
      grant_type: "client_credentials",
      audience: "https://giftcards.reloadly.com"
    }
  );

  return response.data.access_token;
}

async function getGiftCardProducts(countryCode = "US") {
  const token = await getGiftCardToken();

  const response = await axios.get(
    "https://giftcards.reloadly.com/products",
    {
      params: {
        countryCode,
        size: 50,
        page: 1
      },
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/com.reloadly.giftcards-v1+json"
      }
    }
  );

  return response.data;
}

module.exports = {
  getGiftCardProducts
};
