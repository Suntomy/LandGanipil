'use strict';
const crypto = require('node:crypto');
const password = process.argv[2];
if (!password || password.length < 16) {
  console.error('Usage: node scripts/hash-password.js "a-strong-password-at-least-16-chars"');
  process.exit(1);
}
const salt = crypto.randomBytes(16);
const hash = crypto.scryptSync(password, salt, 64);
console.log(`scrypt$${salt.toString('hex')}$${hash.toString('hex')}`);
