const crypto = require("crypto");

function generateAccountNumber() {
  return String(
    crypto.randomInt(1000000000, 10000000000)
  );
}

function validateAccountNumber(number) {
  return /^[0-9]{10}$/.test(String(number));
}

module.exports = {
  generateAccountNumber,
  validateAccountNumber
};
