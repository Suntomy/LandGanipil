const { Pool } = require("pg");

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 30000,
    max: 10,
    ssl: process.env.DATABASE_SSL === "true"
        ? { rejectUnauthorized: true }
        : false
});

pool.on("error", error => {
    console.error("DATABASE ERROR:", error.message);
});

module.exports = pool;
