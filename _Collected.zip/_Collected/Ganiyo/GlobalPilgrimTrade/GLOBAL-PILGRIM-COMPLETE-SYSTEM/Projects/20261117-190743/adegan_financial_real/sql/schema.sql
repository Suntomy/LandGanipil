-- Applied automatically by server.js on startup. This file is supplied for review.
CREATE TABLE IF NOT EXISTS payment_orders (
  reference VARCHAR(80) PRIMARY KEY,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  amount_major NUMERIC(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,
  customer_name VARCHAR(100) NOT NULL,
  customer_email VARCHAR(150) NOT NULL,
  customer_phone VARCHAR(20) NOT NULL,
  description VARCHAR(180) NOT NULL,
  status VARCHAR(24) NOT NULL,
  opay_order_no VARCHAR(100),
  cashier_url TEXT,
  opay_status VARCHAR(24),
  transaction_id VARCHAR(120),
  channel VARCHAR(80),
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  callback_received_at TIMESTAMPTZ,
  callback_payload JSONB,
  failure_message TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS payment_orders_opay_transaction_id_uq
  ON payment_orders(transaction_id) WHERE transaction_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS payment_orders_status_created_idx ON payment_orders(status, created_at DESC);
CREATE TABLE IF NOT EXISTS audit_events (
  id BIGSERIAL PRIMARY KEY,
  event_type VARCHAR(80) NOT NULL,
  reference VARCHAR(80),
  event_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
