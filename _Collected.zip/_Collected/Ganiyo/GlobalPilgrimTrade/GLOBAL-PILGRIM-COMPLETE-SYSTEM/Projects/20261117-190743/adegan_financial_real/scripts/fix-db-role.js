require('dotenv').config();
const { spawnSync } = require('child_process');

const role = 'adegan_user';
const database = 'adegan_global';
const url = new URL(process.env.DATABASE_URL);
const password = decodeURIComponent(url.password);

if (!password) throw new Error('Database password is missing');

const sql = `
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_roles WHERE rolname = '${role}'
  ) THEN
    EXECUTE format(
      'CREATE ROLE %I LOGIN PASSWORD %L',
      '${role}', '${password.replace(/'/g, "''")}'
    );
  ELSE
    EXECUTE format(
      'ALTER ROLE %I WITH LOGIN PASSWORD %L',
      '${role}', '${password.replace(/'/g, "''")}'
    );
  END IF;
END
$$;

GRANT CONNECT ON DATABASE ${database} TO ${role};
`;

const result = spawnSync('psql', [
  '-d', 'postgres',
  '-v', 'ON_ERROR_STOP=1',
  '-c', sql
], { encoding: 'utf8' });

if (result.status !== 0) {
  console.error(result.stderr || result.error);
  process.exit(1);
}

const grants = spawnSync('psql', [
  '-d', database,
  '-v', 'ON_ERROR_STOP=1',
  '-c', `
    GRANT USAGE, CREATE ON SCHEMA public TO ${role};
    GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ${role};
    GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ${role};
  `
], { encoding: 'utf8' });

if (grants.status !== 0) {
  console.error(grants.stderr || grants.error);
  process.exit(1);
}

console.log('Database role repaired and permissions granted.');
