const AdeganNetwork =
  require("../../services/network/resilience");

const config =
  require("../servers/config.json");

const network = new AdeganNetwork();

network.configure(config.servers);

async function monitor() {

  const connection = await network.connect();

  const status = network.getStatus();

  console.log(
    new Date().toISOString(),
    status
  );

  if (!connection) {
    console.log(
      "WARNING: All configured servers unavailable."
    );
  }
}

monitor();

setInterval(monitor, 30000);
