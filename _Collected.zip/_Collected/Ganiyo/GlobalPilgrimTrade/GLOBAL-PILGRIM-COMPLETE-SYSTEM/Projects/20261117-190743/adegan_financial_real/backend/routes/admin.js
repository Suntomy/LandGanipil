'use strict';

const express = require('express');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const db = require('../database/db');

const router = express.Router();

const loginLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false
});

function verifyPassword(password, stored) {
  try {
    const parts = stored.split('$');
    if (parts.length !== 3 || parts[0] !== 'scrypt') return false;

    const salt = Buffer.from(parts[1], 'hex');
    const expected = Buffer.from(parts[2], 'hex');
    const actual = crypto.scryptSync(password, salt, expected.length);

    return expected.length === actual.length &&
      crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

function requireAdmin(req, res, next) {
  if (!req.session || !req.session.admin) {
    return res.status(401).json({ error: 'Administrator login required' });
  }
  next();
}

async function audit(req, action, details = {}) {
  try {
    await db.query(`
      INSERT INTO gpb_admin_audit_logs
      (admin_username, action, details, created_at)
      VALUES ($1, $2, $3, NOW())
    `, [req.session.admin.username, action, JSON.stringify(details)]);
  } catch (error) {
    console.error('Audit log error:', error.message);
  }
}

router.post('/login', loginLimit, async (req, res) => {
  try {
    const { username, password } = req.body || {};

    if (typeof username !== 'string' ||
        typeof password !== 'string' ||
        username.length > 50 ||
        password.length > 200) {
      return res.status(400).json({ error: 'Invalid login details' });
    }

    const result = await db.query(
      `SELECT username, password_hash, role
       FROM gpb_admins
       WHERE username = $1 AND active = TRUE`,
      [username]
    );

    if (!result.rows.length ||
        !verifyPassword(password, result.rows[0].password_hash)) {
      return res.status(401).json({ error: 'Incorrect username or password' });
    }

    req.session.regenerate(error => {
      if (error) {
        return res.status(500).json({ error: 'Could not start secure session' });
      }

      req.session.admin = {
        username: result.rows[0].username,
        role: result.rows[0].role
      };

      req.session.save(async error => {
        if (error) {
          return res.status(500).json({ error: 'Could not save session' });
        }

        await audit(req, 'ADMIN_LOGIN');
        res.json({ message: 'Login successful', admin: req.session.admin });
      });
    });
  } catch (error) {
    console.error('Admin login:', error.message);
    res.status(500).json({ error: 'Login service unavailable' });
  }
});

router.post('/logout', requireAdmin, async (req, res) => {
  await audit(req, 'ADMIN_LOGOUT');
  req.session.destroy(error => {
    if (error) return res.status(500).json({ error: 'Logout failed' });
    res.clearCookie('adegan.admin.sid');
    res.json({ message: 'Logged out successfully' });
  });
});

router.get('/me', requireAdmin, (req, res) => {
  res.json({ admin: req.session.admin });
});

router.get('/overview', requireAdmin, async (req, res) => {
  try {
    const tables = [
      'customers', 'accounts', 'gpb_accounts',
      'transactions', 'gpb_transactions'
    ];

    const counts = {};

    for (const table of tables) {
      const exists = await db.query(
        `SELECT to_regclass($1) AS name`,
        [`public.${table}`]
      );

      if (exists.rows[0].name) {
        const result = await db.query(
          `SELECT COUNT(*)::int AS total FROM public."${table}"`
        );
        counts[table] = result.rows[0].total;
      }
    }

    res.json({ counts, generatedAt: new Date().toISOString() });
  } catch (error) {
    res.status(500).json({ error: 'Overview unavailable' });
  }
});

const allowedTables = {
  customers: 'customers',
  accounts: 'accounts',
  gpb_accounts: 'gpb_accounts',
  transactions: 'transactions',
  gpb_transactions: 'gpb_transactions'
};

async function readTable(table) {
  const columnsResult = await db.query(
    `SELECT column_name
     FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = $1
     ORDER BY ordinal_position`,
    [table]
  );

  const hidden = [
    'password_hash', 'secret', 'private_key',
    'seed_phrase', 'token', 'api_key'
  ];

  const columns = columnsResult.rows
    .map(row => row.column_name)
    .filter(name => !hidden.includes(name.toLowerCase()));

  if (!columns.length) return [];

  const selected = columns.map(name =>
    '"' + name.replace(/"/g, '""') + '"'
  ).join(', ');

  const order = columns.includes('created_at')
    ? '"created_at" DESC'
    : columns.includes('id') ? '"id" DESC' : null;

  const sql = `SELECT ${selected} FROM public."${table}"` +
    (order ? ` ORDER BY ${order}` : '') + ' LIMIT 100';

  const result = await db.query(sql);
  return result.rows;
}

router.get('/customers', requireAdmin, async (req, res) => {
  try {
    res.json({ customers: await readTable(allowedTables.customers) });
  } catch {
    res.status(500).json({ error: 'Could not load customers' });
  }
});

router.patch('/customers/:id/status', requireAdmin, async (req, res) => {
  try {
    const { accountStatus, kycStatus } = req.body || {};
    const updates = [];
    const values = [];

    if (accountStatus !== undefined) {
      if (!['active', 'suspended', 'closed'].includes(accountStatus)) {
        return res.status(400).json({ error: 'Invalid account status' });
      }
      values.push(accountStatus);
      updates.push(`account_status = $${values.length}`);
    }

    if (kycStatus !== undefined) {
      if (!['pending', 'verified', 'rejected'].includes(kycStatus)) {
        return res.status(400).json({ error: 'Invalid KYC status' });
      }
      values.push(kycStatus);
      updates.push(`kyc_status = $${values.length}`);
    }

    if (!updates.length) {
      return res.status(400).json({ error: 'No status supplied' });
    }

    values.push(req.params.id);

    const result = await db.query(
      `UPDATE customers SET ${updates.join(', ')}
       WHERE id = $${values.length}
       RETURNING id, customer_number, full_name, account_status, kyc_status`,
      values
    );

    if (!result.rows.length) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    await audit(req, 'CUSTOMER_STATUS_UPDATED', { customerId: req.params.id });
    res.json({ customer: result.rows[0] });
  } catch (error) {
    res.status(500).json({ error: 'Customer update failed' });
  }
});

router.get('/accounts', requireAdmin, async (req, res) => {
  try {
    const accounts = {};
    for (const table of ['accounts', 'gpb_accounts']) {
      accounts[table] = await readTable(table);
    }
    res.json(accounts);
  } catch {
    res.status(500).json({ error: 'Could not load accounts' });
  }
});

router.get('/transactions', requireAdmin, async (req, res) => {
  try {
    const transactions = {};
    for (const table of ['transactions', 'gpb_transactions']) {
      transactions[table] = await readTable(table);
    }
    res.json(transactions);
  } catch {
    res.status(500).json({ error: 'Could not load transactions' });
  }
});

router.get('/audit', requireAdmin, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, admin_username, action, details, created_at
       FROM gpb_admin_audit_logs
       ORDER BY id DESC LIMIT 100`
    );
    res.json({ logs: result.rows });
  } catch {
    res.status(500).json({ error: 'Could not load audit logs' });
  }
});

module.exports = router;
