const { google } = require("googleapis");
const jwt = require("jsonwebtoken");
const fs = require("fs");

const KEY_FILE =
  process.env.GOOGLE_APPLICATION_CREDENTIALS;

const ISSUER_ID =
  process.env.GOOGLE_WALLET_ISSUER_ID;

function getCredentials() {
  if (!KEY_FILE || !ISSUER_ID) {
    throw new Error(
      "Google Wallet credentials are not configured"
    );
  }

  if (!fs.existsSync(KEY_FILE)) {
    throw new Error("Google service account file not found");
  }

  return JSON.parse(fs.readFileSync(KEY_FILE, "utf8"));
}

async function getWalletClient() {
  const auth = new google.auth.GoogleAuth({
    keyFile: KEY_FILE,
    scopes: [
      "https://www.googleapis.com/auth/wallet_object.issuer"
    ]
  });

  return google.walletobjects({
    version: "v1",
    auth
  });
}

async function createGPBWalletPass(customer) {
  const credentials = getCredentials();

  const issuer = ISSUER_ID;
  const suffix = String(customer.customerId)
    .replace(/[^a-zA-Z0-9_-]/g, "");

  if (!suffix) {
    throw new Error("Invalid customer ID");
  }

  const classId = `${issuer}.gpb_customer_class`;
  const objectId = `${issuer}.customer_${suffix}`;

  const wallet = await getWalletClient();

  const passClass = {
    id: classId,
    issuerName: "Adegan Global",
    reviewStatus: "UNDER_REVIEW"
  };

  try {
    await wallet.genericclass.insert({
      requestBody: passClass
    });
  } catch (error) {
    if (error.code !== 409) throw error;
  }

  const passObject = {
    id: objectId,
    classId,
    state: "ACTIVE",

    cardTitle: {
      defaultValue: {
        language: "en",
        value: "Global Pilgrim Bank"
      }
    },

    header: {
      defaultValue: {
        language: "en",
        value: "GPB Customer Card"
      }
    },

    subheader: {
      defaultValue: {
        language: "en",
        value: "Adegan Global"
      }
    }
  };

  try {
    await wallet.genericobject.insert({
      requestBody: passObject
    });
  } catch (error) {
    if (error.code !== 409) throw error;
  }

  const token = jwt.sign({
    iss: credentials.client_email,
    aud: "google",
    typ: "savetowallet",
    payload: {
      genericObjects: [passObject]
    }
  }, credentials.private_key, {
    algorithm: "RS256"
  });

  return {
    saveUrl:
      `https://pay.google.com/gp/v/save/${token}`,
    status: "PASS_CREATED"
  };
}

module.exports = {
  createGPBWalletPass
};
