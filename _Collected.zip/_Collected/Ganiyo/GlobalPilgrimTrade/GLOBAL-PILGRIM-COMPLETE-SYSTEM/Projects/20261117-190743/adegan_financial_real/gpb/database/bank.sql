CREATE TABLE IF NOT EXISTS gpb_accounts (
    id BIGSERIAL PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    account_number VARCHAR(30) UNIQUE NOT NULL,
    account_name VARCHAR(150) NOT NULL,
    currency CHAR(3) NOT NULL
      CHECK (currency IN ('NGN','USD')),
    account_status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS gpb_transactions (
    id BIGSERIAL PRIMARY KEY,
    reference VARCHAR(100) UNIQUE NOT NULL,
    sender_account BIGINT,
    receiver_account BIGINT,
    amount NUMERIC(24,8) NOT NULL CHECK (amount > 0),
    currency CHAR(3) NOT NULL,
    transaction_type VARCHAR(30) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    provider_reference VARCHAR(150),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS gpb_compliance_logs (
    id BIGSERIAL PRIMARY KEY,
    action VARCHAR(100) NOT NULL,
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
