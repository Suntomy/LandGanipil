const axios = require("axios");

const API_URL = "https://api.exchangerate.dev/v1/latest/USD";

const CURRENCIES = [
  "NGN", "GBP", "EUR", "CAD", "AUD",
  "CHF", "JPY", "CNY", "ZAR", "AED"
];

let cachedRates = null;
let lastUpdated = null;

async function getExchangeRates() {
  try {
    const response = await axios.get(API_URL, {
      params: {
        symbols: CURRENCIES.join(",")
      },
      timeout: 15000
    });

    const data = response.data;

    if (data.result !== "success" || !data.rates) {
      throw new Error("Exchange-rate provider returned invalid data");
    }

    cachedRates = {
      base: data.base,
      rates: data.rates,
      timestamp: data.timestamp,
      dataUpdatedAt: data.data_updated_at,
      source: data.source,
      stale: data.stale,
      notice: data.notice
    };

    lastUpdated = new Date().toISOString();

    return cachedRates;

  } catch (error) {
    console.error("Exchange-rate update failed:", error.message);

    if (cachedRates) {
      return {
        ...cachedRates,
        usingCachedData: true
      };
    }

    throw error;
  }
}

module.exports = {
  getExchangeRates
};
