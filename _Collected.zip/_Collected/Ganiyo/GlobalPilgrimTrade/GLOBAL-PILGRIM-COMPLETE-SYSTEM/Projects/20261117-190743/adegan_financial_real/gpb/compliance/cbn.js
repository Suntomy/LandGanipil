module.exports = {
  regulator: "Central Bank of Nigeria",
  officialWebsite: "https://www.cbn.gov.ng/",
  requirements: [
    "Appropriate CBN banking licence or approved operating arrangement",
    "Corporate and ownership documentation",
    "Capital requirements applicable to the licence",
    "AML and KYC compliance",
    "Risk management framework",
    "Information security controls",
    "Regulatory reporting",
    "Approved payment and settlement arrangements"
  ],
  status: "NOT YET VERIFIED OR AUTHORISED"
};
