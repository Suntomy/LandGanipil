/*
 ADEGAN GLOBAL ENTERPRISE — partner-banking starter backend
 Requires Node.js 20+ and PostgreSQL.
 This is a real application backend for customer accounts and internal ledger transfers.
 External bank payouts, card issuing, USSD, BTC custody/mining and PGC blockchain are NOT
 activated by this source alone; they require contracted, licensed providers and credentials.
*/
"use strict";
require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const { Pool } = require("pg");
const crypto = require("crypto");

const required = ["DATABASE_URL", "JWT_SECRET"];
for (const key of required) if (!process.env[key]) {
  console.error(`Missing required environment variable: ${key}`); process.exit(1);
}
if (process.env.JWT_SECRET.length < 32) {
  console.error("JWT_SECRET must contain at least 32 characters."); process.exit(1);
}
const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : undefined,
  max: 10,
  idleTimeoutMillis: 30000
});
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
    imgSrc: ["'self'", "data:"], connectSrc: ["'self'"], objectSrc: ["'none'"],
    upgradeInsecureRequests: process.env.NODE_ENV === "production" ? [] : null
  }
}}));
app.use("/api/webhooks/paystack", express.raw({type:"application/json",limit:"100kb"}));
app.use(express.json({limit:"30kb"}));
app.use(cookieParser());
app.use("/api/auth", rateLimit({windowMs:15*60*1000,max:15,standardHeaders:true,legacyHeaders:false}));
app.use("/api", rateLimit({windowMs:60*1000,max:100,standardHeaders:true,legacyHeaders:false}));
app.use(express.static("public", {extensions:["html"]}));

const money = (n) => {
  const v = Number(n);
  if (!Number.isFinite(v) || v <= 0 || v > 1000000000) throw new Error("Enter a valid positive amount.");
  return Math.round(v * 100);
};
const ref = () => "AG" + Date.now().toString(36).toUpperCase() + crypto.randomBytes(4).toString("hex").toUpperCase();
const safeUser = u => ({id:u.id,fullName:u.full_name,email:u.email,phone:u.phone,accountNumber:u.account_number,status:u.status});
async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY, full_name VARCHAR(100) NOT NULL,
      email VARCHAR(254) UNIQUE NOT NULL, phone VARCHAR(20) NOT NULL,
      password_hash TEXT NOT NULL, account_number CHAR(10) UNIQUE NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'active',
      role VARCHAR(20) NOT NULL DEFAULT 'customer',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS accounts (
      id BIGSERIAL PRIMARY KEY, user_id BIGINT UNIQUE NOT NULL REFERENCES users(id),
      currency CHAR(3) NOT NULL DEFAULT 'NGN', balance_kobo BIGINT NOT NULL DEFAULT 0 CHECK(balance_kobo >= 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS transactions (
      id BIGSERIAL PRIMARY KEY, reference VARCHAR(50) UNIQUE NOT NULL,
      type VARCHAR(20) NOT NULL, status VARCHAR(20) NOT NULL,
      description VARCHAR(180) NOT NULL, amount_kobo BIGINT NOT NULL CHECK(amount_kobo > 0),
      sender_account CHAR(10), receiver_account CHAR(10),
      provider_reference VARCHAR(100) UNIQUE, metadata JSONB NOT NULL DEFAULT '{}',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS ledger_entries (
      id BIGSERIAL PRIMARY KEY, transaction_id BIGINT NOT NULL REFERENCES transactions(id),
      account_id BIGINT NOT NULL REFERENCES accounts(id),
      direction VARCHAR(6) NOT NULL CHECK(direction IN ('debit','credit')),
      amount_kobo BIGINT NOT NULL CHECK(amount_kobo > 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_ledger_account ON ledger_entries(account_id,created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_transactions_created ON transactions(created_at DESC);
  `);
}
async function makeAccountNumber(client) {
  for (let i=0;i<20;i++) {
    const candidate = String(crypto.randomInt(0,10000000000)).padStart(10,"0");
    const exists = await client.query("SELECT 1 FROM users WHERE account_number=$1",[candidate]);
    if (!exists.rowCount) return candidate;
  }
  throw new Error("Could not allocate account number. Retry.");
}
function auth(req,res,next) {
  const token=req.cookies.ag_session;
  if (!token) return res.status(401).json({error:"Please sign in."});
  try { req.session=jwt.verify(token,process.env.JWT_SECRET); next(); }
  catch { res.clearCookie("ag_session"); return res.status(401).json({error:"Session expired. Sign in again."}); }
}
function cookieOptions() {
  return {httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:8*60*60*1000};
}
app.get("/api/health",async(_req,res)=>{
  try { await pool.query("SELECT 1"); res.json({ok:true,service:"Adegan Global API"}); }
  catch { res.status(503).json({ok:false,error:"Database unavailable"}); }
});
app.post("/api/auth/register",async(req,res)=>{
  const {fullName,email,phone,password}=req.body||{};
  if(typeof fullName!=="string"||fullName.trim().length<3||fullName.length>100||
     typeof email!=="string"||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||
     typeof phone!=="string"||phone.length<7||phone.length>20||
     typeof password!=="string"||password.length<10||password.length>100)
    return res.status(400).json({error:"Enter a valid name, email, phone and password (minimum 10 characters)."});
  const client=await pool.connect();
  try {
    await client.query("BEGIN");
    const accountNumber=await makeAccountNumber(client);
    const hash=await bcrypt.hash(password,12);
    const result=await client.query(
      "INSERT INTO users(full_name,email,phone,password_hash,account_number) VALUES($1,$2,$3,$4,$5) RETURNING *",
      [fullName.trim(),email.trim().toLowerCase(),phone.trim(),hash,accountNumber]);
    await client.query("INSERT INTO accounts(user_id) VALUES($1)",[result.rows[0].id]);
    await client.query("COMMIT");
    const u=result.rows[0], token=jwt.sign({id:u.id,role:u.role},process.env.JWT_SECRET,{expiresIn:"8h"});
    res.cookie("ag_session",token,cookieOptions()).status(201).json({user:safeUser(u)});
  } catch(e) {
    await client.query("ROLLBACK");
    if(e.code==="23505") return res.status(409).json({error:"Email or account number already exists."});
    console.error(e); res.status(500).json({error:"Could not create account."});
  } finally {client.release();}
});
app.post("/api/auth/login",async(req,res)=>{
  const {email,password}=req.body||{};
  if(typeof email!=="string"||typeof password!=="string") return res.status(400).json({error:"Email and password are required."});
  try {
    const r=await pool.query("SELECT * FROM users WHERE email=$1",[email.trim().toLowerCase()]);
    if(!r.rowCount||!(await bcrypt.compare(password,r.rows[0].password_hash))) return res.status(401).json({error:"Incorrect email or password."});
    const u=r.rows[0]; if(u.status!=="active") return res.status(403).json({error:"Account is not active. Contact support."});
    const token=jwt.sign({id:u.id,role:u.role},process.env.JWT_SECRET,{expiresIn:"8h"});
    res.cookie("ag_session",token,cookieOptions()).json({user:safeUser(u)});
  } catch(e) {console.error(e);res.status(500).json({error:"Sign-in failed."});}
});
app.post("/api/auth/logout",(_req,res)=>res.clearCookie("ag_session",{path:"/",sameSite:"lax",secure:process.env.NODE_ENV==="production"}).json({ok:true}));
app.get("/api/me",auth,async(req,res)=>{
  try {
    const [ur,ar,tr]=await Promise.all([
      pool.query("SELECT * FROM users WHERE id=$1",[req.session.id]),
      pool.query("SELECT * FROM accounts WHERE user_id=$1 AND currency='NGN'",[req.session.id]),
      pool.query(`SELECT t.reference,t.type,t.status,t.description,t.amount_kobo,t.created_at
        FROM transactions t JOIN ledger_entries le ON le.transaction_id=t.id
        JOIN accounts a ON a.id=le.account_id WHERE a.user_id=$1
        GROUP BY t.id ORDER BY t.created_at DESC LIMIT 30`,[req.session.id])
    ]);
    if(!ur.rowCount||!ar.rowCount) return res.status(404).json({error:"Account not found."});
    res.json({user:safeUser(ur.rows[0]),account:{accountNumber:ur.rows[0].account_number,balanceKobo:Number(ar.rows[0].balance_kobo)},transactions:tr.rows.map(t=>({...t,amountKobo:Number(t.amount_kobo),createdAt:t.created_at}))});
  } catch(e) {console.error(e);res.status(500).json({error:"Could not load account."});}
});
app.post("/api/transfers/internal",auth,async(req,res)=>{
  let amount;
  try { amount=money(req.body?.amountNaira); } catch(e) {return res.status(400).json({error:e.message});}
  const toAccount=String(req.body?.toAccount||"");
  const memo=String(req.body?.memo||"Internal transfer").slice(0,100);
  if(!/^\d{10}$/.test(toAccount)) return res.status(400).json({error:"Recipient must have a 10-digit Adegan account number."});
  const client=await pool.connect();
  try {
    await client.query("BEGIN");
    const sr=await client.query("SELECT u.id,u.account_number,a.id AS account_id,a.balance_kobo FROM users u JOIN accounts a ON a.user_id=u.id WHERE u.id=$1 AND a.currency='NGN' AND u.status='active' FOR UPDATE",[req.session.id]);
    const rr=await client.query("SELECT u.id,u.account_number,a.id AS account_id FROM users u JOIN accounts a ON a.user_id=u.id WHERE u.account_number=$1 AND u.status='active' AND a.currency='NGN' FOR UPDATE",[toAccount]);
    if(!sr.rowCount||!rr.rowCount) throw new Error("Sender or recipient account is unavailable.");
    if(sr.rows[0].id===rr.rows[0].id) throw new Error("You cannot transfer to your own account.");
    if(BigInt(sr.rows[0].balance_kobo)<BigInt(amount)) throw new Error("Insufficient available balance.");
    await client.query("UPDATE accounts SET balance_kobo=balance_kobo-$1 WHERE id=$2",[amount,sr.rows[0].account_id]);
    await client.query("UPDATE accounts SET balance_kobo=balance_kobo+$1 WHERE id=$2",[amount,rr.rows[0].account_id]);
    const reference=ref();
    const tx=await client.query(`INSERT INTO transactions(reference,type,status,description,amount_kobo,sender_account,receiver_account)
      VALUES($1,'transfer','success',$2,$3,$4,$5) RETURNING id`,
      [reference,memo,amount,sr.rows[0].account_number,rr.rows[0].account_number]);
    await client.query("INSERT INTO ledger_entries(transaction_id,account_id,direction,amount_kobo) VALUES($1,$2,'debit',$3),($1,$4,'credit',$3)",
      [tx.rows[0].id,sr.rows[0].account_id,amount,rr.rows[0].account_id]);
    await client.query("COMMIT");
    res.json({ok:true,reference,status:"success",amountKobo:amount});
  } catch(e) {
    await client.query("ROLLBACK");
    res.status(400).json({error:e.message||"Transfer could not be completed."});
  } finally {client.release();}
});
app.post("/api/payments/initialize",auth,async(req,res)=>{
  let amount;
  try {amount=money(req.body?.amountNaira);} catch(e) {return res.status(400).json({error:e.message});}
  if(!process.env.PAYSTACK_SECRET_KEY) return res.status(503).json({error:"Payment provider is not configured. Add an approved Paystack secret key on the server."});
  try {
    const u=await pool.query("SELECT email FROM users WHERE id=$1",[req.session.id]);
    const reference=ref();
    const response=await fetch("https://api.paystack.co/transaction/initialize",{
      method:"POST",headers:{"Authorization":`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({email:u.rows[0].email,amount,currency:"NGN",reference,callback_url:process.env.PAYSTACK_CALLBACK_URL||undefined,metadata:{adeganUserId:req.session.id}})
    });
    const body=await response.json();
    if(!response.ok||!body.status) return res.status(502).json({error:body.message||"Payment provider initialization failed."});
    await pool.query("INSERT INTO transactions(reference,type,status,description,amount_kobo,metadata) VALUES($1,'deposit','pending','Paystack deposit',$2,$3)",
      [reference,amount,JSON.stringify({userId:req.session.id})]);
    res.json({authorizationUrl:body.data.authorization_url,reference});
  } catch(e) {console.error(e);res.status(502).json({error:"Could not initialize payment."});}
});
app.post("/api/webhooks/paystack",async(req,res)=>{
  const signature=req.headers["x-paystack-signature"];
  if(!process.env.PAYSTACK_SECRET_KEY||!signature||!Buffer.isBuffer(req.body)) return res.sendStatus(401);
  const expected=crypto.createHmac("sha512",process.env.PAYSTACK_SECRET_KEY).update(req.body).digest("hex");
  const a=Buffer.from(signature), b=Buffer.from(expected);
  if(a.length!==b.length||!crypto.timingSafeEqual(a,b)) return res.sendStatus(401);
  let event;
  try { event=JSON.parse(req.body.toString("utf8")); } catch { return res.sendStatus(400); }
  if(event.event!=="charge.success") return res.sendStatus(200);
  const reference=event.data?.reference;
  if(!reference) return res.sendStatus(200);
  try {
    // Verify directly with Paystack before crediting. Never trust webhook fields alone.
    const vr=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{
      headers:{"Authorization":`Bearer ${process.env.PAYSTACK_SECRET_KEY}`}
    });
    const verified=await vr.json();
    if(!vr.ok||!verified.status||verified.data?.status!=="success"||verified.data?.currency!=="NGN") return res.sendStatus(200);
    const client=await pool.connect();
    try {
      await client.query("BEGIN");
      const tr=await client.query("SELECT * FROM transactions WHERE reference=$1 FOR UPDATE",[reference]);
      if(!tr.rowCount||tr.rows[0].status==="success") { await client.query("COMMIT"); return res.sendStatus(200); }
      const tx=tr.rows[0], paid=Number(verified.data.amount);
      if(paid!==Number(tx.amount_kobo)) { await client.query("ROLLBACK"); return res.sendStatus(200); }
      const userId=Number(tx.metadata?.userId);
      const ar=await client.query("SELECT id FROM accounts WHERE user_id=$1 AND currency='NGN' FOR UPDATE",[userId]);
      if(!ar.rowCount) { await client.query("ROLLBACK"); return res.sendStatus(200); }
      await client.query("UPDATE accounts SET balance_kobo=balance_kobo+$1 WHERE id=$2",[paid,ar.rows[0].id]);
      await client.query("UPDATE transactions SET status='success',provider_reference=$1 WHERE id=$2",[String(verified.data.id),tx.id]);
      await client.query("INSERT INTO ledger_entries(transaction_id,account_id,direction,amount_kobo) VALUES($1,$2,'credit',$3)",[tx.id,ar.rows[0].id,paid]);
      await client.query("COMMIT");
    } catch(e) { await client.query("ROLLBACK"); throw e; }
    finally { client.release(); }
    return res.sendStatus(200);
  } catch(e) { console.error("Paystack webhook processing failed:",e); return res.sendStatus(500); }
});
app.get("/api/external-capabilities",(_req,res)=>res.json({
  internalTransfers:"enabled",
  paystackCheckout:!!process.env.PAYSTACK_SECRET_KEY,
  externalBankPayouts:"not enabled — requires approved transfer provider and beneficiary verification",
  cardIssuing:"not enabled — requires licensed card issuer",
  ussd:"not enabled — requires allocated short code and aggregator",
  bitcoin:"not enabled — requires wallet/node provider and custody controls",
  pilgrimCoin:"not enabled — requires deployed blockchain/token and audited issuance rules"
}));
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:"Unexpected server error."});});
const port=Number(process.env.PORT||3000);
initDb().then(()=>app.listen(port,"0.0.0.0",()=>console.log(`Adegan Global API listening on ${port}`)))
  .catch(e=>{console.error("Database initialization failed:",e);process.exit(1);});
