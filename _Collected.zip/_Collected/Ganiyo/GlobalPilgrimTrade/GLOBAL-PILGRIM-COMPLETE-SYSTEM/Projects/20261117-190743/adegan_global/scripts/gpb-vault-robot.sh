#!/data/data/com.termux/files/usr/bin/bash

cd "$HOME/adegan_global" || exit 1

LOG="logs/vault-robot.log"

echo "========================================"
echo " ADEGAN GLOBAL AUTOMATIC REPAIR ROBOT"
echo " GLOBAL PILGRIM BANK"
echo "========================================"

{
echo "Started: $(date)"
echo "Project: $PWD"

echo
echo "1. CHECKING POSTGRESQL"

if ! pg_isready >/dev/null 2>&1; then
    echo "ERROR: PostgreSQL is not running."
    echo "Start it with: pg_ctl -D \$PREFIX/var/lib/postgresql start"
    exit 1
fi

echo "PostgreSQL is running."

echo
echo "2. CHECKING DATABASE CONNECTION"

if ! psql -d adegan_global -v ON_ERROR_STOP=1 -c "SELECT current_database();" ; then
    echo "ERROR: Cannot connect to adegan_global."
    exit 1
fi

echo
echo "3. REPAIRING MISSING VAULT TABLES AND INDEXES"

psql -d adegan_global -v ON_ERROR_STOP=1 <<'SQL'
BEGIN;

CREATE TABLE IF NOT EXISTS gpb_vault_accounts (
    id BIGSERIAL PRIMARY KEY,
    customer_ref VARCHAR(100) NOT NULL,
    vault_number VARCHAR(30) UNIQUE NOT NULL,
    currency VARCHAR(10) NOT NULL,
    vault_name VARCHAR(100) DEFAULT 'Global Pilgrim Bank Vault',
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(customer_ref, currency),
    CHECK (currency IN ('NGN','USD','EUR','GBP','CNY','BTC','PGC')),
    CHECK (status IN ('active','frozen','closed'))
);

CREATE TABLE IF NOT EXISTS gpb_vault_transactions (
    id BIGSERIAL PRIMARY KEY,
    reference VARCHAR(100) UNIQUE NOT NULL,
    customer_ref VARCHAR(100) NOT NULL,
    vault_number VARCHAR(30) NOT NULL,
    transaction_type VARCHAR(20) NOT NULL,
    amount NUMERIC(30,10) NOT NULL CHECK (amount > 0),
    currency VARCHAR(10) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    external_reference VARCHAR(150),
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    CHECK (transaction_type IN ('deposit','withdrawal','transfer')),
    CHECK (status IN ('pending','approved','completed','rejected','failed'))
);

CREATE TABLE IF NOT EXISTS gpb_vault_ledger (
    id BIGSERIAL PRIMARY KEY,
    transaction_reference VARCHAR(100) NOT NULL,
    vault_number VARCHAR(30) NOT NULL,
    entry_type VARCHAR(10) NOT NULL,
    amount NUMERIC(30,10) NOT NULL CHECK (amount > 0),
    currency VARCHAR(10) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CHECK (entry_type IN ('debit','credit'))
);

CREATE TABLE IF NOT EXISTS gpb_vault_approvals (
    id BIGSERIAL PRIMARY KEY,
    transaction_reference VARCHAR(100) NOT NULL,
    administrator_ref VARCHAR(100),
    decision VARCHAR(20) DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CHECK (decision IN ('pending','approved','rejected'))
);

CREATE INDEX IF NOT EXISTS idx_gpb_vault_customer
ON gpb_vault_accounts(customer_ref);

CREATE INDEX IF NOT EXISTS idx_gpb_vault_transactions
ON gpb_vault_transactions(customer_ref, created_at);

CREATE INDEX IF NOT EXISTS idx_gpb_vault_ledger
ON gpb_vault_ledger(vault_number, created_at);

CREATE INDEX IF NOT EXISTS idx_gpb_vault_pending
ON gpb_vault_transactions(status);

COMMIT;
SQL

if [ $? -ne 0 ]; then
    echo "ERROR: Vault database repair failed."
    echo "Check existing table structures before changing them."
    exit 1
fi

echo
echo "4. CHECKING NODE.JS"

if [ -f package.json ]; then
    node -e "JSON.parse(require('fs').readFileSync('package.json')); console.log('package.json: OK')" || echo "ERROR: package.json needs attention."
else
    echo "WARNING: package.json not found."
fi

if [ -f server.js ]; then
    node --check server.js || echo "ERROR: server.js has JavaScript syntax errors."
else
    echo "WARNING: server.js not found."
fi

echo
echo "5. CHECKING VAULT TABLES"

psql -d adegan_global -c "
SELECT table_name
FROM information_schema.tables
WHERE table_schema='public'
AND table_name LIKE 'gpb_vault_%'
ORDER BY table_name;
"

echo
echo "6. CHECKING ENVIRONMENT FILE"

if [ -f .env ]; then
    echo ".env exists. Secret values were not displayed."
else
    echo "WARNING: .env file is missing."
fi

echo
echo "7. CHECKING PROJECT FILES"

for file in server.js package.json public; do
    if [ -e "$file" ]; then
        echo "OK: $file"
    else
        echo "MISSING: $file"
    fi
done

echo
echo "ROBOT CHECK FINISHED: $(date)"
echo "No existing customer balances or transactions were changed."

} 2>&1 | tee -a "$LOG"

echo
echo "Robot report saved to: $LOG"
